<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - E Certificate System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --primary: #FF6B01;
            --secondary: #FFFFFF;
            --dark: #353535;
            --shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 10px 20px rgba(0, 0, 0, 0.12);
            --border-radius: 12px;
            --border-radius-sm: 6px;
            --transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(145deg, #f7f7f7, #e8e8e8);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 1.5rem;
            overflow-x: hidden;
            position: relative;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-user-drag: none;
            -webkit-touch-callout: none;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 30%, rgba(255, 107, 1, 0.08) 0%, transparent 40%),
                        radial-gradient(circle at 80% 70%, rgba(255, 107, 1, 0.08) 0%, transparent 40%);
            z-index: -1;
            animation: subtlePulse 15s infinite ease-in-out;
        }

        .login-container {
            max-width: 1200px;
            width: 100%;
            padding: 2rem;
            background: var(--secondary);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            position: relative;
            overflow: hidden;
            animation: fadeIn 0.8s ease;
        }

        .institution-title {
            text-align: center;
            margin-bottom: 2rem;
            animation: slideInDown 0.8s ease;
        }

        .institution-title img {
            width: 120px;
            height: auto;
            margin-bottom: 0.75rem;
            transition: var(--transition);
            filter: drop-shadow(0 3px 6px rgba(0, 0, 0, 0.1));
        }

        .institution-title img:hover {
            transform: scale(1.05);
        }

        .institution-title h1 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark);
            letter-spacing: 0.03em;
        }

        .institution-title p {
            font-size: 0.95rem;
            color: var(--dark);
            opacity: 0.65;
            margin-top: 0.4rem;
        }

        .login-logo {
            text-align: center;
            margin-bottom: 2rem;
            animation: zoomIn 0.8s ease;
        }

        .login-logo-wrapper {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
            margin-bottom: 0.75rem;
        }

        .logo-large {
            width: 60px;
            height: 60px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            transition: var(--transition);
            overflow: hidden;
        }

        .logo-large img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .login-logo:hover .logo-large {
            transform: scale(1.1);
            box-shadow: var(--shadow-lg);
        }

        .login-logo h1 {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--primary);
        }

        .login-logo p {
            font-size: 0.95rem;
            color: var(--dark);
            opacity: 0.65;
            position: relative;
            padding-bottom: 0.5rem;
        }

        .login-logo p::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 2px;
            background: var(--primary);
            border-radius: 2px;
            transition: var(--transition);
        }

        .login-logo:hover p::after {
            width: 90px;
        }

        #message-container {
            text-align: center;
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
            font-weight: 500;
            color: var(--dark);
            animation: fadeIn 0.8s ease;
        }

        .role-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            justify-items: center;
        }

        .role-card {
            background: var(--secondary);
            padding: 1.5rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 340px;
            text-align: center;
            transition: var(--transition);
            cursor: pointer;
            position: relative;
            overflow: hidden;
            max-height: 220px;
            animation: slideInUp 0.6s ease forwards;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .role-card:nth-child(1) { animation-delay: 0.1s; }
        .role-card:nth-child(2) { animation-delay: 0.2s; }
        .role-card:nth-child(3) { animation-delay: 0.3s; }

        .role-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
            border-color: var(--primary);
        }

        .role-card.expanded {
            max-height: 900px;
            border-color: var(--primary);
        }

        .role-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: var(--primary);
            transform: scaleX(0);
            transform-origin: left;
            transition: var(--transition);
        }

        .role-card:hover::before {
            transform: scaleX(1);
        }

        .role-card i {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 0.75rem;
            transition: var(--transition);
        }

        .role-card:hover i {
            transform: scale(1.1);
        }

        .role-card h3 {
            color: var(--dark);
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .role-card p {
            color: var(--dark);
            font-size: 0.9rem;
            line-height: 1.5;
            opacity: 0.65;
        }

        .login-form {
            display: none;
            margin-top: 1.5rem;
            opacity: 0;
            transition: var(--transition);
        }

        .role-card.expanded .login-form {
            display: block;
            opacity: 1;
            animation: fadeIn 0.5s ease forwards;
        }

        .form-group {
            position: relative;
            margin-bottom: 1.2rem;
        }

        .form-control {
            width: 100%;
            padding: 0.8rem 2.5rem 0.8rem 1rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: var(--border-radius-sm);
            font-size: 0.95rem;
            transition: var(--transition);
            background: #fafafa;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 107, 1, 0.1);
        }

        .form-control.is-invalid {
            border-color: #dc2626;
        }

        .password-toggle {
            position: absolute;
            right: 0.8rem;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--dark);
            opacity: 0.5;
            font-size: 0.85rem;
        }

        .role-card:hover .password-toggle {
            transform: translateY(-50%);
        }

        .floating-label label {
            position: absolute;
            top: 50%;
            left: 1rem;
            transform: translateY(-50%);
            color: var(--dark);
            font-size: 0.95rem;
            font-weight: 400;
            transition: var(--transition);
            pointer-events: none;
            background: transparent;
        }

        .floating-label.active label {
            top: -0.7rem;
            font-size: 0.75rem;
            color: var(--primary);
            background: var(--secondary);
            padding: 0 0.3rem;
            border-radius: 3px;
        }

        .forgot-password {
            display: block;
            text-align: right;
            margin-bottom: 0.75rem;
            color: var(--primary);
            font-size: 0.85rem;
            text-decoration: none;
            transition: var(--transition);
        }

        .forgot-password:hover {
            color: var(--dark);
            text-decoration: underline;
        }

        .btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            padding: 0.7rem 1rem;
            background: var(--primary);
            color: var(--secondary);
            border: none;
            border-radius: var(--border-radius-sm);
            font-size: 0.95rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            gap: 0.4rem;
        }

        .btn:hover {
            background: #e55e00;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .btn:disabled {
            background: #cccccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .ripple-effect {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: scale(0);
            animation: ripple 0.5s linear;
        }

        @keyframes ripple {
            to {
                transform: scale(3);
                opacity: 0;
            }
        }

        .student-tabs {
            display: flex;
            background: #f3f3f3;
            border-radius: var(--border-radius-sm);
            margin-bottom: 1.2rem;
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .student-tab {
            flex: 1;
            padding: 0.7rem;
            text-align: center;
            cursor: pointer;
            font-weight: 500;
            color: var(--dark);
            opacity: 0.65;
            transition: var(--transition);
            font-size: 0.95rem;
        }

        .student-tab.active {
            background: var(--secondary);
            color: var(--primary);
            border-bottom: 2px solid var(--primary);
            font-weight: 600;
            opacity: 1;
        }

        .student-tab:hover {
            background: var(--secondary);
            color: var(--primary);
            opacity: 1;
        }

        .student-form-section, .otp-form-section {
            display: none;
            padding: 1.2rem;
            background: var(--secondary);
            border-radius: var(--border-radius-sm);
            box-shadow: var(--shadow);
        }

        .student-form-section.active, .otp-form-section.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }

        .password-strength {
            display: flex;
            gap: 0.2rem;
            margin-top: 0.5rem;
        }

        .strength-bar {
            width: 20%;
            height: 3px;
            background: #e5e7eb;
            border-radius: 2px;
            transition: var(--transition);
        }

        .strength-bar.filled.weak { background: #dc2626; }
        .strength-bar.filled.medium { background: #f59e0b; }
        .strength-bar.filled.strong { background: #10b981; }

        .password-feedback {
            font-size: 0.85rem;
            margin-top: 0.5rem;
            font-weight: 400;
        }

        .text-danger { color: #dc2626; }
        .text-success { color: #10b981; }

        .alert {
            padding: 0.8rem;
            border-radius: var(--border-radius-sm);
            margin-bottom: 1.2rem;
            font-size: 0.95rem;
            font-weight: 400;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideInUp 0.4s ease;
        }

        .alert-success { background: #ecfdf5; color: #065f46; }
        .alert-danger { background: #fef2f2; color: #991b1b; }

        .alert i {
            font-size: 1rem;
        }

        .spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-top-color: var(--secondary);
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin-right: 0.5rem;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: var(--secondary);
            text-align: center;
            padding: 0.4rem 0;
            font-size: 0.8rem;
            color: var(--dark);
            opacity: 0.65;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            z-index: 1000;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes zoomIn {
            from { opacity: 0; transform: scale(0.9); }
            to { opacity: 1; transform: scale(1); }
        }

        @keyframes subtlePulse {
            0%, 100% { opacity: 0.6; }
            50% { opacity: 1; }
        }

        /* Enhanced Responsive Design */
        @media (max-width: 1200px) {
            .login-container { max-width: 1000px; padding: 2rem; }
            .institution-title h1 { font-size: 1.9rem; }
            .institution-title img { width: 110px; }
            .login-logo h1 { font-size: 2.1rem; }
            .role-card { max-width: 320px; }
            .role-cards { gap: 1.3rem; }
        }

        @media (max-width: 1024px) {
            .login-container { max-width: 900px; padding: 1.8rem; }
            .institution-title h1 { font-size: 1.8rem; }
            .institution-title img { width: 100px; }
            .login-logo h1 { font-size: 2rem; }
            .logo-large { width: 55px; height: 55px; }
            .role-card { max-width: 300px; }
            .role-cards { gap: 1.2rem; }
        }

        @media (max-width: 768px) {
            .login-container { max-width: 600px; padding: 1.5rem; }
            .institution-title h1 { font-size: 1.6rem; }
            .institution-title img { width: 90px; }
            .login-logo h1 { font-size: 1.8rem; }
            .login-logo-wrapper { flex-direction: column; gap: 0.75rem; }
            .logo-large { width: 50px; height: 50px; }
            .role-card { max-width: 100%; padding: 1.2rem; }
            .role-cards { gap: 1rem; grid-template-columns: 1fr; }
            .btn { font-size: 0.9rem; padding: 0.6rem; }
            .form-control { font-size: 0.9rem; }
        }

        @media (max-width: 600px) {
            .login-container { padding: 1.2rem; }
            .institution-title h1 { font-size: 1.5rem; }
            .institution-title img { width: 85px; }
            .login-logo h1 { font-size: 1.7rem; }
            .logo-large { width: 48px; height: 48px; }
            .role-card { padding: 1rem; }
            .role-cards { gap: 0.8rem; }
            .btn { font-size: 0.85rem; }
            .form-control { font-size: 0.85rem; padding: 0.7rem 2rem 0.7rem 0.9rem; }
        }

        @media (max-width: 480px) {
            .login-container { padding: 1rem; }
            .institution-title h1 { font-size: 1.4rem; }
            .institution-title img { width: 80px; }
            .login-logo h1 { font-size: 1.6rem; }
            .logo-large { width: 45px; height: 45px; }
            .role-card { padding: 0.8rem; }
            .role-cards { gap: 0.6rem; }
            .btn { font-size: 0.8rem; padding: 0.5rem; }
            .form-control { font-size: 0.8rem; padding: 0.6rem 1.8rem 0.6rem 0.8rem; }
            .floating-label label { font-size: 0.9rem; }
            .floating-label.active label { font-size: 0.7rem; top: -0.6rem; }
            .footer { font-size: 0.7rem; }
        }

        @media (max-width: 360px) {
            .login-container { padding: 0.8rem; }
            .institution-title h1 { font-size: 1.3rem; }
            .institution-title img { width: 75px; }
            .login-logo h1 { font-size: 1.5rem; }
            .logo-large { width: 42px; height: 42px; }
            .role-card { padding: 0.7rem; }
            .role-cards { gap: 0.5rem; }
            .btn { font-size: 0.75rem; }
            .form-control { font-size: 0.75rem; padding: 0.5rem 1.5rem 0.5rem 0.7rem; }
            .floating-label label { font-size: 0.85rem; }
            .floating-label.active label { font-size: 0.65rem; }
            .footer { font-size: 0.65rem; }
        }

        @media (min-width: 1400px) {
            .login-container { max-width: 1300px; padding: 2.5rem; }
            .institution-title h1 { font-size: 2.2rem; }
            .institution-title img { width: 130px; }
            .login-logo h1 { font-size: 2.4rem; }
            .logo-large { width: 65px; height: 65px; }
            .role-card { max-width: 360px; }
            .role-cards { gap: 2rem; }
        }
    </style>
</head>

<body>
    <div class="login-container">
        <div class="institution-title">
            <img src="/images/allen-logo.png" alt="Allenhouse Logo">
            <h1>Allenhouse Group of Institutions</h1>
            <p>Certificate Management System</p>
        </div>

        <div class="login-logo">
            <div class="login-logo-wrapper">
                <div class="logo-large">
                    <img src="/images/logo.png" alt="E Certificate Logo">
                </div>
                <h1>E Certificate System</h1>
            </div>
            <p>Secure Certificate Generation & Verification</p>
        </div>

        <div id="message-container">
            <h3>Choose Your Role</h3>
        </div>

        <div class="role-cards">
            <div class="role-card animate__animated" data-role="superadmin" onclick="expandCard(this)">
                <i class="fas fa-user-shield"></i>
                <h3>Admin</h3>
                <p>System administrators who manage faculty, categories, and events.</p>
                <form action="../handlers/login.php" method="POST" class="login-form">
                    <input type="hidden" name="role" value="superadmin">
                    <div class="form-group floating-label">
                        <input type="email" id="admin-email" name="email" class="form-control" required>
                        <label for="admin-email">Email</label>
                    </div>
                    <div class="form-group floating-label">
                        <input type="password" id="admin-password" name="password" class="form-control" required>
                        <label for="admin-password">Password</label>
                        <i class="fas fa-eye password-toggle" onclick="togglePassword('admin-password')"></i>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block ripple"><i class="fas fa-sign-in-alt"></i> Login</button>
                </form>
            </div>

            <div class="role-card animate__animated" data-role="faculty" onclick="expandCard(this)">
                <i class="fas fa-chalkboard-teacher"></i>
                <h3>Faculty</h3>
                <p>Faculty members who generate and manage student certificates.</p>
                <form action="../handlers/login.php" method="POST" class="login-form">
                    <input type="hidden" name="role" value="faculty">
                    <div class="form-group floating-label">
                        <input type="email" id="faculty-email" name="email" class="form-control" required>
                        <label for="faculty-email">Email</label>
                    </div>
                    <div class="form-group floating-label">
                        <input type="password" id="faculty-password" name="password" class="form-control" required>
                        <label for="faculty-password">Password</label>
                        <i class="fas fa-eye password-toggle" onclick="togglePassword('faculty-password')"></i>
                    </div>
                    <a href="../includes/forgot_password.php" class="forgot-password">Forgot Password?</a>
                    <button type="submit" class="btn btn-primary btn-block ripple"><i class="fas fa-sign-in-alt"></i> Login</button>
                </form>
            </div>

            <div class="role-card animate__animated" data-role="student" onclick="expandCard(this)">
                <i class="fas fa-user-graduate"></i>
                <h3>Student</h3>
                <p>Students who can view and verify their certificates.</p>
                <div class="login-form">
                    <div class="student-tabs">
                        <div class="student-tab active" onclick="switchTab('login')" data-tab="login">Login</div>
                        <div class="student-tab" onclick="switchTab('signup')" data-tab="signup">Sign Up</div>
                    </div>

                    <div class="student-form-section active" id="login-section">
                        <form action="../handlers/login.php" method="POST">
                            <input type="hidden" name="role" value="student">
                            <div class="form-group floating-label">
                                <input type="email" id="student-email" name="email" class="form-control" required>
                                <label for="student-email">Email</label>
                            </div>
                            <div class="form-group floating-label">
                                <input type="password" id="student-password" name="password" class="form-control" required>
                                <label for="student-password">Password</label>
                                <i class="fas fa-eye password-toggle" onclick="togglePassword('student-password')"></i>
                            </div>
                            <a href="../includes/forgot_password.php" class="forgot-password">Forgot Password?</a>
                            <button type="submit" class="btn btn-primary btn-block ripple"><i class="fas fa-sign-in-alt"></i> Login</button>
                        </form>
                    </div>

                    <div class="student-form-section" id="signup-section">
                        <form action="../handlers/signup_handle.php" method="POST" id="signup-form">
                            <input type="hidden" name="request_token" value="<?php echo uniqid('signup_', true); ?>">
                            <div class="form-group floating-label">
                                <input type="email" id="signup-email" name="email" class="form-control" required>
                                <label for="signup-email">Email</label>
                            </div>
                            <div class="form-group floating-label">
                                <input type="password" id="signup-password" name="password" class="form-control" required>
                                <label for="signup-password">Password</label>
                                <i class="fas fa-eye password-toggle" onclick="togglePassword('signup-password')"></i>
                            </div>
                            <div class="form-group floating-label">
                                <input type="password" id="signup-confirm" name="confirm_password" class="form-control" required>
                                <label for="signup-confirm">Confirm Password</label>
                                <i class="fas fa-eye password-toggle" onclick="togglePassword('signup-confirm')"></i>
                                <div class="password-strength"></div>
                            </div>
                            <div class="password-feedback"></div>
                            <button type="submit" class="btn btn-primary btn-block ripple"><i class="fas fa-user-plus"></i> Sign Up</button>
                        </form>
                    </div>

                    <div class="otp-form-section" id="otp-section">
                        <form action="../handlers/signup_handle.php" method="POST" id="otp-form">
                            <input type="hidden" name="request_token" value="<?php echo uniqid('otp_', true); ?>">
                            <div class="form-group floating-label">
                                <input type="text" id="otp-input" name="otp" class="form-control" required maxlength="6" pattern="\d{6}" inputmode="numeric">
                                <label for="otp-input">Enter OTP</label>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block ripple"><i class="fas fa-check"></i> Verify OTP</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        Developed by Team GARUDA 🦅
    </footer>

    <script>
        let isSubmitting = false;

        document.addEventListener('contextmenu', event => event.preventDefault());

        document.onkeydown = function(e) {
            if (
                e.keyCode == 123 ||
                (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) ||
                (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) ||
                (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) || 
                (e.ctrlKey && e.keyCode == 'S'.charCodeAt(0)) 
            ) {
                return false;
            }
        };

        document.addEventListener('selectstart', e => e.preventDefault());
        document.addEventListener('dragstart', e => e.preventDefault());

        setInterval(() => {
            const devtoolsOpen = window.outerWidth - window.innerWidth > 100;
            if (devtoolsOpen) {
                document.body.innerHTML = "<h1 style='text-align:center; margin-top:20%; color:red;'>Inspecting is not allowed!</h1>";
            }
        }, 1000);

        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const toggle = input.nextElementSibling;
            if (input.type === 'password') {
                input.type = 'text';
                toggle.classList.remove('fa-eye');
                toggle.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                toggle.classList.remove('fa-eye-slash');
                toggle.classList.add('fa-eye');
            }
        }

        function showNotification(message, type = 'info') {
            console.log(`Showing notification: ${message} (${type})`);
            const messageContainer = document.getElementById('message-container');
            messageContainer.innerHTML = `<div class="alert alert-${type} animate__animated animate__fadeIn"><i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}</div>`;
            setTimeout(() => {
                const alert = messageContainer.querySelector('.alert');
                if (alert) {
                    alert.classList.remove('animate__fadeIn');
                    alert.classList.add('animate__fadeOut');
                    setTimeout(() => {
                        messageContainer.innerHTML = '<h3>Choose Your Role</h3>';
                    }, 500);
                }
            }, 5000);
        }

        function expandCard(card) {
            console.log('Expanding card:', card.dataset.role);
            if (card.classList.contains('expanded') || isSubmitting) return;

            document.querySelectorAll('.role-card').forEach(el => {
                if (el.classList.contains('expanded')) {
                    const form = el.querySelector('.login-form');
                    form.style.opacity = '0';
                    setTimeout(() => {
                        el.classList.remove('expanded');
                        form.style.display = 'none';
                    }, 300);
                }
            });

            setTimeout(() => {
                card.classList.add('expanded');
                const form = card.querySelector('.login-form');
                form.style.display = 'block';
                setTimeout(() => {
                    form.style.opacity = '1';
                    const firstInput = form.querySelector('input:first-of-type');
                    if (firstInput) firstInput.focus();
                }, 100);
            }, 300);
        }

        function switchTab(tab) {
            if (isSubmitting) return;
            console.log(`Switching to tab: ${tab}`);
            const tabs = document.querySelectorAll('.student-tab');
            const sections = document.querySelectorAll('.student-form-section, .otp-form-section');

            tabs.forEach(el => el.classList.remove('active'));

            sections.forEach(el => {
                if (el.classList.contains('active')) {
                    el.style.transition = 'opacity 0.3s';
                    el.style.opacity = '0';
                    setTimeout(() => {
                        el.classList.remove('active');
                        el.style.display = 'none';
                        const newSection = document.getElementById(`${tab}-section`);
                        newSection.style.display = 'block';
                        newSection.classList.add('active');
                        setTimeout(() => {
                            newSection.style.opacity = '1';
                            const firstInput = newSection.querySelector('input:first-of-type');
                            if (firstInput) firstInput.focus();
                        }, 50);
                    }, 300);
                }
            });

            document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
        }

        document.addEventListener('DOMContentLoaded', function() {
            console.log('DOM fully loaded');

            document.querySelectorAll('.floating-label input').forEach(input => {
                input.addEventListener('focus', () => {
                    input.parentElement.classList.add('active');
                });
                input.addEventListener('blur', () => {
                    if (!input.value) {
                        input.parentElement.classList.remove('active');
                    }
                });
                if (input.value) {
                    input.parentElement.classList.add('active');
                }
            });

            document.querySelectorAll('.ripple').forEach(button => {
                button.addEventListener('click', function(e) {
                    if (this.disabled) return;
                    const x = e.clientX - e.target.getBoundingClientRect().left;
                    const y = e.clientY - e.target.getBoundingClientRect().top;
                    const ripple = document.createElement('span');
                    ripple.classList.add('ripple-effect');
                    ripple.style.left = `${x}px`;
                    ripple.style.top = `${y}px`;
                    this.appendChild(ripple);
                    setTimeout(() => ripple.remove(), 600);
                });
            });

            const urlParams = new URLSearchParams(window.location.search);
            const errorMsg = urlParams.get('error');
            const successMsg = urlParams.get('message');
            if (errorMsg) {
                showNotification(decodeURIComponent(errorMsg), 'danger');
            } else if (successMsg) {
                showNotification(decodeURIComponent(successMsg), 'success');
            }

            document.querySelectorAll('.login-form form:not(#signup-form):not(#otp-form)').forEach(form => {
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    console.log('Login form submitted');
                    submitForm(this, 'login');
                });
            });

            const signupForm = document.getElementById('signup-form');
            const passwordInput = document.getElementById('signup-password');
            const confirmInput = document.getElementById('signup-confirm');
            const feedbackDiv = document.querySelector('.password-feedback');
            const strengthDiv = document.querySelector('.password-strength');

            if (signupForm && passwordInput && confirmInput) {
                function validatePassword() {
                    if (passwordInput.value !== confirmInput.value) {
                        feedbackDiv.innerHTML = 'Passwords do not match';
                        feedbackDiv.classList.add('text-danger');
                        feedbackDiv.classList.remove('text-success');
                        return false;
                    } else if (passwordInput.value.length < 6) {
                        feedbackDiv.innerHTML = 'Password must be at least 6 characters';
                        feedbackDiv.classList.add('text-danger');
                        feedbackDiv.classList.remove('text-success');
                        return false;
                    } else {
                        feedbackDiv.innerHTML = 'Passwords match';
                        feedbackDiv.classList.remove('text-danger');
                        feedbackDiv.classList.add('text-success');
                        return true;
                    }
                }

                function checkPasswordStrength(password) {
                    let strength = 0;
                    if (password.length >= 6) strength += 1;
                    if (password.length >= 10) strength += 1;
                    if (/[A-Z]/.test(password)) strength += 1;
                    if (/[0-9]/.test(password)) strength += 1;
                    if (/[^A-Za-z0-9]/.test(password)) strength += 1;

                    strengthDiv.innerHTML = '';
                    for (let i = 0; i < 5; i++) {
                        const span = document.createElement('span');
                        if (i < strength) {
                            span.classList.add('strength-bar', 'filled');
                            if (strength <= 2) span.classList.add('weak');
                            else if (strength <= 4) span.classList.add('medium');
                            else span.classList.add('strong');
                        } else {
                            span.classList.add('strength-bar');
                        }
                        strengthDiv.appendChild(span);
                    }
                }

                passwordInput.addEventListener('input', function() {
                    checkPasswordStrength(this.value);
                    if (confirmInput.value) validatePassword();
                });

                confirmInput.addEventListener('input', validatePassword);

                signupForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    console.log('Signup form submitted');
                    if (!validatePassword()) {
                        showNotification('Please correct the errors in the form', 'danger');
                        return;
                    }
                    submitForm(this, 'signup');
                });
            } else {
                console.error('Signup form or inputs not found');
            }

            const otpForm = document.getElementById('otp-form');
            const otpInput = document.getElementById('otp-input');

            if (otpForm && otpInput) {
                otpInput.addEventListener('input', function() {
                    this.value = this.value.replace(/\D/g, '');
                    if (this.value.length === 6) {
                        console.log('Auto-submitting OTP');
                        otpForm.dispatchEvent(new Event('submit'));
                    }
                });

                otpForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    console.log('OTP form submitted');
                    submitForm(this, 'otp');
                });
            } else {
                console.error('OTP form or input not found');
            }

            function submitForm(form, formType) {
                if (isSubmitting) {
                    console.log(`Form submission blocked: ${formType} form is already processing`);
                    return;
                }

                console.log(`Submitting ${formType} form`);
                isSubmitting = true;

                let isValid = true;
                form.querySelectorAll('input[required]').forEach(input => {
                    if (!input.value.trim()) {
                        isValid = false;
                        input.classList.add('is-invalid');
                    } else {
                        input.classList.remove('is-invalid');
                    }
                });

                if (!isValid) {
                    showNotification('Please fill in all required fields', 'danger');
                    console.log('Validation failed: Missing required fields');
                    isSubmitting = false;
                    return;
                }

                if (formType === 'signup') {
                    const password = form.querySelector('#signup-password').value;
                    const confirm = form.querySelector('#signup-confirm').value;

                    if (password !== confirm) {
                        showNotification('Passwords do not match', 'danger');
                        console.log('Validation failed: Passwords do not match');
                        isSubmitting = false;
                        return;
                    }

                    if (password.length < 6) {
                        showNotification('Password must be at least 6 characters', 'danger');
                        console.log('Validation failed: Password too short');
                        isSubmitting = false;
                        return;
                    }
                }

                const formData = new FormData(form);
                console.log('Form Data:');
                for (let [key, value] of formData.entries()) {
                    console.log(`${key}: ${value}`);
                }

                const submitBtn = form.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<span class="spinner"></span> Processing...';
                submitBtn.disabled = true;

                fetch(form.action, {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin' 
                })
                .then(response => {
                    console.log('Fetch response status:', response.status, 'Redirected:', response.redirected);
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                    isSubmitting = false;

                    if (formType === 'login') {
                        if (response.redirected) {
                            const redirectUrl = response.url;
                            console.log('Following redirect to:', redirectUrl);
                            window.location.href = redirectUrl;
                        } else if (response.status === 200) {
                            return response.json().then(data => {
                                console.log('Server response:', data);
                                if (data.success) {
                                    const role = form.querySelector('input[name="role"]').value;
                                    let redirectUrl;
                                    if (role === 'superadmin') {
                                        redirectUrl = 'includes/register_faculty.php';
                                    } else if (role === 'faculty') {
                                        redirectUrl = 'includes/dashboard.php';
                                    } else if (role === 'student') {
                                        redirectUrl = 'includes/student_dashboard.php';
                                    } else {
                                        throw new Error('Unknown role');
                                    }
                                    console.log('Manually redirecting to:', redirectUrl);
                                    window.location.href = redirectUrl;
                                } else {
                                    showNotification(data.message || 'Login failed', 'danger');
                                }
                            });
                        } else {
                            return response.text().then(text => {
                                console.error('Unexpected response:', text);
                                showNotification('Unexpected server response', 'danger');
                            });
                        }
                    } else {
                        if (!response.ok) {
                            throw new Error(`Network response was not ok: ${response.statusText}`);
                        }
                        return response.json();
                    }
                })
                .then(data => {
                    if (!data) return; 
                    console.log('Server Response:', data);

                    if (data.success) {
                        if (formType === 'signup' && data.action === 'show_otp_form') {
                            console.log('Showing OTP section');
                            const signupSection = document.getElementById('signup-section');
                            const otpSection = document.getElementById('otp-section');

                            if (!signupSection || !otpSection) {
                                console.error('Signup or OTP section not found');
                                showNotification('UI error: OTP section not found', 'danger');
                                return;
                            }

                            showNotification(`OTP sent to ${data.email}`, 'success');

                            signupSection.style.transition = 'opacity 0.3s';
                            signupSection.style.opacity = '0';
                            setTimeout(() => {
                                signupSection.classList.remove('active');
                                signupSection.style.display = 'none';
                                otpSection.style.display = 'block';
                                otpSection.classList.add('active');
                                setTimeout(() => {
                                    otpSection.style.opacity = '1';
                                    const otpInput = otpSection.querySelector('#otp-input');
                                    if (otpInput) {
                                        otpInput.focus();
                                        console.log('Focused on OTP input');
                                    } else {
                                        console.error('OTP input not found');
                                    }
                                }, 50);
                            }, 300);

                            signupForm.reset();
                            signupForm.querySelectorAll('.floating-label').forEach(label => {
                                label.classList.remove('active');
                            });
                            strengthDiv.innerHTML = '';
                            feedbackDiv.innerHTML = '';
                        } else if (formType === 'otp') {
                            showNotification(data.message || 'Signup successful', 'success');
                            console.log('OTP verified successfully');

                            const studentCard = document.querySelector('.role-card[data-role="student"]');
                            const loginForm = studentCard.querySelector('.login-form');
                            loginForm.style.opacity = '0';
                            setTimeout(() => {
                                studentCard.classList.remove('expanded');
                                loginForm.style.display = 'none';
                                switchTab('login');
                                otpForm.reset();
                                otpForm.querySelectorAll('.floating-label').forEach(label => {
                                    label.classList.remove('active');
                                });
                                setTimeout(() => {
                                    window.location.reload();
                                }, 1000);
                            }, 300);
                        }
                    } else {
                        showNotification(data.message || 'An error occurred', 'danger');
                        console.log('Server error:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Fetch Error:', error);
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                    isSubmitting = false;
                    showNotification('An error occurred. Please try again.', 'danger');
                });
            }
        });
    </script>
</body>
</html>