<?php

if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    header('HTTP/1.1 403 Forbidden');
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Direct access attempt blocked\n", FILE_APPEND);
    die('Access denied');
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Attempting database connection\n", FILE_APPEND);


$db_host = "localhost";
$db_user = "root";
$db_pass = "your_password_here"; // Change this to your actual password
$db_name = "exuberance_db";


try {
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    if ($conn->connect_error) {
        file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Connection failed: " . $conn->connect_error . "\n", FILE_APPEND);
        die("Connection failed: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");
    
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Database connection successful\n", FILE_APPEND);
} catch (Exception $e) {
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Database connection exception: " . $e->getMessage() . "\n", FILE_APPEND);
    die("Database connection error: " . $e->getMessage());
}
?>