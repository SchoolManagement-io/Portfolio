<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../index.html");
    exit;
}

if ($_SESSION['role'] !== 'superadmin' && $_SESSION['role'] !== 'faculty') {
    header("Location: ../includes/dashboard.php");
    exit;
}

require_once '../assets/db_config.php';

file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - delete_certificate.php accessed\n", FILE_APPEND);

if (!isset($_GET['id']) || empty($_GET['id'])) {
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Invalid certificate ID\n", FILE_APPEND);
    echo "error: Invalid certificate ID";
    exit;
}

$id = mysqli_real_escape_string($conn, $_GET['id']);

if ($_SESSION['role'] === 'faculty') {
    $checkQuery = "SELECT created_by FROM certificates WHERE id = '$id'";
    $checkResult = mysqli_query($conn, $checkQuery);
    if ($checkResult && mysqli_num_rows($checkResult) > 0) {
        $certData = mysqli_fetch_assoc($checkResult);
        if ($certData['created_by'] != $_SESSION['user_id']) {
            file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Permission denied for user {$_SESSION['user_id']}\n", FILE_APPEND);
            echo "error: You don't have permission to delete this certificate";
            exit;
        }
    }
}

$query = "SELECT certificate_file, qr_code FROM certificates WHERE id = '$id'";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $certificate = mysqli_fetch_assoc($result);
    
    if (!empty($certificate['certificate_file'])) {
        $certificate_path = '../certificates/' . $certificate['certificate_file'];
        if (file_exists($certificate_path)) {
            unlink($certificate_path);
            file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Deleted certificate file: $certificate_path\n", FILE_APPEND);
        }
    }
    
    if (!empty($certificate['qr_code'])) {
        $qr_path = '../qrcodes/' . $certificate['qr_code'];
        if (file_exists($qr_path)) {
            unlink($qr_path);
            file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Deleted QR code file: $qr_path\n", FILE_APPEND);
        }
    }
    
    $delete_query = "DELETE FROM certificates WHERE id = '$id'";
    if (mysqli_query($conn, $delete_query)) {
        file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Certificate ID $id deleted successfully\n", FILE_APPEND);
        echo "success: Certificate deleted successfully";
    } else {
        $db_error = mysqli_error($conn);
        file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Database error: $db_error\n", FILE_APPEND);
        echo "error: $db_error";
    }
} else {
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Certificate ID $id not found\n", FILE_APPEND);
    echo "error: Certificate not found";
}

mysqli_close($conn);
?>