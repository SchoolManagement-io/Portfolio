<?php
require_once '../assets/db_config.php';

if (!isset($_GET['ref'])) {
    die("Certificate reference missing.");
}

$ref = $_GET['ref'];

$sql = "SELECT certificate_file FROM certificates WHERE certificate_ref = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $ref);
$stmt->execute();
$stmt->bind_result($fileName);
$stmt->fetch();
$stmt->close();
$conn->close();

$filePath = '../certificates/' . $fileName;

if (!file_exists($filePath)) {
    die("Certificate file not found on server: $filePath");
}

header("Content-Type: application/pdf");
header("Content-Disposition: attachment; filename=\"" . basename($fileName) . "\"");
header("Content-Length: " . filesize($filePath));
readfile($filePath);
exit;
?>
