<?php

if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    header('HTTP/1.1 403 Forbidden');
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Direct access attempt blocked to mail_credentials.php\n", FILE_APPEND);
    die('Access denied');
}

require_once '../assets/db_config.php';
require_once '../PHP_Extensions/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendOTPEmail($conn, $email, $otp) {
    try {
        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'your_mail_here'; // Change this to your actual email
        $mail->Password = 'your_password_here'; // Change this to your actual password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('no-reply@ecertsystem.com', 'E-Certificate System');
        $mail->addAddress($email);

        $mail->Subject = 'Verify Your Email with OTP';
        $mail->Body = "
            <html>
            <head>
                <style>
                    body {
                        font-family: 'Inter', Arial, sans-serif;
                        line-height: 1.6;
                        color: #353535;
                        margin: 0;
                        padding: 0;
                        background: #f7f7f7;
                    }
                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        padding: clamp(1rem, 2vw, 1.5rem);
                        background: #FFFFFF;
                        border-radius: 12px;
                        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
                        animation: fadeIn 0.8s ease;
                    }
                    .header {
                        background: linear-gradient(90deg, #FF6B01, #ff8c00);
                        color: #FFFFFF;
                        padding: clamp(1rem, 2vw, 1.5rem);
                        text-align: center;
                        border-radius: 12px 12px 0 0;
                    }
                    .header h2 {
                        font-size: clamp(1.2rem, 2.5vw, 1.5rem);
                        margin: 0;
                        font-weight: 600;
                    }
                    .content {
                        padding: clamp(1rem, 2.5vw, 1.5rem);
                        background: rgba(255, 255, 255, 0.95);
                        border: 1px solid rgba(0, 0, 0, 0.05);
                        border-radius: 0 0 12px 12px;
                    }
                    .content p {
                        font-size: clamp(0.85rem, 1.6vw, 0.95rem);
                        margin: clamp(0.5rem, 1vw, 0.75rem) 0;
                    }
                    .otp-box {
                        font-size: clamp(1.2rem, 2.5vw, 1.4rem);
                        font-weight: 700;
                        color: #FF6B01;
                        text-align: center;
                        padding: clamp(0.8rem, 2vw, 1rem);
                        background: #fff7ed;
                        border: 2px solid #FF6B01;
                        border-radius: 8px;
                        margin: clamp(0.8rem, 2vw, 1rem) 0;
                        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
                        animation: scaleIn 0.6s ease;
                    }
                    .footer {
                        text-align: center;
                        margin-top: clamp(1rem, 2vw, 1.5rem);
                        font-size: clamp(0.7rem, 1.4vw, 0.8rem);
                        color: #353535;
                        opacity: 0.65;
                    }
                    @keyframes fadeIn {
                        from { opacity: 0; transform: translateY(20px); }
                        to { opacity: 1; transform: translateY(0); }
                    }
                    @keyframes scaleIn {
                        from { transform: scale(0.8); opacity: 0; }
                        to { transform: scale(1); opacity: 1; }
                    }
                    @media (max-width: 600px) {
                        .container {
                            padding: clamp(0.8rem, 2vw, 1rem);
                        }
                        .header {
                            padding: clamp(0.8rem, 2vw, 1rem);
                        }
                        .header h2 {
                            font-size: clamp(1rem, 2vw, 1.2rem);
                        }
                        .content {
                            padding: clamp(0.8rem, 2vw, 1rem);
                        }
                        .content p {
                            font-size: clamp(0.8rem, 1.5vw, 0.9rem);
                        }
                        .otp-box {
                            font-size: clamp(1rem, 2vw, 1.2rem);
                            padding: clamp(0.6rem, 1.5vw, 0.8rem);
                        }
                        .footer {
                            font-size: clamp(0.65rem, 1.3vw, 0.75rem);
                        }
                    }
                    @media (max-width: 480px) {
                        .container {
                            padding: clamp(0.6rem, 1.5vw, 0.8rem);
                        }
                        .content p {
                            font-size: clamp(0.75rem, 1.4vw, 0.85rem);
                        }
                        .otp-box {
                            font-size: clamp(0.9rem, 1.8vw, 1rem);
                            padding: clamp(0.5rem, 1.2vw, 0.6rem);
                        }
                    }
                    @media (max-width: 360px) {
                        .header h2 {
                            font-size: clamp(0.9rem, 1.8vw, 1rem);
                        }
                        .content p {
                            font-size: clamp(0.7rem, 1.3vw, 0.8rem);
                        }
                        .otp-box {
                            font-size: clamp(0.8rem, 1.6vw, 0.9rem);
                        }
                    }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='header'>
                        <h2>E-Certificate System</h2>
                    </div>
                    <div class='content'>
                        <p>Dear User,</p>
                        <p>Thank you for registering with the E-Certificate System. To complete your sign-up, please verify your email address using the One-Time Password (OTP) below:</p>
                        <div class='otp-box'>{$otp}</div>
                        <p>This OTP is valid for 2 minutes. Please enter it on the verification page to proceed.</p>
                        <p>If you did not request this OTP, please ignore this email.</p>
                        <p>Best regards,<br>E-Certificate System Team</p>
                    </div>
                    <div class='footer'>
                        <p>© " . date('Y') . " E-Certificate System. All rights reserved.</p>
                    </div>
                </div>
            </body>
            </html>
        ";

        $mail->isHTML(true);

        $mail->send();
        error_log("[otp_mail.php] OTP email sent successfully to {$email} with OTP: {$otp}");
        return true;
    } catch (Exception $e) {
        error_log("[otp_mail.php] OTP email sending failed for {$email}: {$mail->ErrorInfo}");
        return false;
    }
}
?>