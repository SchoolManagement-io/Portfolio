<?php
session_start();
require_once '../assets/db_config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['logged_in']) || $_SESSION['role'] !== 'superadmin') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!isset($input['id']) || !is_numeric($input['id']) || !isset($input['file'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid or missing template ID or file']);
    exit;
}

$template_id = (int)$input['id'];
$template_file = $input['file'];
$upload_dir = '../Uploads/templates/';
$file_path = $upload_dir . $template_file;

try {
    $conn->begin_transaction();

    $stmt = $conn->prepare("SELECT template_file FROM certificate_templates WHERE id = ?");
    $stmt->bind_param("i", $template_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => 'Template not found']);
        exit;
    }

    $stmt = $conn->prepare("DELETE FROM certificate_templates WHERE id = ?");
    $stmt->bind_param("i", $template_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        if (file_exists($file_path)) {
            if (!unlink($file_path)) {
                $conn->rollback();
                echo json_encode(['success' => false, 'error' => 'Failed to delete template file']);
                exit;
            }
        }
        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Template deleted successfully']);
    } else {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => 'Failed to delete template']);
    }
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>