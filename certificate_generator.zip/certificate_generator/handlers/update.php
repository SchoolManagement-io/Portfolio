<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../index.html");
    exit;
}

if ($_SESSION['role'] !== 'superadmin' && $_SESSION['role'] !== 'faculty') {
    header("Location: ../includes/dashboard.php");
    exit;
}

require_once '../assets/db_config.php';
require_once 'add_update_mail.php';
require_once '../PHP_Extensions/qr_generator.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    error_log("Update.php received POST request: " . print_r($_POST, true));
    
    $id = isset($_POST['id']) ? mysqli_real_escape_string($conn, $_POST['id']) : null;
    $participant_name = mysqli_real_escape_string($conn, $_POST['participant_name']);
    $participant_crn = mysqli_real_escape_string($conn, $_POST['participant_crn']);
    $participant_mobile = mysqli_real_escape_string($conn, $_POST['participant_mobile']);
    $participant_email = mysqli_real_escape_string($conn, $_POST['participant_email']);
    $course_name = mysqli_real_escape_string($conn, $_POST['course_name']);
    $category_id = mysqli_real_escape_string($conn, $_POST['category_id']);
    $event_id = mysqli_real_escape_string($conn, $_POST['event_id']);
    $certificate_ref = mysqli_real_escape_string($conn, $_POST['certificate_ref']);
    $template_id = isset($_POST['template_id']) ? mysqli_real_escape_string($conn, $_POST['template_id']) : null;

    if (!$id || !is_numeric($id)) {
        echo "error: Invalid certificate ID provided";
        exit;
    }

    if (!$template_id || !is_numeric($template_id)) {
        echo "error: Invalid template ID provided";
        exit;
    }
    
    if ($_SESSION['role'] === 'faculty') {
        $checkQuery = "SELECT created_by FROM certificates WHERE id = $id";
        $checkResult = mysqli_query($conn, $checkQuery);
        if ($checkResult && mysqli_num_rows($checkResult) > 0) {
            $certData = mysqli_fetch_assoc($checkResult);
            if ($certData['created_by'] != $_SESSION['user_id']) {
                echo "error: You don't have permission to update this certificate";
                exit;
            }
        }
    }
    
    $eventQuery = "SELECT e.event_name, c.category_name 
                  FROM events e 
                  JOIN categories c ON e.category_id = c.id 
                  WHERE e.id = '$event_id'";
    $eventResult = mysqli_query($conn, $eventQuery);
    
    if ($eventResult && mysqli_num_rows($eventResult) > 0) {
        $eventData = mysqli_fetch_assoc($eventResult);
    } else {
        echo "error: Invalid event or category";
        exit;
    }
    
    $fileUpdateSql = "";
    if (isset($_FILES['certificate_file']) && $_FILES['certificate_file']['error'] == 0) {
        $allowed = array('pdf', 'jpg', 'jpeg', 'png');
        $filename = $_FILES['certificate_file']['name'];
        $tmp = $_FILES['certificate_file']['tmp_name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($ext), $allowed)) {
            $new_filename = $certificate_ref . '.' . $ext;
            if (!file_exists('../certificates')) {
                mkdir('../certificates', 0777, true);
            }
            if (move_uploaded_file($tmp, '../certificates/' . $new_filename)) {
                $fileUpdateSql = ", certificate_file = '$new_filename'";
            } else {
                echo "error: Failed to upload file";
                exit;
            }
        } else {
            echo "error: Invalid file format";
            exit;
        }
    }
    
    $baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
    $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
    $verificationUrl = $baseUrl . str_replace('/handlers', '/includes', $scriptDir) . "/view_certificate.php?ref=" . urlencode($certificate_ref);
    $qrData = $verificationUrl;
    $qrFilename = $certificate_ref . '_qr.png';
    generateQRCode($qrData, $qrFilename);
    
    $sql = "UPDATE certificates 
            SET participant_name = '$participant_name', 
                participant_crn = '$participant_crn', 
                participant_mobile = '$participant_mobile', 
                participant_email = '$participant_email', 
                course_name = '$course_name',
                category_id = '$category_id', 
                event_id = '$event_id', 
                certificate_ref = '$certificate_ref',
                template_id = '$template_id',
                qr_code = '$qrFilename',
                updated_at = NOW()
                $fileUpdateSql
            WHERE id = $id";
    
    if (mysqli_query($conn, $sql)) {
        $certificateData = [
            'participant_name' => $participant_name,
            'participant_email' => $participant_email,
            'course_name' => $course_name,
            'event_id' => $event_id,
            'certificate_ref' => $certificate_ref,
            'verification_url' => $verificationUrl
        ];

        if (!sendCertificateEmail($conn, 'update', $certificateData, $_SESSION['user_id'])) {
            error_log("Warning: Email sending failed for certificate_ref: $certificate_ref");
        }

        echo "success: Certificate updated successfully";
    } else {
        echo "error: " . mysqli_error($conn);
    }
    
    mysqli_close($conn);
} else {
    header("Location: ../includes/dashboard.php");
    exit;
}
?>