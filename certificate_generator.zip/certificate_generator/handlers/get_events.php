<?php
session_start();
file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - get_events.php accessed with SESSION: " . print_r($_SESSION, true) . "\n", FILE_APPEND);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Unauthorized access to get_events.php\n", FILE_APPEND);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

require_once '../assets/db_config.php';

if (!isset($_GET['category_id']) || !is_numeric($_GET['category_id'])) {
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Invalid category ID: " . (isset($_GET['category_id']) ? $_GET['category_id'] : 'not set') . "\n", FILE_APPEND);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid category ID']);
    exit;
}

$categoryId = mysqli_real_escape_string($conn, $_GET['category_id']);
file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Fetching events for category ID: $categoryId\n", FILE_APPEND);

$eventsQuery = "SELECT id, event_name FROM events WHERE category_id = '$categoryId' ORDER BY event_name";
$eventsResult = mysqli_query($conn, $eventsQuery);

if (!$eventsResult) {
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Query error: " . mysqli_error($conn) . "\n", FILE_APPEND);
}

$events = [];
if ($eventsResult && mysqli_num_rows($eventsResult) > 0) {
    while ($event = mysqli_fetch_assoc($eventsResult)) {
        $events[] = [
            'id' => $event['id'],
            'event_name' => $event['event_name']
        ];
    }
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Found " . count($events) . " events for category ID: $categoryId\n", FILE_APPEND);
} else {
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - No events found for category ID: $categoryId\n", FILE_APPEND);
}

header('Content-Type: application/json');
echo json_encode($events);
file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Returned events: " . json_encode($events) . "\n", FILE_APPEND);
?> 