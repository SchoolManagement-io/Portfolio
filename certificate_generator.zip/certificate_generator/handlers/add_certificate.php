<?php
session_start();
require_once '../assets/db_config.php';
require_once 'add_update_mail.php';
require_once '../PHP_Extensions/qr_generator.php';

if (!isset($_SESSION['logged_in']) || !in_array($_SESSION['role'], ['faculty', 'superadmin'])) {
    header("Location: ../includes/dashboard.php");
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_error_log.txt');

function logDebug($message) {
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - $message\n", FILE_APPEND);
}

logDebug("add_certificate.php accessed");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        logDebug("POST data: " . print_r($_POST, true));
        logDebug("FILES data: " . print_r($_FILES, true));

        $required_fields = [
            'participant_name', 'participant_crn', 'participant_mobile', 'participant_email',
            'course_name', 'category_id', 'event_id', 'certificate_ref', 'created_by', 'template_id'
        ];
        foreach ($required_fields as $field) {
            if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
                throw new Exception("Missing required field: $field");
            }
        }

        $participant_name = trim($_POST['participant_name']);
        $participant_crn = trim($_POST['participant_crn']);
        $participant_mobile = trim($_POST['participant_mobile']);
        $participant_email = trim($_POST['participant_email']);
        $course_name = trim($_POST['course_name']);
        $category_id = (int)$_POST['category_id'];
        $event_id = (int)$_POST['event_id'];
        $certificate_ref = trim($_POST['certificate_ref']);
        $created_by = (int)$_POST['created_by'];
        $template_id = (int)$_POST['template_id'];

        if (!filter_var($participant_email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Invalid email format');
        }

        if (!preg_match('/^[0-9]{10}$/', $participant_mobile)) {
            throw new Exception('Invalid mobile number');
        }

        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM events e 
                                JOIN categories c ON e.category_id = c.id 
                                WHERE e.id = ? AND c.id = ?");
        $stmt->bind_param("ii", $event_id, $category_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        if ($row['count'] == 0) {
            throw new Exception('Invalid event or category');
        }

        $certificate_file = null;
        if (isset($_FILES['certificate_file']) && $_FILES['certificate_file']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['certificate_file']['tmp_name'];
            $file_name = $_FILES['certificate_file']['name'];
            $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            $allowed = ['pdf', 'jpg', 'jpeg', 'png'];

            if (!in_array($ext, $allowed)) {
                throw new Exception('Invalid file format. Allowed: PDF, JPG, JPEG, PNG');
            }

            $new_filename = $certificate_ref . '.' . $ext;
            $file_path = '../certificates/' . $new_filename;

            if (!file_exists('../certificates')) {
                mkdir('../certificates', 0777, true);
                logDebug("Created certificates directory");
            }

            if (!move_uploaded_file($file_tmp, $file_path)) {
                throw new Exception('Failed to upload certificate file');
            }

            $certificate_file = $new_filename;
            logDebug("File uploaded successfully: $new_filename");
        }

        $qr_filename = $certificate_ref . '_qr.png';
        $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
        $script_dir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
        $verification_url = $base_url . str_replace('/handlers', '/includes', $script_dir) . "/view_certificate.php?ref=" . urlencode($certificate_ref);
        $qr_code = generateQRCode($verification_url, $qr_filename);

        $stmt = $conn->prepare("INSERT INTO certificates (participant_name, participant_crn, participant_mobile, 
                                participant_email, course_name, category_id, event_id, template_id, certificate_ref, 
                                certificate_file, qr_code, created_by, created_at) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param(
            "sssssiiisssi",
            $participant_name,
            $participant_crn,
            $participant_mobile,
            $participant_email,
            $course_name,
            $category_id,
            $event_id,
            $template_id,
            $certificate_ref,
            $certificate_file,
            $qr_code,
            $created_by
        );

        if ($stmt->execute()) {
            logDebug("Database insert successful for certificate_ref: $certificate_ref");

            $certificateData = [
                'participant_name' => $participant_name,
                'participant_email' => $participant_email,
                'course_name' => $course_name,
                'event_id' => $event_id,
                'certificate_ref' => $certificate_ref,
                'verification_url' => $verification_url
            ];

            if (!sendCertificateEmail($conn, 'add', $certificateData, $created_by)) {
                logDebug("Warning: Email sending failed for certificate_ref: $certificate_ref");
            }

            echo "success";
        } else {
            throw new Exception("Database error: " . $stmt->error);
        }

        $stmt->close();

    } catch (Exception $e) {
        logDebug("Error: " . $e->getMessage());
        echo "error: " . $e->getMessage();
    }

    $conn->close();
} else {
    logDebug("Invalid request method: " . $_SERVER['REQUEST_METHOD']);
    header("Location: ../includes/dashboard.php");
    exit;
}
?>