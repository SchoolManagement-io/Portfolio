<?php
session_start();
require_once '../assets/db_config.php';
require_once 'otp_mail.php';

header('Content-Type: application/json');

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$port = $_SERVER['SERVER_PORT'] !== '80' && $_SERVER['SERVER_PORT'] !== '443' ? ':' . $_SERVER['SERVER_PORT'] : '';
$base_url = "$protocol://$host$port/";

$response = ['success' => false, 'message' => '', 'action' => '', 'redirect' => '', 'email' => ''];

error_log("[signup_handle.php] Request received: " . json_encode($_POST));

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = "Invalid request method";
    error_log("[signup_handle.php] Error: Invalid request method");
    echo json_encode($response, JSON_UNESCAPED_SLASHES);
    exit;
}

$request_token = $_POST['request_token'] ?? '';
if (empty($request_token)) {
    $response['message'] = "Invalid request token";
    error_log("[signup_handle.php] Error: Missing request token");
    echo json_encode($response, JSON_UNESCAPED_SLASHES);
    exit;
}

$stmt = $conn->prepare("DELETE FROM request_tokens WHERE created_at < NOW() - INTERVAL 20 SECOND");
if (!$stmt->execute()) {
    error_log("[signup_handle.php] Warning: Failed to clean up expired tokens: " . $conn->error);
}
$stmt->close();

$stmt = $conn->prepare("SELECT id FROM request_tokens WHERE token = ? AND created_at > NOW() - INTERVAL 20 SECOND");
$stmt->bind_param("s", $request_token);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $response['message'] = "Please wait 20 seconds before requesting a new OTP.";
    error_log("[signup_handle.php] Error: Duplicate request token: $request_token");
    echo json_encode($response, JSON_UNESCAPED_SLASHES);
    exit;
}

$stmt = $conn->prepare("INSERT INTO request_tokens (token, created_at) VALUES (?, NOW())");
$stmt->bind_param("s", $request_token);
if (!$stmt->execute()) {
    $response['message'] = "Error processing request: " . $conn->error;
    error_log("[signup_handle.php] Error: Failed to store request token: " . $conn->error);
    echo json_encode($response, JSON_UNESCAPED_SLASHES);
    exit;
}
$stmt->close();

if (isset($_POST['otp'])) {
    $otp = trim($_POST['otp']);
    $email = isset($_SESSION['signup_email']) ? $_SESSION['signup_email'] : '';

    error_log("[signup_handle.php] OTP verification for email: $email, OTP: $otp");

    if (empty($otp) || empty($email)) {
        $response['message'] = "Invalid OTP or session expired";
        error_log("[signup_handle.php] Error: Invalid OTP or session expired");
    } else {
        $stmt = $conn->prepare("SELECT otp, expires_at FROM otp_verifications WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            $response['message'] = "No OTP found for this email";
            error_log("[signup_handle.php] Error: No OTP found for email: $email");
        } else {
            $row = $result->fetch_assoc();
            $stored_otp = $row['otp'];
            $expires_at = strtotime($row['expires_at']);
            $current_time = time();

            if ($current_time > $expires_at) {
                $response['message'] = "OTP has expired";
                error_log("[signup_handle.php] Error: OTP expired for email: $email");
            } elseif ($otp !== $stored_otp) {
                $response['message'] = "Invalid OTP";
                error_log("[signup_handle.php] Error: Invalid OTP for email: $email");
            } else {
                $password = $_SESSION['signup_password'];
                $stmt = $conn->prepare("SELECT id FROM students WHERE email = ?");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $response['message'] = "Email already registered";
                    error_log("[signup_handle.php] Error: Email already registered: $email");
                } else {
                    $stmt = $conn->prepare("INSERT INTO students (email, password) VALUES (?, ?)");
                    $stmt->bind_param("ss", $email, $password);

                    if ($stmt->execute()) {
                        $stmt = $conn->prepare("DELETE FROM otp_verifications WHERE email = ?");
                        $stmt->bind_param("s", $email);
                        $stmt->execute();

                        $stmt = $conn->prepare("DELETE FROM request_tokens WHERE token = ?");
                        $stmt->bind_param("s", $request_token);
                        if ($stmt->execute()) {
                            error_log("[signup_handle.php] Success: Request token deleted: $request_token");
                        } else {
                            error_log("[signup_handle.php] Warning: Failed to delete request token: $request_token, Error: " . $conn->error);
                        }

                        unset($_SESSION['signup_email']);
                        unset($_SESSION['signup_password']);

                        $response['success'] = true;
                        $response['message'] = "Student registered successfully";
                        error_log("[signup_handle.php] Success: Student registered: $email");
                    } else {
                        $response['message'] = "Error registering student: " . $conn->error;
                        error_log("[signup_handle.php] Error: Failed to register student: " . $conn->error);
                    }
                }
            }
        }
        $stmt->close();
    }
} else {
    if (empty($_POST['email']) || empty($_POST['password']) || empty($_POST['confirm_password'])) {
        $response['message'] = "All fields are required";
        error_log("[signup_handle.php] Error: Missing required fields");
    } elseif ($_POST['password'] !== $_POST['confirm_password']) {
        $response['message'] = "Passwords do not match";
        error_log("[signup_handle.php] Error: Passwords do not match");
    } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $response['message'] = "Invalid email format";
        error_log("[signup_handle.php] Error: Invalid email format");
    } elseif (strlen($_POST['password']) < 6) {
        $response['message'] = "Password must be at least 6 characters";
        error_log("[signup_handle.php] Error: Password too short");
    } else {
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        error_log("[signup_handle.php] Processing signup for email: $email");

        $stmt = $conn->prepare("SELECT id FROM students WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $response['message'] = "Email already registered";
            error_log("[signup_handle.php] Error: Email already registered: $email");
        } else {
            $stmt = $conn->prepare("SELECT id FROM otp_verifications WHERE email = ? AND created_at > NOW() - INTERVAL 20 SECOND");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $response['message'] = "An OTP was recently sent. Please wait 20 seconds before requesting again.";
                error_log("[signup_handle.php] Error: Recent OTP exists for email: $email");
            } else {
                $otp = sprintf("%06d", mt_rand(0, 999999));
                $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));

                $stmt = $conn->prepare("INSERT INTO otp_verifications (email, otp, expires_at, created_at) VALUES (?, ?, ?, NOW()) 
                                        ON DUPLICATE KEY UPDATE otp = ?, expires_at = ?, created_at = NOW()");
                $stmt->bind_param("sssss", $email, $otp, $expires_at, $otp, $expires_at);

                if ($stmt->execute()) {
                    if (sendOTPEmail($conn, $email, $otp)) {
                        $stmt = $conn->prepare("DELETE FROM request_tokens WHERE token = ?");
                        $stmt->bind_param("s", $request_token);
                        if ($stmt->execute()) {
                            error_log("[signup_handle.php] Success: Request token deleted after OTP send: $request_token");
                        } else {
                            error_log("[signup_handle.php] Warning: Failed to delete request token after OTP send: $request_token, Error: " . $conn->error);
                        }

                        $_SESSION['signup_email'] = $email;
                        $_SESSION['signup_password'] = $password;

                        $response['success'] = true;
                        $response['message'] = "OTP sent to your email";
                        $response['action'] = "show_otp_form";
                        $response['email'] = $email;
                        error_log("[signup_handle.php] Success: OTP sent to email: $email");
                    } else {
                        $response['message'] = "Failed to send OTP email";
                        error_log("[signup_handle.php] Error: Failed to send OTP email to: $email");
                    }
                } else {
                    $response['message'] = "Error storing OTP: " . $conn->error;
                    error_log("[signup_handle.php] Error: Failed to store OTP: " . $conn->error);
                }
            }
        }
        $stmt->close();
    }
}

echo json_encode($response, JSON_UNESCAPED_SLASHES);
exit;
?>