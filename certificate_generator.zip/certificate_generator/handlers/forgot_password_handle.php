<?php
session_start();

if (!file_exists('../assets/db_config.php')) {
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Configuration file not found']);
    exit;
}

require_once '../assets/db_config.php';
require_once 'forgot_mail.php';

header('Content-Type: application/json');

function generateOTP() {
    return sprintf("%06d", mt_rand(100000, 999999));
}

function clearPreviousOTP($conn, $email) {
    $stmt = $conn->prepare("DELETE FROM otp_verifications WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->close();
}

function clearRequestToken($conn, $email) {
    $stmt = $conn->prepare("DELETE FROM request_tokens WHERE token = ?");
    $token = hash('sha256', $email);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $stmt->close();
}

function hasRecentRequest($conn, $email) {
    $token = hash('sha256', $email);
    $stmt = $conn->prepare("SELECT created_at FROM request_tokens WHERE token = ? AND created_at > NOW() - INTERVAL 2 MINUTE");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $hasRecent = $result->num_rows > 0;
    $stmt->close();
    return $hasRecent;
}

function storeRequestToken($conn, $email) {
    $token = hash('sha256', $email);
    $stmt = $conn->prepare("INSERT INTO request_tokens (token, created_at) VALUES (?, NOW())");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $stmt->close();
}

function checkEmailExists($conn, $email) {
    $tables = ['students', 'faculty'];
    foreach ($tables as $table) {
        $stmt = $conn->prepare("SELECT email FROM $table WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $stmt->close();
            return $table;
        }
        $stmt->close();
    }
    return false;
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    if (!isset($db_host, $db_user, $db_pass, $db_name)) {
        throw new Exception('Database configuration variables are missing');
    }

    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    if ($conn->connect_error) {
        throw new Exception('Database connection failed: ' . $conn->connect_error);
    }

    $action = isset($_POST['action']) ? $_POST['action'] : '';

    switch ($action) {
        case 'send_otp':
            $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception('Invalid email format');
            }

            $table = checkEmailExists($conn, $email);
            if (!$table) {
                throw new Exception('Email not found');
            }

            if (hasRecentRequest($conn, $email)) {
                throw new Exception('Please wait 2 minutes before requesting another OTP');
            }

            $otp = generateOTP();
            $expires_at = date('Y-m-d H:i:s', strtotime('+2 minutes'));

            clearPreviousOTP($conn, $email);
            $stmt = $conn->prepare("INSERT INTO otp_verifications (email, otp, expires_at) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $email, $otp, $expires_at);
            if (!$stmt->execute()) {
                throw new Exception('Failed to store OTP');
            }
            $stmt->close();

            storeRequestToken($conn, $email);

            if (!sendOTPEmail($conn, $email, $otp)) {
                throw new Exception('Failed to send OTP email');
            }

            $_SESSION['reset_email'] = $email;
            $_SESSION['otp_timer'] = time() + 120;
            echo json_encode(['success' => true, 'email' => $email]);
            break;

        case 'verify_otp':
            $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
            $otp = preg_replace('/\D/', '', $_POST['otp']);

            if (!isset($_SESSION['reset_email']) || $_SESSION['reset_email'] !== $email) {
                throw new Exception('Invalid session');
            }

            if (!isset($_SESSION['otp_timer']) || $_SESSION['otp_timer'] < time()) {
                clearPreviousOTP($conn, $email);
                throw new Exception('OTP has expired');
            }

            $stmt = $conn->prepare("SELECT otp, expires_at FROM otp_verifications WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                throw new Exception('No OTP found for this email');
            }

            $row = $result->fetch_assoc();
            $stmt->close();

            if (strtotime($row['expires_at']) < time()) {
                clearPreviousOTP($conn, $email);
                throw new Exception('OTP has expired');
            }

            if ($row['otp'] !== $otp) {
                throw new Exception('Invalid OTP');
            }

            clearPreviousOTP($conn, $email);
            clearRequestToken($conn, $email);
            $_SESSION['otp_verified'] = true;
            echo json_encode(['success' => true]);
            break;

        case 'reset_password':
            $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];

            if (!isset($_SESSION['reset_email']) || $_SESSION['reset_email'] !== $email || !isset($_SESSION['otp_verified']) || $_SESSION['otp_verified'] !== true) {
                throw new Exception('Invalid session or OTP not verified');
            }

            if ($password !== $confirm_password) {
                throw new Exception('Passwords do not match');
            }

            if (strlen($password) < 8) {
                throw new Exception('Password must be at least 8 characters');
            }

            if (!preg_match("/[A-Z]/", $password)) {
                throw new Exception('Password must contain at least one uppercase letter');
            }

            if (!preg_match("/[0-9]/", $password)) {
                throw new Exception('Password must contain at least one number');
            }

            if (!preg_match("/[^A-Za-z0-9]/", $password)) {
                throw new Exception('Password must contain at least one special character');
            }

            $table = checkEmailExists($conn, $email);
            if (!$table) {
                throw new Exception('Email not found');
            }

            $hashed_password = $password;
            $stmt = $conn->prepare("UPDATE $table SET password = ? WHERE email = ?");
            $stmt->bind_param("ss", $hashed_password, $email);
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to update password');
            }
            $stmt->close();

            session_unset();
            session_destroy();
            echo json_encode(['success' => true]);
            break;

        default:
            throw new Exception('Invalid action');
    }

    $conn->close();
} catch (Exception $e) {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>