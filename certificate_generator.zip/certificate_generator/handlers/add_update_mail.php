<?php

if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    header('HTTP/1.1 403 Forbidden');
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Direct access attempt blocked to mail_credentials.php\n", FILE_APPEND);
    die('Access denied');
}

require_once '../assets/db_config.php';
require_once '../PHP_Extensions/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendCertificateEmail($conn, $action, $certificateData, $facultyId) {
    try {
        $facultyQuery = "SELECT name, email FROM faculty WHERE id = ?";
        $stmt = $conn->prepare($facultyQuery);
        $stmt->bind_param("i", $facultyId);
        $stmt->execute();
        $facultyResult = $stmt->get_result();
        $faculty = $facultyResult->fetch_assoc();
        $stmt->close();

        if (!$faculty) {
            throw new Exception("Faculty not found");
        }

        $eventQuery = "SELECT e.event_name, c.category_name 
                       FROM events e 
                       JOIN categories c ON e.category_id = c.id 
                       WHERE e.id = ?";
        $stmt = $conn->prepare($eventQuery);
        $stmt->bind_param("i", $certificateData['event_id']);
        $stmt->execute();
        $eventResult = $stmt->get_result();
        $eventData = $eventResult->fetch_assoc();
        $stmt->close();

        if (!$eventData) {
            throw new Exception("Event or category not found");
        }

        $verificationUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]/includes/view_certificate.php?ref=" . urlencode($certificateData['certificate_ref']);
        $certificateData['verification_url'] = $verificationUrl;

        $mail = new PHPMailer(true);
        
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'your_email_here';
        $mail->Password = 'your_mail_password_here';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom($faculty['email'], $faculty['name']);
        $mail->addAddress($certificateData['participant_email'], $certificateData['participant_name']);
        
        if ($action === 'add') {
            $mail->Subject = 'Congratulations! Your New Certificate Has Been Issued';
            $mail->Body = "
                <html>
                <head>
                    <style>
                        body {
                            font-family: 'Inter', Arial, sans-serif;
                            line-height: 1.6;
                            color: #353535;
                            margin: 0;
                            padding: 0;
                            background: #f7f7f7;
                        }
                        .container {
                            max-width: 600px;
                            margin: 0 auto;
                            padding: clamp(1rem, 2vw, 1.5rem);
                            background: #FFFFFF;
                            border-radius: 12px;
                            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
                            animation: fadeIn 0.8s ease;
                        }
                        .header {
                            background: linear-gradient(90deg, #FF6B01, #ff8c00);
                            color: #FFFFFF;
                            padding: clamp(1rem, 2vw, 1.5rem);
                            text-align: center;
                            border-radius: 12px 12px 0 0;
                        }
                        .header h2 {
                            font-size: clamp(1.2rem, 2.5vw, 1.5rem);
                            margin: 0;
                            font-weight: 600;
                        }
                        .content {
                            padding: clamp(1rem, 2.5vw, 1.5rem);
                            background: rgba(255, 255, 255, 0.95);
                            border: 1px solid rgba(0, 0, 0, 0.05);
                            border-radius: 0 0 12px 12px;
                        }
                        .content p {
                            font-size: clamp(0.85rem, 1.6vw, 0.95rem);
                            margin: clamp(0.5rem, 1vw, 0.75rem) 0;
                        }
                        .content ul {
                            list-style: none;
                            padding: 0;
                            margin: clamp(0.5rem, 1vw, 0.75rem) 0;
                        }
                        .content ul li {
                            font-size: clamp(0.85rem, 1.6vw, 0.95rem);
                            margin-bottom: clamp(0.3rem, 0.8vw, 0.5rem);
                            display: flex;
                            align-items: center;
                            gap: 0.5rem;
                        }
                        .content ul li::before {
                            content: '✓';
                            color: #FF6B01;
                            font-weight: bold;
                        }
                        .button {
                            display: inline-block;
                            padding: clamp(0.6rem, 1.5vw, 0.8rem) clamp(1.2rem, 3vw, 1.5rem);
                            background: linear-gradient(90deg, #FF6B01, #ff8c00);
                            color: #FFFFFF;
                            text-decoration: none;
                            border-radius: 25px;
                            font-size: clamp(0.8rem, 1.5vw, 0.9rem);
                            font-weight: 500;
                            text-align: center;
                            transition: all 0.3s ease;
                            margin: clamp(0.5rem, 1vw, 0.75rem) 0;
                        }
                        .button:hover {
                            background: linear-gradient(90deg, #e55e00, #FF6B01);
                            transform: translateY(-2px);
                            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
                        }
                        .footer {
                            text-align: center;
                            margin-top: clamp(1rem, 2vw, 1.5rem);
                            font-size: clamp(0.7rem, 1.4vw, 0.8rem);
                            color: #353535;
                            opacity: 0.65;
                        }
                        @keyframes fadeIn {
                            from { opacity: 0; transform: translateY(20px); }
                            to { opacity: 1; transform: translateY(0); }
                        }
                        @media (max-width: 600px) {
                            .container {
                                padding: clamp(0.8rem, 2vw, 1rem);
                            }
                            .header {
                                padding: clamp(0.8rem, 2vw, 1rem);
                            }
                            .header h2 {
                                font-size: clamp(1rem, 2vw, 1.2rem);
                            }
                            .content {
                                padding: clamp(0.8rem, 2vw, 1rem);
                            }
                            .content p, .content ul li {
                                font-size: clamp(0.8rem, 1.5vw, 0.9rem);
                            }
                            .button {
                                padding: clamp(0.5rem, 1.2vw, 0.6rem) clamp(1rem, 2.5vw, 1.2rem);
                                font-size: clamp(0.75rem, 1.4vw, 0.85rem);
                            }
                            .footer {
                                font-size: clamp(0.65rem, 1.3vw, 0.75rem);
                            }
                        }
                        @media (max-width: 480px) {
                            .container {
                                padding: clamp(0.6rem, 1.5vw, 0.8rem);
                            }
                            .content p, .content ul li {
                                font-size: clamp(0.75rem, 1.4vw, 0.85rem);
                            }
                            .button {
                                padding: clamp(0.4rem, 1vw, 0.5rem) clamp(0.8rem, 2vw, 1rem);
                                font-size: clamp(0.7rem, 1.3vw, 0.8rem);
                            }
                        }
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h2>E-Certificate System</h2>
                        </div>
                        <div class='content'>
                            <p>Dear {$certificateData['participant_name']},</p>
                            <p>We are delighted to inform you that you have been awarded a new certificate!</p>
                            <p><strong>Details of Your Certificate:</strong></p>
                            <ul>
                                <li><strong>Event:</strong> {$eventData['event_name']}</li>
                                <li><strong>Category:</strong> {$eventData['category_name']}</li>
                                <li><strong>Course:</strong> {$certificateData['course_name']}</li>
                                <li><strong>Certificate Reference:</strong> {$certificateData['certificate_ref']}</li>
                            </ul>
                            <p>This certificate was issued by <strong>{$faculty['name']}</strong> from our institution.</p>
                            <p>You can verify your certificate using the QR code provided with the certificate or by visiting the verification link below.</p>
                            <p style='text-align: center;'>
                                <a href='{$certificateData['verification_url']}' class='button'>Verify Certificate</a>
                            </p>
                            <p>Congratulations on your achievement!</p>
                            <p>Best regards,<br>E-Certificate System Team</p>
                        </div>
                        <div class='footer'>
                            <p>© " . date('Y') . " E-Certificate System. All rights reserved.</p>
                        </div>
                    </div>
                </body>
                </html>
            ";
        } else {
            $mail->Subject = 'Your Certificate Has Been Updated';
            $mail->Body = "
                <html>
                <head>
                    <style>
                        body {
                            font-family: 'Inter', Arial, sans-serif;
                            line-height: 1.6;
                            color: #353535;
                            margin: 0;
                            padding: 0;
                            background: #f7f7f7;
                        }
                        .container {
                            max-width: 600px;
                            margin: 0 auto;
                            padding: clamp(1rem, 2vw, 1.5rem);
                            background: #FFFFFF;
                            border-radius: 12px;
                            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
                            animation: fadeIn 0.8s ease;
                        }
                        .header {
                            background: linear-gradient(90deg, #FF6B01, #ff8c00);
                            color: #FFFFFF;
                            padding: clamp(1rem, 2vw, 1.5rem);
                            text-align: center;
                            border-radius: 12px 12px 0 0;
                        }
                        .header h2 {
                            font-size: clamp(1.2rem, 2.5vw, 1.5rem);
                            margin: 0;
                            font-weight: 600;
                        }
                        .content {
                            padding: clamp(1rem, 2.5vw, 1.5rem);
                            background: rgba(255, 255, 255, 0.95);
                            border: 1px solid rgba(0, 0, 0, 0.05);
                            border-radius: 0 0 12px 12px;
                        }
                        .content p {
                            font-size: clamp(0.85rem, 1.6vw, 0.95rem);
                            margin: clamp(0.5rem, 1vw, 0.75rem) 0;
                        }
                        .content ul {
                            list-style: none;
                            padding: 0;
                            margin: clamp(0.5rem, 1vw, 0.75rem) 0;
                        }
                        .content ul li {
                            font-size: clamp(0.85rem, 1.6vw, 0.95rem);
                            margin-bottom: clamp(0.3rem, 0.8vw, 0.5rem);
                            display: flex;
                            align-items: center;
                            gap: 0.5rem;
                        }
                        .content ul li::before {
                            content: '✓';
                            color: #FF6B01;
                            font-weight: bold;
                        }
                        .button {
                            display: inline-block;
                            padding: clamp(0.6rem, 1.5vw, 0.8rem) clamp(1.2rem, 3vw, 1.5rem);
                            background: linear-gradient(90deg, #FF6B01, #ff8c00);
                            color: #FFFFFF;
                            text-decoration: none;
                            border-radius: 25px;
                            font-size: clamp(0.8rem, 1.5vw, 0.9rem);
                            font-weight: 500;
                            text-align: center;
                            transition: all 0.3s ease;
                            margin: clamp(0.5rem, 1vw, 0.75rem) 0;
                        }
                        .button:hover {
                            background: linear-gradient(90deg, #e55e00, #FF6B01);
                            transform: translateY(-2px);
                            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
                        }
                        .footer {
                            text-align: center;
                            margin-top: clamp(1rem, 2vw, 1.5rem);
                            font-size: clamp(0.7rem, 1.4vw, 0.8rem);
                            color: #353535;
                            opacity: 0.65;
                        }
                        @keyframes fadeIn {
                            from { opacity: 0; transform: translateY(20px); }
                            to { opacity: 1; transform: translateY(0); }
                        }
                        @media (max-width: 600px) {
                            .container {
                                padding: clamp(0.8rem, 2vw, 1rem);
                            }
                            .header {
                                padding: clamp(0.8rem, 2vw, 1rem);
                            }
                            .header h2 {
                                font-size: clamp(1rem, 2vw, 1.2rem);
                            }
                            .content {
                                padding: clamp(0.8rem, 2vw, 1rem);
                            }
                            .content p, .content ul li {
                                font-size: clamp(0.8rem, 1.5vw, 0.9rem);
                            }
                            .button {
                                padding: clamp(0.5rem, 1.2vw, 0.6rem) clamp(1rem, 2.5vw, 1.2rem);
                                font-size: clamp(0.75rem, 1.4vw, 0.85rem);
                            }
                            .footer {
                                font-size: clamp(0.65rem, 1.3vw, 0.75rem);
                            }
                        }
                        @media (max-width: 480px) {
                            .container {
                                padding: clamp(0.6rem, 1.5vw, 0.8rem);
                            }
                            .content p, .content ul li {
                                font-size: clamp(0.75rem, 1.4vw, 0.85rem);
                            }
                            .button {
                                padding: clamp(0.4rem, 1vw, 0.5rem) clamp(0.8rem, 2vw, 1rem);
                                font-size: clamp(0.7rem, 1.3vw, 0.8rem);
                            }
                        }
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h2>E-Certificate System</h2>
                        </div>
                        <div class='content'>
                            <p>Dear {$certificateData['participant_name']},</p>
                            <p>We would like to inform you that your certificate has been updated.</p>
                            <p><strong>Updated Certificate Details:</strong></p>
                            <ul>
                                <li><strong>Event:</strong> {$eventData['event_name']}</li>
                                <li><strong>Category:</strong> {$eventData['category_name']}</li>
                                <li><strong>Course:</strong> {$certificateData['course_name']}</li>
                                <li><strong>Certificate Reference:</strong> {$certificateData['certificate_ref']}</li>
                            </ul>
                            <p>This update was performed by <strong>{$faculty['name']}</strong> from our institution.</p>
                            <p>You can verify your updated certificate using the QR code provided with the certificate or by visiting the verification link below.</p>
                            <p style='text-align: center;'>
                                <a href='{$certificateData['verification_url']}' class='button'>Verify Certificate</a>
                            </p>
                            <p>Thank you for your attention.</p>
                            <p>Best regards,<br>E-Certificate System Team</p>
                        </div>
                        <div class='footer'>
                            <p>© " . date('Y') . " E-Certificate System. All rights reserved.</p>
                        </div>
                    </div>
                </body>
                </html>
            ";
        }

        $mail->isHTML(true);

        $mail->send();
        error_log("Email sent successfully to {$certificateData['participant_email']} for $action");
        return true;
    } catch (Exception $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
        return false;
    }
}
?>