<?php
session_start();
require_once '../assets/db_config.php';

error_log("[login.php] Request received: " . json_encode($_POST));

$input = $_POST;
if (!isset($input['email']) || !isset($input['password']) || !isset($input['role'])) {
    error_log("[login.php] Error: Missing required fields");
    header("Location: ../index.php?error=" . urlencode("All fields are required"));
    exit;
}

$email = trim($input['email']);
$password = trim($input['password']);
$role = trim($input['role']);

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    error_log("[login.php] Error: Invalid email format: $email");
    header("Location: ../index.php?error=" . urlencode("Invalid email format"));
    exit;
}

if ($role === 'superadmin') {
    $stmt = $conn->prepare("SELECT id, email, password FROM super_admin WHERE email = ?");
} elseif ($role === 'faculty') {
    $stmt = $conn->prepare("SELECT id, email, password FROM faculty WHERE email = ?");
} elseif ($role === 'student') {
    $stmt = $conn->prepare("SELECT id, email, password FROM students WHERE email = ?");
} else {
    error_log("[login.php] Error: Invalid role: $role");
    header("Location: ../index.php?error=" . urlencode("Invalid role"));
    exit;
}

if (!$stmt) {
    error_log("[login.php] Error: SQL preparation failed: " . $conn->error);
    header("Location: ../index.php?error=" . urlencode("Internal server error"));
    exit;
}

$stmt->bind_param("s", $email);
if (!$stmt->execute()) {
    error_log("[login.php] Error: Query execution failed: " . $stmt->error);
    header("Location: ../index.php?error=" . urlencode("Internal server error"));
    exit;
}
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    error_log("[login.php] Error: Email not found: $email");
    header("Location: ../index.php?error=" . urlencode("Email not found"));
    exit;
}

$user = $result->fetch_assoc();

if ($password === $user['password']) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $role;
    $_SESSION['email'] = $email;
    $_SESSION['logged_in'] = true;

    error_log("[login.php] Session set: " . json_encode($_SESSION));

    $redirect_url = '';
    if ($role === 'superadmin') {
        $redirect_url = '../includes/register_faculty.php';
    } elseif ($role === 'faculty') {
        $redirect_url = '../includes/dashboard.php';
    } elseif ($role === 'student') {
        $redirect_url = '../includes/student_dashboard.php';
    }

    $full_path = realpath(__DIR__ . '/' . $redirect_url);
    error_log("[login.php] Redirect path: $full_path, Exists: " . (file_exists($full_path) ? 'Yes' : 'No'));

    if (!$full_path || !file_exists($full_path)) {
        error_log("[login.php] Error: Redirect file does not exist: $redirect_url");
        header("Location: ../index.php?error=" . urlencode("Redirect page not found"));
        exit;
    }

    error_log("[login.php] Success: Redirecting user: $email, Role: $role, URL: $redirect_url");

    header("HTTP/1.1 302 Found");
    header("Location: $redirect_url");
    header("Cache-Control: no-cache, must-revalidate");
    exit;
} else {
    error_log("[login.php] Error: Incorrect password for email: $email");
    header("Location: ../index.php?error=" . urlencode("Incorrect password"));
    exit;
}

$stmt->close();
$conn->close();
?>