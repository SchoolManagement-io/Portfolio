<?php
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error 404: Page Not Found</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: #f0f0f0;
            font-family: Arial, sans-serif;
            user-select: none;
        }

        .error-message {
            font-size: 2.5rem;
            color: #333;
            text-align: center;
            margin-bottom: 20px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .chicken-container {
            width: 100px;
            height: 100px;
            position: relative;
            overflow: hidden;
        }

        .chicken {
            width: 80px;
            height: 80px;
            position: absolute;
            top: -100px;
            left: 50%;
            transform: translateX(-50%);
            animation: fall 3s linear infinite;
            background: url('/images/chicken.png') no-repeat center;
            background-size: contain;
        }

        @keyframes fall {
            0% {
                top: -100px;
                transform: translateX(-50%) rotate(0deg);
            }
            100% {
                top: 100vh;
                transform: translateX(-50%) rotate(360deg);
            }
        }
    </style>
</head>
<body>
    <div class="error-message">Error 404: Page not found.</div>
    <div class="chicken-container">
        <div class="chicken"></div>
    </div>
</body>
</html>