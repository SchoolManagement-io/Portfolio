<?php
require_once '../assets/db_config.php';

$certificate_ref = isset($_GET['ref']) ? $_GET['ref'] : '';

if (empty($certificate_ref)) {
    echo "Invalid certificate reference";
    exit;
}

$sql = "SELECT c.*, e.event_name, cat.category_name 
        FROM certificates c
        JOIN events e ON c.event_id = e.id
        JOIN categories cat ON c.category_id = cat.id
        WHERE c.certificate_ref = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $certificate_ref);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Certificate not found";
    exit;
}

$certificate = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate Verification</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --primary: #FF6B01;
            --secondary: #FFFFFF;
            --dark: #353535;
            --shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 10px 20px rgba(0, 0, 0, 0.12);
            --border-radius: 12px;
            --border-radius-sm: 6px;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(145deg, #f7f7f7, #e8e8e8);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-user-drag: none;
            -webkit-touch-callout: none;
            overflow-x: hidden;
        }

        .container {
            max-width: 900px;
            margin: clamp(1.5rem, 5vw, 2.5rem) auto;
            padding: clamp(0.8rem, 2vw, 1.5rem);
            padding-bottom: clamp(3rem, 8vh, 4rem);
            width: 100%;
        }

        .certificate-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            backdrop-filter: blur(8px);
            padding: clamp(1.5rem, 4vw, 2.5rem);
            animation: fadeInUp 0.8s ease;
            position: relative;
            overflow: hidden;
        }

        .certificate-header {
            text-align: center;
            margin-bottom: clamp(1.5rem, 4vw, 2.5rem);
            padding-bottom: clamp(0.8rem, 2vw, 1rem);
            border-bottom: 3px solid var(--primary);
        }

        .certificate-title {
            color: var(--primary);
            font-size: clamp(1.5rem, 3vw, 1.8rem);
            font-weight: 700;
            margin: 0;
        }

        .certificate-subtitle {
            color: var(--dark);
            font-size: clamp(0.9rem, 1.8vw, 1rem);
            margin: clamp(0.4rem, 1vw, 0.5rem) 0 0;
            opacity: 0.7;
        }

        .verification-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: #16a34a;
            color: var(--secondary);
            padding: clamp(0.4rem, 1vw, 0.5rem) clamp(0.8rem, 2vw, 1rem);
            border-radius: 20px;
            font-size: clamp(0.75rem, 1.5vw, 0.9rem);
            font-weight: 500;
            margin-top: clamp(0.8rem, 2vw, 1rem);
            animation: scaleIn 0.6s ease;
        }

        .certificate-body {
            margin-bottom: clamp(1.5rem, 4vw, 2.5rem);
        }

        .certificate-field {
            display: flex;
            align-items: center;
            margin-bottom: clamp(0.8rem, 2vw, 1rem);
            padding-bottom: clamp(0.6rem, 1.5vw, 0.8rem);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            transition: var(--transition);
            will-change: transform, background;
        }

        .certificate-field:hover {
            background: #fff7ed;
            transform: translateY(-2px);
            border-radius: var(--border-radius-sm);
        }

        .field-label {
            font-weight: 600;
            width: clamp(120px, 25vw, 180px);
            color: var(--dark);
            font-size: clamp(0.85rem, 1.6vw, 0.95rem);
        }

        .field-value {
            flex: 1;
            color: var(--dark);
            font-size: clamp(0.85rem, 1.6vw, 0.95rem);
        }

        .field-value a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: var(--transition);
        }

        .field-value a:hover {
            color: #e55e00;
            text-decoration: underline;
        }

        .certificate-footer {
            text-align: center;
            color: var(--dark);
            font-size: clamp(0.75rem, 1.4vw, 0.85rem);
            margin-top: clamp(1.5rem, 4vw, 2rem);
            padding-top: clamp(0.8rem, 2vw, 1rem);
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            opacity: 0.7;
        }

        .certificate-ref {
            font-size: clamp(0.7rem, 1.3vw, 0.8rem);
            color: var(--dark);
            margin-top: clamp(0.4rem, 1vw, 0.5rem);
            font-style: italic;
            opacity: 0.65;
        }

        .action-buttons {
            text-align: center;
            margin-top: clamp(1.5rem, 4vw, 2rem);
            display: flex;
            justify-content: center;
            gap: clamp(0.5rem, 1.5vw, 1rem);
            flex-wrap: wrap;
        }

        .btn {
            padding: clamp(0.6rem, 1.5vw, 0.8rem) clamp(1.2rem, 3vw, 1.5rem);
            border-radius: 25px;
            font-weight: 500;
            font-size: clamp(0.8rem, 1.5vw, 0.9rem);
            border: none;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            min-height: 44px;
            min-width: 44px;
            text-decoration: none;
            will-change: transform, box-shadow;
        }

        .btn-primary {
            background: linear-gradient(90deg, var(--primary), #ff8c00);
            color: var(--secondary);
        }

        .btn-primary:hover {
            background: linear-gradient(90deg, #e55e00, var(--primary));
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .btn-secondary {
            background: #6b7280;
            color: var(--secondary);
        }

        .btn-secondary:hover {
            background: #4b5563;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: var(--secondary);
            text-align: center;
            padding: clamp(0.4rem, 1vw, 0.5rem);
            font-size: clamp(0.7rem, 1.4vw, 0.8rem);
            color: var(--dark);
            opacity: 0.65;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            z-index: 1000;
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes scaleIn {
            from {
                transform: scale(0.8);
                opacity: 0;
            }
            to {
                transform: scale(1);
                opacity: 1;
            }
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .container {
                padding: clamp(0.6rem, 1.5vw, 1rem);
            }

            .certificate-card {
                padding: clamp(1rem, 3vw, 1.5rem);
            }

            .certificate-title {
                font-size: clamp(1.4rem, 2.8vw, 1.6rem);
            }

            .certificate-subtitle {
                font-size: clamp(0.85rem, 1.6vw, 0.95rem);
            }

            .field-label,
            .field-value {
                font-size: clamp(0.8rem, 1.5vw, 0.9rem);
            }

            .btn {
                padding: clamp(0.5rem, 1.2vw, 0.7rem) clamp(1rem, 2.5vw, 1.2rem);
                font-size: clamp(0.75rem, 1.4vw, 0.85rem);
            }
        }

        @media (max-width: 768px) {
            .certificate-field {
                flex-direction: column;
                align-items: flex-start;
            }

            .field-label {
                width: 100%;
                margin-bottom: clamp(0.3rem, 0.8vw, 0.4rem);
            }

            .field-value {
                width: 100%;
            }

            .certificate-title {
                font-size: clamp(1.3rem, 2.5vw, 1.5rem);
            }

            .certificate-subtitle {
                font-size: clamp(0.8rem, 1.5vw, 0.9rem);
            }

            .verification-badge {
                font-size: clamp(0.7rem, 1.4vw, 0.85rem);
                padding: clamp(0.3rem, 0.8vw, 0.4rem) clamp(0.6rem, 1.5vw, 0.8rem);
            }

            .action-buttons {
                flex-direction: column;
                align-items: center;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }

        @media (max-width: 480px) {
            .container {
                margin: clamp(1rem, 3vw, 1.5rem) auto;
                padding: clamp(0.5rem, 1.2vw, 0.8rem);
            }

            .certificate-card {
                padding: clamp(0.8rem, 2vw, 1rem);
            }

            .certificate-title {
                font-size: clamp(1.2rem, 2.2vw, 1.3rem);
            }

            .certificate-subtitle {
                font-size: clamp(0.75rem, 1.4vw, 0.85rem);
            }

            .verification-badge {
                font-size: clamp(0.65rem, 1.3vw, 0.8rem);
            }

            .field-label,
            .field-value {
                font-size: clamp(0.75rem, 1.4vw, 0.85rem);
            }

            .certificate-footer {
                font-size: clamp(0.7rem, 1.3vw, 0.8rem);
            }

            .certificate-ref {
                font-size: clamp(0.65rem, 1.2vw, 0.75rem);
            }

            .btn {
                padding: clamp(0.4rem, 1vw, 0.6rem) clamp(0.8rem, 2vw, 1rem);
                font-size: clamp(0.7rem, 1.3vw, 0.8rem);
                min-height: 40px;
            }

            .footer {
                font-size: clamp(0.65rem, 1.2vw, 0.75rem);
            }
        }

        @media (max-width: 360px) {
            .certificate-title {
                font-size: clamp(1.1rem, 2vw, 1.2rem);
            }

            .field-label,
            .field-value {
                font-size: clamp(0.7rem, 1.3vw, 0.8rem);
            }

            .btn {
                font-size: clamp(0.65rem, 1.2vw, 0.75rem);
                min-height: 36px;
            }
        }

        /* Print Styles */
        @media print {
            body {
                background: var(--secondary);
                margin: 0;
                padding: 0;
            }

            .container {
                margin: 0;
                padding: 0;
                width: 100%;
            }

            .certificate-card {
                box-shadow: none;
                border: 1px solid var(--dark);
                padding: clamp(1rem, 2.5vw, 1.5rem);
                margin: 0;
                border-radius: 0;
                background: var(--secondary);
            }

            .certificate-header {
                border-bottom: 2px solid var(--primary);
            }

            .certificate-footer {
                border-top: 1px solid var(--dark);
            }

            .action-buttons {
                display: none;
            }

            .footer {
                display: none;
            }

            .certificate-field:hover {
                background: none;
                transform: none;
            }

            .btn {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="certificate-card">
            <div class="certificate-header">
                <h1 class="certificate-title">Certificate Verification</h1>
                <p class="certificate-subtitle">Allenhouse Group of Institutions</p>
                <div class="verification-badge"><i class="fas fa-check-circle"></i> VERIFIED</div>
            </div>
            
            <div class="certificate-body">
                <div class="certificate-field">
                    <div class="field-label">Participant Name:</div>
                    <div class="field-value"><?php echo htmlspecialchars($certificate['participant_name']); ?></div>
                </div>
                
                <div class="certificate-field">
                    <div class="field-label">CRN:</div>
                    <div class="field-value"><?php echo htmlspecialchars($certificate['participant_crn']); ?></div>
                </div>
                
                <div class="certificate-field">
                    <div class="field-label">Mobile Number:</div>
                    <div class="field-value"><?php echo htmlspecialchars($certificate['participant_mobile']); ?></div>
                </div>
                
                <div class="certificate-field">
                    <div class="field-label">Email:</div>
                    <div class="field-value"><?php echo htmlspecialchars($certificate['participant_email']); ?></div>
                </div>
                
                <div class="certificate-field">
                    <div class="field-label">Category:</div>
                    <div class="field-value"><?php echo htmlspecialchars($certificate['category_name']); ?></div>
                </div>
                
                <div class="certificate-field">
                    <div class="field-label">Event:</div>
                    <div class="field-value"><?php echo htmlspecialchars($certificate['event_name']); ?></div>
                </div>
                
                <div class="certificate-field">
                    <div class="field-label">Issue Date:</div>
                    <div class="field-value"><?php echo date('F j, Y', strtotime($certificate['created_at'])); ?></div>
                </div>
                
                <?php if (!empty($certificate['certificate_file'])): ?>
                <div class="certificate-field">
                    <div class="field-label">Certificate:</div>
                    <div class="field-value">
                        <a href="../certificates/<?php echo htmlspecialchars($certificate['certificate_file']); ?>" target="_blank">View Certificate</a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="certificate-footer">
                <p>This certificate has been verified as authentic by E Certificate System</p>
                <p class="certificate-ref">Certificate Reference: <?php echo htmlspecialchars($certificate['certificate_ref']); ?></p>
            </div>
        </div>
        
        <div class="action-buttons">
            <button onclick="printCertificate()" class="btn btn-primary"><i class="fas fa-print"></i> Print Certificate</button>
            <?php if (!empty($certificate['certificate_file'])): ?>
            <a href="../certificates/<?php echo htmlspecialchars($certificate['certificate_file']); ?>" download class="btn btn-secondary"><i class="fas fa-download"></i> Download Certificate</a>
            <?php endif; ?>
        </div>
    </div>

    <footer class="footer">
        Developed by Team GARUDA 🦅
    </footer>

    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());

        document.onkeydown = function(e) {
            if (
                e.keyCode == 123 || 
                (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) ||
                (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) || 
                (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) || 
                (e.ctrlKey && e.keyCode == 'S'.charCodeAt(0)) 
            ) {
                return false;
            }
        };

        document.addEventListener('selectstart', e => e.preventDefault());
        document.addEventListener('dragstart', e => e.preventDefault());

        setInterval(() => {
            const devtoolsOpen = window.outerWidth - window.innerWidth > 100;
            if (devtoolsOpen) {
                document.body.innerHTML = "<h1 style='text-align:center; margin-top:20%; color:red;'>Inspecting is not allowed!</h1>";
            }
        }, 1000);

        function printCertificate() {
            window.print();
        }

        document.querySelectorAll('.certificate-field').forEach(field => {
            field.addEventListener('mouseenter', () => {
                field.style.transform = 'translateY(-2px)';
            });
            field.addEventListener('mouseleave', () => {
                field.style.transform = 'translateY(0)';
            });
        });

        window.addEventListener('load', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    </script>
</body>
</html>