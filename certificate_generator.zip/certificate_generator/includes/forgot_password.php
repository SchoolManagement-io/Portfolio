<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - E Certificate System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --primary: #FF6B01;
            --secondary: #FFFFFF;
            --dark: #353535;
            --shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 10px 20px rgba(0, 0, 0, 0.12);
            --border-radius: 12px;
            --border-radius-sm: 6px;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(145deg, #f7f7f7, #e8e8e8);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 1.5rem;
            overflow-x: hidden;
            position: relative;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-user-drag: none;
            -webkit-touch-callout: none;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at 20% 30%, rgba(255, 107, 1, 0.1) 0%, transparent 30%),
                        radial-gradient(circle at 80% 70%, rgba(255, 107, 1, 0.1) 0%, transparent 30%);
            z-index: -1;
            animation: pulse 12s infinite ease-in-out;
        }

        .reset-container {
            max-width: 500px;
            width: 100%;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.95);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            backdrop-filter: blur(8px);
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.8s ease;
            margin-bottom: 3rem;
        }

        .reset-title {
            text-align: center;
            margin-bottom: 2rem;
        }

        .reset-title h1 {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
            animation: slideInDown 0.8s ease;
        }

        .reset-title p {
            font-size: 1rem;
            color: var(--dark);
            opacity: 0.65;
            margin-top: 0.5rem;
        }

        .form-section {
            display: none;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .form-section.active {
            display: block;
            opacity: 1;
            animation: fadeIn 0.6s ease;
        }

        .form-group {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .form-control {
            width: 100%;
            padding: 0.8rem 1rem 0.8rem 2.5rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: var(--border-radius-sm);
            font-size: 0.95rem;
            transition: var(--transition);
            background: #fafafa;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 107, 1, 0.1);
            outline: none;
        }

        .form-control.is-invalid {
            border-color: #dc2626;
        }

        .form-group i {
            position: absolute;
            left: 0.8rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--dark);
            opacity: 0.5;
            font-size: 0.9rem;
        }

        .password-toggle {
            position: absolute;
            right: 0.8rem;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--dark);
            opacity: 0.65;
            font-size: 0.9rem;
            transition: var(--transition);
        }

        .password-toggle:hover {
            opacity: 1;
        }

        .floating-label label {
            position: absolute;
            top: 50%;
            left: 2.5rem;
            transform: translateY(-50%);
            color: var(--dark);
            font-size: 0.95rem;
            opacity: 0.65;
            transition: var(--transition);
            pointer-events: none;
            background: transparent;
        }

        .floating-label.active label {
            top: -0.6rem;
            left: 1.2rem;
            font-size: 0.75rem;
            color: var(--primary);
            background: var(--secondary);
            padding: 0 0.2rem;
            opacity: 1;
        }

        .btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            padding: 0.9rem;
            background: linear-gradient(90deg, var(--primary), #ff8c00);
            color: var(--secondary);
            border: none;
            border-radius: var(--border-radius-sm);
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
            gap: 0.5rem;
            min-height: 48px;
        }

        .btn:hover {
            background: linear-gradient(90deg, #e55e00, var(--primary));
            transform: translateY(-3px);
            box-shadow: var(--shadow);
        }

        .btn:disabled {
            background: #cccccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .ripple-effect {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: scale(0);
            animation: ripple 0.6s linear;
        }

        .alert {
            padding: 1rem;
            border-radius: var(--border-radius-sm);
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
            font-weight: 400;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: slideInUp 0.5s ease;
        }

        .alert-success {
            background: #e6fffa;
            color: #2a9d8f;
        }

        .alert-danger {
            background: #ffe6e6;
            color: #dc2626;
        }

        .alert i {
            font-size: 1.1rem;
        }

        .spinner {
            display: inline-block;
            width: 24px;
            height: 24px;
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-top-color: var(--secondary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-right: 0.75rem;
        }

        .password-strength {
            display: flex;
            gap: 0.3rem;
            margin-top: 0.75rem;
        }

        .strength-bar {
            width: 20%;
            height: 5px;
            background: #e5e7eb;
            border-radius: 3px;
            transition: var(--transition);
        }

        .strength-bar.filled.weak {
            background: #dc2626;
        }

        .strength-bar.filled.medium {
            background: #f59e0b;
        }

        .strength-bar.filled.strong {
            background: #16a34a;
        }

        .password-feedback {
            font-size: 0.85rem;
            margin-top: 0.5rem;
            font-weight: 400;
        }

        .timer {
            text-align: center;
            font-size: 0.9rem;
            color: var(--dark);
            margin-top: 1rem;
            font-weight: 500;
            opacity: 0.75;
        }

        .text-danger {
            color: #dc2626;
        }

        .text-success {
            color: #16a34a;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: var(--secondary);
            text-align: center;
            padding: 0.5rem;
            font-size: 0.8rem;
            color: var(--dark);
            opacity: 0.65;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            z-index: 1000;
        }

        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes pulse {
            0%, 100% {
                opacity: 0.7;
            }
            50% {
                opacity: 1;
            }
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .reset-container {
                padding: 1.5rem;
            }

            .reset-title h1 {
                font-size: 1.8rem;
            }

            .reset-title p {
                font-size: 0.95rem;
            }

            .form-control {
                font-size: 0.9rem;
                padding: 0.75rem 1rem 0.75rem 2.3rem;
            }

            .form-group i {
                left: 0.7rem;
                font-size: 0.85rem;
            }

            .floating-label label {
                left: 2.3rem;
                font-size: 0.9rem;
            }

            .floating-label.active label {
                top: -0.5rem;
                left: 1rem;
                font-size: 0.7rem;
            }
        }

        @media (max-width: 768px) {
            .reset-container {
                padding: 1.2rem;
                max-width: 400px;
            }

            .reset-title h1 {
                font-size: 1.6rem;
            }

            .reset-title p {
                font-size: 0.9rem;
            }

            .form-control {
                font-size: 0.85rem;
                padding: 0.7rem 0.9rem 0.7rem 2.2rem;
            }

            .form-group i {
                left: 0.6rem;
                font-size: 0.8rem;
            }

            .floating-label label {
                left: 2.2rem;
                font-size: 0.85rem;
            }

            .floating-label.active label {
                top: -0.5rem;
                left: 0.9rem;
                font-size: 0.65rem;
            }

            .btn {
                padding: 0.8rem;
                font-size: 0.95rem;
                min-height: 44px;
            }

            .alert {
                font-size: 0.85rem;
                padding: 0.8rem;
            }

            .timer {
                font-size: 0.85rem;
            }

            .password-feedback {
                font-size: 0.8rem;
            }
        }

        @media (max-width: 480px) {
            .reset-container {
                padding: 1rem;
                max-width: 340px;
            }

            .reset-title h1 {
                font-size: 1.4rem;
            }

            .reset-title p {
                font-size: 0.85rem;
            }

            .form-control {
                font-size: 0.8rem;
                padding: 0.65rem 0.8rem 0.65rem 2rem;
            }

            .form-group i {
                left: 0.6rem;
                font-size: 0.75rem;
            }

            .floating-label label {
                left: 2rem;
                font-size: 0.8rem;
            }

            .floating-label.active label {
                top: -0.5rem;
                left: 0.8rem;
                font-size: 0.6rem;
            }

            .btn {
                padding: 0.7rem;
                font-size: 0.9rem;
                min-height: 40px;
            }

            .alert {
                font-size: 0.8rem;
                padding: 0.7rem;
            }

            .alert i {
                font-size: 1rem;
            }

            .spinner {
                width: 20px;
                height: 20px;
                border-width: 3px;
            }

            .password-strength {
                gap: 0.2rem;
            }

            .strength-bar {
                height: 4px;
            }

            .password-feedback {
                font-size: 0.75rem;
            }

            .timer {
                font-size: 0.8rem;
            }

            .footer {
                font-size: 0.7rem;
                padding: 0.4rem;
            }
        }
    </style>
</head>

<body>
    <div class="reset-container">
        <div class="reset-title">
            <h1>Forgot Password</h1>
            <p>Reset your password securely</p>
        </div>

        <div id="message-container"></div>

        <div class="form-section active" id="email-section">
            <form id="email-form" action="../handlers/forgot_password_handle.php" method="POST">
                <input type="hidden" name="action" value="send_otp">
                <div class="form-group floating-label">
                    <i class="fas fa-envelope"></i>
                    <input type="email" id="reset-email" name="email" class="form-control" required>
                    <label for="reset-email">Email</label>
                </div>
                <button type="submit" class="btn ripple"><i class="fas fa-arrow-right"></i> Next</button>
            </form>
        </div>

        <div class="form-section" id="otp-section">
            <form id="otp-form" action="../handlers/forgot_password_handle.php" method="POST">
                <input type="hidden" name="action" value="verify_otp">
                <input type="hidden" name="email" id="otp-email">
                <div class="form-group floating-label">
                    <i class="fas fa-lock"></i>
                    <input type="text" id="otp-input" name="otp" class="form-control" required maxlength="6" pattern="\d{6}" inputmode="numeric">
                    <label for="otp-input">Enter OTP</label>
                </div>
                <div class="timer" id="otp-timer">2:00</div>
                <button type="submit" class="btn ripple"><i class="fas fa-check"></i> Verify OTP</button>
            </form>
        </div>

        <div class="form-section" id="password-section">
            <form id="password-form" action="../handlers/forgot_password_handle.php" method="POST">
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="email" id="password-email">
                <div class="form-group floating-label">
                    <i class="fas fa-key"></i>
                    <input type="password" id="new-password" name="password" class="form-control" required>
                    <label for="new-password">New Password</label>
                    <i class="fas fa-eye password-toggle" onclick="togglePassword('new-password')"></i>
                </div>
                <div class="form-group floating-label">
                    <i class="fas fa-key"></i>
                    <input type="password" id="confirm-password" name="confirm_password" class="form-control" required>
                    <label for="confirm-password">Confirm Password</label>
                    <i class="fas fa-eye password-toggle" onclick="togglePassword('confirm-password')"></i>
                </div>
                <div class="password-strength"></div>
                <div class="password-feedback"></div>
                <button type="submit" class="btn ripple"><i class="fas fa-save"></i> Reset Password</button>
            </form>
        </div>
    </div>

    <footer class="footer">
        Developed by Team GARUDA 🦅
    </footer>

    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());

        document.onkeydown = function(e) {
            if (
                e.keyCode == 123 || 
                (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) || 
                (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) || 
                (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) || 
                (e.ctrlKey && e.keyCode == 'S'.charCodeAt(0)) 
            ) {
                return false;
            }
        };

        document.addEventListener('selectstart', e => e.preventDefault());
        document.addEventListener('dragstart', e => e.preventDefault());

        setInterval(() => {
            const devtoolsOpen = window.outerWidth - window.innerWidth > 100;
            if (devtoolsOpen) {
                document.body.innerHTML = "<h1 style='text-align:center; margin-top:20%; color:red;'>Inspecting is not allowed!</h1>";
            }
        }, 1000);

        let isSubmitting = false;
        let timerInterval;
        const FORM_ACTION_URL = '../handlers/forgot_password_handle.php';

        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const toggle = input.nextElementSibling;
            if (input.type === 'password') {
                input.type = 'text';
                toggle.classList.remove('fa-eye');
                toggle.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                toggle.classList.remove('fa-eye-slash');
                toggle.classList.add('fa-eye');
            }
        }

        function showNotification(message, type = 'info') {
            const messageContainer = document.getElementById('message-container');
            messageContainer.innerHTML = `<div class="alert alert-${type}"><i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}</div>`;
            setTimeout(() => {
                const alert = messageContainer.querySelector('.alert');
                if (alert) {
                    alert.style.opacity = '0';
                    setTimeout(() => {
                        messageContainer.innerHTML = '';
                    }, 300);
                }
            }, 5000);
        }

        function startTimer() {
            const timerElement = document.getElementById('otp-timer');
            let timeLeft = 120;

            clearInterval(timerInterval);
            timerInterval = setInterval(() => {
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
                
                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    timerElement.textContent = 'OTP Expired';
                    timerElement.classList.add('text-danger');
                    showNotification('OTP has expired', 'danger');
                    switchSection('email-section');
                }
                timeLeft--;
            }, 1000);
        }

        function switchSection(sectionId) {
            if (isSubmitting) return;
            const sections = document.querySelectorAll('.form-section');
            sections.forEach(section => {
                if (section.classList.contains('active')) {
                    section.style.transition = 'opacity 0.3s';
                    section.style.opacity = '0';
                    setTimeout(() => {
                        section.classList.remove('active');
                        section.style.display = 'none';
                        const newSection = document.getElementById(sectionId);
                        newSection.style.display = 'block';
                        newSection.classList.add('active');
                        setTimeout(() => {
                            newSection.style.opacity = '1';
                            const firstInput = newSection.querySelector('input:not([type=hidden])');
                            if (firstInput) firstInput.focus();
                            if (sectionId === 'otp-section') {
                                startTimer();
                            } else {
                                clearInterval(timerInterval);
                            }
                        }, 50);
                    }, 300);
                }
            });
        }

        function validateFormAction(form) {
            if (form.action !== FORM_ACTION_URL) {
                console.error(`Invalid form action detected: ${form.action}`);
                form.action = FORM_ACTION_URL;
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.floating-label input:not([type=hidden])').forEach(input => {
                input.addEventListener('focus', () => {
                    input.parentElement.classList.add('active');
                });
                input.addEventListener('blur', () => {
                    if (!input.value) {
                        input.parentElement.classList.remove('active');
                    }
                });
                if (input.value) {
                    input.parentElement.classList.add('active');
                }
            });

            document.querySelectorAll('.ripple').forEach(button => {
                button.addEventListener('click', function(e) {
                    if (this.disabled) return;
                    const x = e.clientX - e.target.getBoundingClientRect().left;
                    const y = e.clientY - e.target.getBoundingClientRect().top;
                    const ripple = document.createElement('span');
                    ripple.classList.add('ripple-effect');
                    ripple.style.left = `${x}px`;
                    ripple.style.top = `${y}px`;
                    this.appendChild(ripple);
                    setTimeout(() => ripple.remove(), 600);
                });
            });

            const emailForm = document.getElementById('email-form');
            if (emailForm) {
                emailForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    if (isSubmitting) return;
                    isSubmitting = true;

                    validateFormAction(emailForm);
                    console.log('Email form submitting to:', emailForm.action);

                    const emailInput = document.getElementById('reset-email');
                    if (!emailInput.value.trim()) {
                        emailInput.classList.add('is-invalid');
                        showNotification('Please enter your email', 'danger');
                        isSubmitting = false;
                        return;
                    }

                    const formData = new FormData(this);
                    const submitBtn = this.querySelector('button[type="submit"]');
                    const originalText = submitBtn.innerHTML;
                    submitBtn.innerHTML = '<span class="spinner"></span> Processing...';
                    submitBtn.disabled = true;

                    try {
                        const response = await fetch(FORM_ACTION_URL, {
                            method: 'POST',
                            body: formData
                        });

                        const data = await response.json();
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                        isSubmitting = false;

                        if (data.success) {
                            showNotification(`OTP sent to ${data.email}`, 'success');
                            document.getElementById('otp-email').value = data.email;
                            switchSection('otp-section');
                            emailForm.reset();
                            emailForm.querySelectorAll('.floating-label').forEach(label => {
                                label.classList.remove('active');
                            });
                        } else {
                            showNotification(data.message || 'An error occurred', 'danger');
                        }
                    } catch (error) {
                        console.error('Fetch Error:', error);
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                        isSubmitting = false;
                        showNotification('An error occurred. Please try again.', 'danger');
                    }
                });
            }

            const otpForm = document.getElementById('otp-form');
            const otpInput = document.getElementById('otp-input');
            if (otpForm && otpInput) {
                otpInput.addEventListener('input', function() {
                    this.value = this.value.replace(/\D/g, '');
                    if (this.value.length === 6) {
                        otpForm.dispatchEvent(new Event('submit'));
                    }
                });

                otpForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    if (isSubmitting) return;
                    isSubmitting = true;

                    validateFormAction(otpForm);
                    console.log('OTP form submitting to:', otpForm.action);

                    const formData = new FormData(this);
                    const submitBtn = this.querySelector('button[type="submit"]');
                    const originalText = submitBtn.innerHTML;
                    submitBtn.innerHTML = '<span class="spinner"></span> Processing...';
                    submitBtn.disabled = true;

                    try {
                        const response = await fetch(FORM_ACTION_URL, {
                            method: 'POST',
                            body: formData
                        });

                        const data = await response.json();
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                        isSubmitting = false;

                        if (data.success) {
                            clearInterval(timerInterval);
                            showNotification('OTP verified successfully', 'success');
                            document.getElementById('password-email').value = document.getElementById('otp-email').value;
                            switchSection('password-section');
                            otpForm.reset();
                            otpForm.querySelectorAll('.floating-label').forEach(label => {
                                label.classList.remove('active');
                            });
                        } else {
                            showNotification(data.message || 'Invalid OTP', 'danger');
                        }
                    } catch (error) {
                        console.error('Fetch Error:', error);
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                        isSubmitting = false;
                        showNotification('An error occurred. Please try again.', 'danger');
                    }
                });
            }

            const passwordForm = document.getElementById('password-form');
            const passwordInput = document.getElementById('new-password');
            const confirmInput = document.getElementById('confirm-password');
            const feedbackDiv = document.querySelector('.password-feedback');
            const strengthDiv = document.querySelector('.password-strength');

            if (passwordForm && passwordInput && confirmInput) {
                function validatePassword() {
                    if (passwordInput.value !== confirmInput.value) {
                        feedbackDiv.innerHTML = 'Passwords do not match';
                        feedbackDiv.classList.add('text-danger');
                        feedbackDiv.classList.remove('text-success');
                        return false;
                    } else if (passwordInput.value.length < 8) {
                        feedbackDiv.innerHTML = 'Password must be at least 8 characters';
                        feedbackDiv.classList.add('text-danger');
                        feedbackDiv.classList.remove('text-success');
                        return false;
                    } else if (!/[A-Z]/.test(passwordInput.value)) {
                        feedbackDiv.innerHTML = 'Password must contain at least one uppercase letter';
                        feedbackDiv.classList.add('text-danger');
                        feedbackDiv.classList.remove('text-success');
                        return false;
                    } else if (!/[0-9]/.test(passwordInput.value)) {
                        feedbackDiv.innerHTML = 'Password must contain at least one number';
                        feedbackDiv.classList.add('text-danger');
                        feedbackDiv.classList.remove('text-success');
                        return false;
                    } else if (!/[^A-Za-z0-9]/.test(passwordInput.value)) {
                        feedbackDiv.innerHTML = 'Password must contain at least one special character';
                        feedbackDiv.classList.add('text-danger');
                        feedbackDiv.classList.remove('text-success');
                        return false;
                    } else {
                        feedbackDiv.innerHTML = 'Passwords match';
                        feedbackDiv.classList.remove('text-danger');
                        feedbackDiv.classList.add('text-success');
                        return true;
                    }
                }

                function checkPasswordStrength(password) {
                    let strength = 0;
                    if (password.length >= 8) strength += 1;
                    if (password.length >= 12) strength += 1;
                    if (/[A-Z]/.test(password)) strength += 1;
                    if (/[0-9]/.test(password)) strength += 1;
                    if (/[^A-Za-z0-9]/.test(password)) strength += 1;

                    strengthDiv.innerHTML = '';
                    for (let i = 0; i < 5; i++) {
                        const span = document.createElement('span');
                        if (i < strength) {
                            span.classList.add('strength-bar', 'filled');
                            if (strength <= 2) span.classList.add('weak');
                            else if (strength <= 4) span.classList.add('medium');
                            else span.classList.add('strong');
                        } else {
                            span.classList.add('strength-bar');
                        }
                        strengthDiv.appendChild(span);
                    }
                }

                passwordInput.addEventListener('input', function() {
                    checkPasswordStrength(this.value);
                    if (confirmInput.value) validatePassword();
                });

                confirmInput.addEventListener('input', validatePassword);

                passwordForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    if (isSubmitting) return;
                    isSubmitting = true;

                    validateFormAction(passwordForm);
                    console.log('Password form submitting to:', passwordForm.action);

                    if (!validatePassword()) {
                        showNotification('Please correct the errors in the form', 'danger');
                        isSubmitting = false;
                        return;
                    }

                    const formData = new FormData(this);
                    const submitBtn = this.querySelector('button[type="submit"]');
                    const originalText = submitBtn.innerHTML;
                    submitBtn.innerHTML = '<span class="spinner"></span> Processing...';
                    submitBtn.disabled = true;

                    try {
                        const response = await fetch(FORM_ACTION_URL, {
                            method: 'POST',
                            body: formData
                        });

                        const data = await response.json();
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                        isSubmitting = false;

                        if (data.success) {
                            showNotification('Password reset successfully', 'success');
                            setTimeout(() => {
                                window.location.href = '../index.php';
                            }, 2000);
                        } else {
                            showNotification(data.message || 'An error occurred', 'danger');
                        }
                    } catch (error) {
                        console.error('Fetch Error:', error);
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                        isSubmitting = false;
                        showNotification('An error occurred. Please try again.', 'danger');
                    }
                });
            }
        });
    </script>
</body>
</html>