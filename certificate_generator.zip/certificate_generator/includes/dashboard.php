<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../index.html");
    exit;
}

if ($_SESSION['role'] !== 'faculty') {
    header("Location: ../index.html");
    exit;
}

require_once '../assets/db_config.php';

$userRole = $_SESSION['role'];
$userId = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard - E Certificate System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        :root {
            --primary: #FF6B01;
            --secondary: #FFFFFF;
            --dark: #353535;
            --shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 10px 20px rgba(0, 0, 0, 0.12);
            --border-radius: 12px;
            --border-radius-sm: 6px;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(145deg, #f7f7f7, #e8e8e8);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            color: var(--dark);
            line-height: 1.6;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-user-drag: none;
            -webkit-touch-callout: none;
        }

        .app-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            box-shadow: var(--shadow);
            padding: 1rem;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1.5rem;
            width: 100%;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .app-logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .app-logo h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary);
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            transition: var(--transition);
            overflow: hidden;
        }

        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .app-logo:hover .logo-icon {
            transform: scale(1.1);
        }

        .app-nav {
            display: flex;
            gap: 0.75rem;
            flex-wrap: wrap;
            justify-content: center;
        }

        .nav-link {
            text-decoration: none;
            color: var(--dark);
            font-weight: 500;
            padding: 0.6rem 1rem;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            font-size: 0.95rem;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--primary);
            color: var(--secondary);
            box-shadow: var(--shadow);
            transform: translateY(-2px);
            text-decoration: none;
        }

        .logout {
            background: var(--primary);
            color: var(--secondary);
        }

        .logout:hover {
            background: #e55e00;
            text-decoration: none;
        }

        .dashboard-container {
            display: flex;
            flex-direction: column;
            gap: 2rem;
            margin-top: 1.5rem;
        }

        .card {
            background: var(--secondary);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: var(--transition);
            animation: fadeInUp 0.6s ease forwards;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .card-header {
            background: linear-gradient(90deg, var(--primary), #ff8c00);
            color: var(--secondary);
            padding: 1rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .card-header h2 {
            font-size: 1.5rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: 1.5rem;
        }

        .row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1rem;
        }

        .form-group {
            position: relative;
            margin-bottom: 1.2rem;
        }

        .form-control {
            width: 100%;
            padding: 0.75rem 1rem 0.75rem 2.5rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: var(--border-radius-sm);
            font-size: 0.9rem;
            transition: var(--transition);
            background: #fafafa;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 107, 1, 0.1);
            outline: none;
        }

        .form-control[readonly] {
            background: #f0f0f0;
            cursor: not-allowed;
        }

        .form-group i {
            position: absolute;
            left: 0.8rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--dark);
            opacity: 0.5;
            font-size: 0.9rem;
        }

        .form-group label {
            position: absolute;
            top: 50%;
            left: 2.5rem;
            transform: translateY(-50%);
            font-size: 0.9rem;
            color: var(--dark);
            opacity: 0.65;
            transition: var(--transition);
            pointer-events: none;
            background: transparent;
        }

        .form-control:focus + label,
        .form-control:not(:placeholder-shown) + label {
            top: -0.6rem;
            left: 1.2rem;
            font-size: 0.7rem;
            color: var(--primary);
            background: var(--secondary);
            padding: 0 0.2rem;
            opacity: 1;
        }

        .file-info {
            font-size: 0.8rem;
            color: var(--dark);
            opacity: 0.65;
            margin-top: 0.3rem;
            display: block;
            word-break: break-all;
        }

        .file-info.has-file {
            color: var(--primary);
            opacity: 1;
        }

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .btn {
            padding: 0.75rem 1.25rem;
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            font-size: 0.9rem;
            position: relative;
            overflow: hidden;
            text-decoration: none !important;
            min-height: 44px;
        }

        .btn:hover,
        .btn:focus {
            text-decoration: none !important;
        }

        .btn-primary {
            background: var(--primary);
            color: var(--secondary);
        }

        .btn-primary:hover {
            background: #e55e00;
            transform: scale(1.05);
            box-shadow: var(--shadow);
        }

        .btn-danger {
            background: #dc2626;
            color: var(--secondary);
        }

        .btn-danger:hover {
            background: #b91c1c;
            transform: scale(1.05);
            box-shadow: var(--shadow);
        }

        .btn-secondary {
            background: var(--dark);
            color: var(--secondary);
        }

        .btn-secondary:hover {
            background: #2a2a2a;
            transform: scale(1.05);
            box-shadow: var(--shadow);
        }

        .btn-success {
            background: #16a34a;
            color: var(--secondary);
        }

        .btn-success:hover {
            background: #15803d;
            transform: scale(1.05);
            box-shadow: var(--shadow);
        }

        .btn-warning {
            background: #f59e0b;
            color: var(--secondary);
        }

        .btn-warning:hover {
            background: #d97706;
            transform: scale(1.05);
            box-shadow: var(--shadow);
        }

        .btn-generate {
            background: #16a34a;
            color: var(--secondary);
            padding: 0.6rem 1rem;
        }

        .btn-generate:hover {
            background: #15803d;
            transform: scale(1.05);
            box-shadow: var(--shadow);
        }

        .btn-sm {
            padding: 0.5rem 0.75rem;
            font-size: 0.8rem;
            min-height: 36px;
        }

        .ripple-effect {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: scale(0);
            animation: ripple 0.5s linear;
        }

        @keyframes ripple {
            to {
                transform: scale(3);
                opacity: 0;
            }
        }

        .filter-container {
            padding: 1rem;
            background: #fafafa;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .filter-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 1rem;
        }

        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            table-layout: auto;
        }

        .table th,
        .table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            vertical-align: middle;
        }

        .table th {
            background: var(--primary);
            color: var(--secondary);
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
            white-space: nowrap;
        }

        .table tr {
            transition: var(--transition);
        }

        .table tr:nth-child(even) {
            background: #f5f5f5;
        }

        .table tr:hover {
            background: #fff;
            box-shadow: var(--shadow);
        }

        .table-action-buttons {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .table-action-buttons a,
        .table-action-buttons button {
            text-decoration: none !important;
        }

        .badge-danger {
            background: #dc2626;
            color: var(--secondary);
            padding: 0.3rem 0.5rem;
            border-radius: var(--border-radius-sm);
            font-size: 0.8rem;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 1001;
            animation: fadeIn 0.3s ease;
        }

        .modal-content {
            background: var(--secondary);
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 1rem;
            width: 90%;
            max-width: 400px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            animation: slideInUp 0.4s ease;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            padding-bottom: 0.75rem;
        }

        .modal-header h3 {
            font-size: 1.1rem;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .close-modal {
            background: none;
            border: none;
            font-size: 1.2rem;
            cursor: pointer;
            color: var(--dark);
            opacity: 0.65;
            transition: var(--transition);
        }

        .close-modal:hover {
            opacity: 1;
        }

        .modal-body {
            padding: 1rem 0;
            text-align: center;
        }

        .qr-container img {
            max-width: 100%;
            width: 200px;
            height: auto;
            margin-bottom: 1rem;
            border-radius: var(--border-radius-sm);
            box-shadow: var(--shadow);
        }

        .qr-actions {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
            justify-content: center;
            margin-bottom: 1rem;
        }

        .qr-actions a {
            text-decoration: none !important;
        }

        .qr-instructions {
            font-size: 0.85rem;
            color: var(--dark);
            opacity: 0.75;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: var(--secondary);
            text-align: center;
            padding: 0.5rem;
            font-size: 0.8rem;
            color: var(--dark);
            opacity: 0.65;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            z-index: 1000;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes highlight {
            0% { background: #fff3e0; }
            100% { background: inherit; }
        }

        @keyframes updateHighlight {
            0% { background: #ffedd5; }
            100% { background: inherit; }
        }

        .highlight-animation {
            animation: highlight 1s ease;
        }

        .update-animation {
            animation: updateHighlight 1s ease;
        }

        .form-group.file-group {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        /* Responsive Table Card Layout */
        @media (max-width: 480px) {
            .table-responsive {
                overflow-x: hidden;
            }

            .table {
                display: block;
            }

            .table thead {
                display: none;
            }

            .table tbody {
                display: block;
            }

            .table tr {
                display: block;
                margin-bottom: 1rem;
                background: var(--secondary);
                border-radius: var(--border-radius-sm);
                box-shadow: var(--shadow);
                padding: 1rem;
            }

            .table tr:hover {
                background: #fff;
            }

            .table td {
                display: block;
                text-align: left;
                padding: 0.5rem 0;
                border: none;
                position: relative;
            }

            .table td:before {
                content: attr(data-label);
                font-weight: 600;
                color: var(--primary);
                display: inline-block;
                width: 40%;
                padding-right: 0.5rem;
            }

            .table td:not(:first-child):not(:last-child):not(:nth-child(2)):not(:nth-child(5)) {
                display: none;
            }

            .table-action-buttons {
                justify-content: flex-start;
                gap: 0.5rem;
            }

            .table td:last-child {
                display: flex;
                flex-wrap: wrap;
            }
        }

        /* Media Queries */
        @media (max-width: 1024px) {
            .container {
                padding: 1rem;
            }

            .app-logo h1 {
                font-size: 1.6rem;
            }

            .card-header h2 {
                font-size: 1.4rem;
            }

            .row {
                grid-template-columns: 1fr;
            }

            .form-control {
                font-size: 0.85rem;
                padding: 0.7rem 1rem 0.7rem 2.3rem;
            }

            .form-group i {
                left: 0.7rem;
                font-size: 0.85rem;
            }

            .form-group label {
                left: 2.3rem;
                font-size: 0.85rem;
            }

            .form-control:focus + label,
            .form-control:not(:placeholder-shown) + label {
                top: -0.5rem;
                left: 1rem;
                font-size: 0.65rem;
            }

            .logo-icon {
                width: 36px;
                height: 36px;
            }
        }

        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                align-items: center;
            }

            .app-nav {
                flex-direction: column;
                align-items: center;
                gap: 0.5rem;
            }

            .nav-link {
                padding: 0.5rem 0.8rem;
                font-size: 0.9rem;
            }

            .card-header {
                flex-direction: column;
                align-items: flex-start;
                padding: 0.8rem 1rem;
            }

            .card-header h2 {
                font-size: 1.3rem;
            }

            .card-body {
                padding: 1rem;
            }

            .form-actions {
                flex-direction: column;
                align-items: stretch;
            }

            .btn {
                padding: 0.6rem 1rem;
                font-size: 0.85rem;
                width: 100%;
                justify-content: center;
            }

            .btn-sm {
                padding: 0.4rem 0.6rem;
                font-size: 0.75rem;
            }

            .filter-row {
                grid-template-columns: 1fr;
            }

            .filter-container {
                padding: 0.8rem;
            }

            .table th,
            .table td {
                font-size: 0.8rem;
                padding: 0.6rem;
            }

            .modal-content {
                max-width: 350px;
                padding: 0.8rem;
            }

            .modal-header h3 {
                font-size: 1rem;
            }

            .qr-container img {
                width: 150px;
            }

            .logo-icon {
                width: 34px;
                height: 34px;
            }
        }

        @media (max-width: 480px) {
            .app-logo h1 {
                font-size: 1.4rem;
            }

            .logo-icon {
                width: 32px;
                height: 32px;
            }

            .card-header h2 {
                font-size: 1.2rem;
            }

            .form-control {
                font-size: 0.8rem;
                padding: 0.6rem 0.8rem 0.6rem 2rem;
            }

            .form-group i {
                left: 0.6rem;
                font-size: 0.8rem;
            }

            .form-group label {
                left: 2rem;
                font-size: 0.8rem;
            }

            .form-control:focus + label,
            .form-control:not(:placeholder-shown) + label {
                top: -0.5rem;
                left: 0.8rem;
                font-size: 0.6rem;
            }

            .file-info {
                font-size: 0.75rem;
            }

            .btn {
                padding: 0.5rem 0.8rem;
                font-size: 0.8rem;
            }

            .footer {
                font-size: 0.7rem;
                padding: 0.4rem;
            }

            .modal-content {
                max-width: 300px;
                padding: 0.6rem;
            }

            .modal-header h3 {
                font-size: 0.9rem;
            }

            .qr-container img {
                width: 120px;
            }

            .qr-instructions {
                font-size: 0.75rem;
            }
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="container">
            <div class="header-content">
                <div class="app-logo">
                    <div class="logo-icon"><img src="../images/logo.png" alt="E Certificate Logo"></div>
                    <h1>E Certificates</h1>
                </div>
                <nav class="app-nav">
                    <a href="dashboard.php" class="nav-link active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                    <a href="category.php" class="nav-link"><i class="fas fa-list"></i> Categories & Events</a>
                    <a href="../handlers/logout.php" class="nav-link logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
        </div>
    </header>
    
    <main class="container dashboard-container">
        <div class="card">
            <div class="card-header">
                <div style="display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;">
                    <h2 id="form-title"><i class="fas fa-certificate"></i> Add Certificate</h2>
                    <div class="form-group">
                        <i class="fas fa-file-alt"></i>
                        <select id="template_id" name="template_id" class="form-control" required>
                            <option value="">Select Template</option>
                            <?php
                            $templateQuery = "SELECT id, template_name FROM certificate_templates ORDER BY template_name";
                            $templateResult = mysqli_query($conn, $templateQuery);
                            if ($templateResult && mysqli_num_rows($templateResult) > 0) {
                                while ($template = mysqli_fetch_assoc($templateResult)) {
                                    echo "<option value='" . $template['id'] . "'>" . htmlspecialchars($template['template_name']) . "</option>";
                                }
                            }
                            ?>
                        </select>
                        <label for="template_id">Certificate Template</label>
                    </div>
                </div>
                <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
                    <button id="import-btn" class="btn btn-success"><i class="fas fa-file-import"></i> Import</button>
                    <button id="export-btn" class="btn btn-warning"><i class="fas fa-file-export"></i> Export</button>
                </div>
            </div>
            <div class="card-body">
                <form id="certificate-form" method="post" enctype="multipart/form-data">
                    <input type="hidden" id="edit_mode" name="edit_mode" value="0">
                    <input type="hidden" name="created_by" value="<?php echo $userId; ?>">
                    <input type="hidden" id="id_field" name="id">
                    <input type="hidden" id="hidden_template_id" name="template_id">
                    
                    <div class="row">
                        <div class="form-group">
                            <i class="fas fa-user"></i>
                            <input type="text" id="participant_name" name="participant_name" class="form-control" placeholder=" " required>
                            <label for="participant_name">Participant Name</label>
                        </div>
                        <div class="form-group">
                            <i class="fas fa-id-card"></i>
                            <input type="text" id="participant_crn" name="participant_crn" class="form-control" placeholder=" " required>
                            <label for="participant_crn">CRN</label>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="form-group">
                            <i class="fas fa-phone"></i>
                            <input type="text" id="participant_mobile" name="participant_mobile" class="form-control" placeholder=" " required>
                            <label for="participant_mobile">Mobile</label>
                        </div>
                        <div class="form-group">
                            <i class="fas fa-envelope"></i>
                            <input type="email" id="participant_email" name="participant_email" class="form-control" placeholder=" " required>
                            <label for="participant_email">Email</label>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="form-group">
                            <i class="fas fa-graduation-cap"></i>
                            <select id="course_name" name="course_name" class="form-control" required>
                                <option value="">Select Course</option>
                                <option value="BCA">BCA</option>
                                <option value="BBA">BBA</option>
                                <option value="B.Tech">B.Tech</option>
                                <option value="MBA">MBA</option>
                            </select>
                            <label for="course_name">Course Name</label>
                        </div>
                        <div class="form-group">
                            <i class="fas fa-folder"></i>
                            <select id="category_id" name="category_id" class="form-control" required>
                                <option value="">Select Category</option>
                                <?php
                                $categoryQuery = "SELECT id, category_name FROM categories ORDER BY category_name";
                                $categoryResult = mysqli_query($conn, $categoryQuery);
                                if ($categoryResult && mysqli_num_rows($categoryResult) > 0) {
                                    while ($category = mysqli_fetch_assoc($categoryResult)) {
                                        echo "<option value='" . $category['id'] . "'>" . htmlspecialchars($category['category_name']) . "</option>";
                                    }
                                }
                                ?>
                            </select>
                            <label for="category_id">Category</label>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="form-group">
                            <i class="fas fa-calendar-check"></i>
                            <select id="event_id" name="event_id" class="form-control" required disabled>
                                <option value="">Select Event</option>
                            </select>
                            <label for="event_id">Event</label>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="form-group">
                            <i class="fas fa-barcode"></i>
                            <input type="text" id="certificate_ref" name="certificate_ref" class="form-control" placeholder=" " required readonly>
                            <label for="certificate_ref">Certificate Reference</label>
                        </div>
                        <div class="form-group file-group">
                            <i class="fas fa-file-upload"></i>
                            <input type="file" id="certificate_file" name="certificate_file" class="form-control" accept=".pdf,.jpg,.jpeg,.png">
                            <label for="certificate_file">Certificate File <small>(Optional)</small></label>
                            <button type="button" id="generate-btn" class="btn-generate" style="display: none;"><i class="fas fa-file-pdf"></i> Generate</button>
                            <span id="file-info" class="file-info">No file chosen</span>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" id="submit-btn" class="btn btn-primary"><i class="fas fa-save"></i> Submit</button>
                        <button type="button" id="cancel-btn" class="btn btn-danger" style="display: none;"><i class="fas fa-times"></i> Cancel</button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-list-ul"></i> Certificates List</h2>
            </div>
            <div class="filter-container">
                <div class="filter-row">
                    <div class="form-group">
                        <i class="fas fa-filter"></i>
                        <select id="filter_status" class="form-control">
                            <option value="">All Certificates</option>
                            <option value="with_certificate">Students with Certificates</option>
                            <option value="without_certificate">Students without Certificates</option>
                        </select>
                        <label for="filter_status">Certificate Status</label>
                    </div>
                    <div class="form-group">
                        <i class="fas fa-file-alt"></i>
                        <select id="filter_template" class="form-control">
                            <option value="">All Templates</option>
                            <?php
                            $templateQuery = "SELECT id, template_name FROM certificate_templates ORDER BY template_name";
                            $templateResult = mysqli_query($conn, $templateQuery);
                            if ($templateResult && mysqli_num_rows($templateResult) > 0) {
                                while ($template = mysqli_fetch_assoc($templateResult)) {
                                    echo "<option value='" . $template['id'] . "'>" . htmlspecialchars($template['template_name']) . "</option>";
                                }
                            }
                            ?>
                        </select>
                        <label for="filter_template">Template</label>
                    </div>
                    <div class="form-group">
                        <i class="fas fa-folder"></i>
                        <select id="filter_category" class="form-control">
                            <option value="">All Categories</option>
                            <?php
                            $categoryQuery = "SELECT id, category_name FROM categories ORDER BY category_name";
                            $categoryResult = mysqli_query($conn, $categoryQuery);
                            if ($categoryResult && mysqli_num_rows($categoryResult) > 0) {
                                while ($category = mysqli_fetch_assoc($categoryResult)) {
                                    echo "<option value='" . $category['id'] . "'>" . htmlspecialchars($category['category_name']) . "</option>";
                                }
                            }
                            ?>
                        </select>
                        <label for="filter_category">Category</label>
                    </div>
                    <div class="form-group">
                        <i class="fas fa-graduation-cap"></i>
                        <select id="filter_course" class="form-control">
                            <option value="">All Courses</option>
                            <option value="BCA">BCA</option>
                            <option value="BBA">BBA</option>
                            <option value="B.Tech">B.Tech</option>
                            <option value="MBA">MBA</option>
                        </select>
                        <label for="filter_course">Course</label>
                    </div>
                    <div class="form-group">
                        <i class="fas fa-search"></i>
                        <input type="text" id="search" class="form-control" placeholder=" ">
                        <label for="search">Search Certificates</label>
                    </div>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-user"></i> Name</th>
                                <th><i class="fas fa-id-card"></i> CRN</th>
                                <th><i class="fas fa-phone"></i> Mobile</th>
                                <th><i class="fas fa-envelope"></i> Email</th>
                                <th><i class="fas fa-graduation-cap"></i> Course</th>
                                <th><i class="fas fa-folder"></i> Category</th>
                                <th><i class="fas fa-calendar-check"></i> Event</th>
                                <th><i class="fas fa-file-alt"></i> Template</th>
                                <th><i class="fas fa-barcode"></i> Certificate Ref</th>
                                <th><i class="fas fa-file"></i> File</th>
                                <th><i class="fas fa-qrcode"></i> QR Code</th>
                                <th><i class="fas fa-tools"></i> Action</th>
                            </tr>
                        </thead>
                        <tbody id="certificate-table">
                            <?php
                            $sql = "SELECT c.*, cat.category_name, e.event_name, t.template_name 
                                   FROM certificates c
                                   JOIN events e ON c.event_id = e.id
                                   JOIN categories cat ON e.category_id = cat.id
                                   LEFT JOIN certificate_templates t ON c.template_id = t.id
                                   WHERE c.created_by = ?";
                            $stmt = $conn->prepare($sql);
                            if (!$stmt) {
                                error_log("Prepare failed: " . $conn->error);
                                die("Database error: Unable to prepare query.");
                            }
                            $stmt->bind_param("i", $userId);
                            if (!$stmt->execute()) {
                                error_log("Execute failed: " . $stmt->error);
                                die("Database error: Unable to execute query.");
                            }
                            $result = $stmt->get_result();
                            if (!$result) {
                                error_log("Query failed: " . $conn->error);
                                die("Database error: Query failed.");
                            }
                            
                            if ($result && $result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr data-id='" . $row['id'] . "' data-category-id='" . $row['category_id'] . "' data-event-id='" . $row['event_id'] . "' data-template-id='" . ($row['template_id'] ?: '') . "'>";
                                    echo "<td data-label='Name'>" . htmlspecialchars($row['participant_name']) . "</td>";
                                    echo "<td data-label='CRN'>" . htmlspecialchars($row['participant_crn']) . "</td>";
                                    echo "<td data-label='Mobile'>" . htmlspecialchars($row['participant_mobile']) . "</td>";
                                    echo "<td data-label='Email'>" . htmlspecialchars($row['participant_email']) . "</td>";
                                    echo "<td data-label='Course'>" . htmlspecialchars($row['course_name']) . "</td>";
                                    echo "<td data-label='Category'>" . htmlspecialchars($row['category_name']) . "</td>";
                                    echo "<td data-label='Event'>" . htmlspecialchars($row['event_name']) . "</td>";
                                    echo "<td data-label='Template'>" . ($row['template_name'] ? htmlspecialchars($row['template_name']) : 'No Template') . "</td>";
                                    echo "<td data-label='Certificate Ref'>" . htmlspecialchars($row['certificate_ref']) . "</td>";
                                    echo "<td data-label='File'>";
                                    if (!empty($row['certificate_file'])) {
                                        $fileUrl = "../certificates/" . $row['certificate_file'];
                                        echo "<a href='" . $fileUrl . "' target='_blank' class='btn btn-sm btn-primary'><i class='fas fa-eye'></i> View</a>";
                                    } else {
                                        echo "<span class='badge badge-danger'>No file</span>";
                                    }
                                    echo "</td>";
                                    echo "<td data-label='QR Code'>";
                                    if (!empty($row['qr_code'])) {
                                        $qrUrl = "../qrcodes/" . $row['qr_code'];
                                        $verificationUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                                        $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
                                        if ($scriptDir != '/') {
                                            $verificationUrl .= $scriptDir;
                                        }
                                        $verificationUrl .= "/view_certificate.php?ref=" . urlencode($row['certificate_ref']);
                                        echo "<button class='btn btn-sm btn-secondary view-qr' data-qr='" . $qrUrl . "' data-url='" . $verificationUrl . "'><i class='fas fa-qrcode'></i></button>";
                                    } else {
                                        echo "<span class='badge badge-danger'>No QR</span>";
                                    }
                                    echo "</td>";
                                    echo "<td data-label='Action' class='table-action-buttons'>";
                                    echo "<button class='btn btn-sm btn-warning edit-btn' onclick='editRow(this)'><i class='fas fa-edit'></i> Edit</button>";
                                    echo "<button class='btn btn-sm btn-primary update-btn' style='display:none' onclick='updateRow(this)'><i class='fas fa-check'></i> Update</button>";
                                    echo "<button class='btn btn-sm btn-danger delete-btn' onclick='deleteRow(this)'><i class='fas fa-trash'></i> Delete</button>";
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='12' class='text-center p-3'>No certificates found</td></tr>";
                            }
                            $stmt->close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    
    <div id="qr-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-qrcode"></i> Certificate QR Code</h3>
                <button class="close-modal">×</button>
            </div>
            <div class="modal-body">
                <div class="qr-container">
                    <img id="qr-image" src="" alt="QR Code">
                    <div class="qr-actions">
                        <button id="print-qr" class="btn btn-primary"><i class="fas fa-print"></i> Print QR Code</button>
                        <a id="direct-link" href="#" target="_blank" class="btn btn-success"><i class='fas fa-link'></i> Open Verification Link</a>
                    </div>
                    <p class="qr-instructions">Scan this QR code or use the button above to verify the certificate.</p>
                </div>
            </div>
        </div>
    </div>
    
    <footer class="footer">
        Developed by Team GARUDA 🦅
    </footer>

    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());

        document.onkeydown = function(e) {
            if (
                e.keyCode == 123 || 
                (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) ||
                (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) ||
                (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) ||
                (e.ctrlKey && e.keyCode == 'S'.charCodeAt(0)) 
            ) {
                return false;
            }
        };

        document.addEventListener('selectstart', e => e.preventDefault());
        document.addEventListener('dragstart', e => e.preventDefault());

        setInterval(() => {
            const devtoolsOpen = window.outerWidth - window.innerWidth > 100;
            if (devtoolsOpen) {
                document.body.innerHTML = "<h1 style='text-align:center; margin-top:20%; color:red;'>Inspecting is not allowed!</h1>";
            }
        }, 1000);

        document.addEventListener('DOMContentLoaded', function() {
            const categorySelect = document.getElementById('category_id');
            const eventSelect = document.getElementById('event_id');
            const templateSelect = document.getElementById('template_id');
            const hiddenTemplateInput = document.getElementById('hidden_template_id');
            const fileInput = document.getElementById('certificate_file');
            const fileInfo = document.getElementById('file-info');
            const generateBtn = document.getElementById('generate-btn');
            const certificateForm = document.getElementById('certificate-form');
            const importBtn = document.getElementById('import-btn');
            const exportBtn = document.getElementById('export-btn');

            templateSelect.addEventListener('change', function() {
                hiddenTemplateInput.value = this.value;
                filterCertificates();
            });

            categorySelect.addEventListener('change', function() {
                const categoryId = this.value;
                if (!categoryId) {
                    eventSelect.innerHTML = '<option value="">Select Event</option>';
                    eventSelect.disabled = true;
                    return;
                }
                
                fetch(`../handlers/get_events.php?category_id=${categoryId}`)
                    .then(response => {
                        if (!response.ok) throw new Error('Failed to fetch events');
                        return response.json();
                    })
                    .then(events => {
                        eventSelect.innerHTML = '<option value="">Select Event</option>';
                        events.forEach(event => {
                            const option = document.createElement('option');
                            option.value = event.id;
                            option.textContent = event.event_name;
                            eventSelect.appendChild(option);
                        });
                        eventSelect.disabled = false;
                    })
                    .catch(error => {
                        console.error('Error fetching events:', error);
                        alert('Error fetching events: ' + error.message);
                    });
            });

            fileInput.addEventListener('change', function() {
                updateFileInfo(this.files);
            });

            function updateFileInfo(files) {
                if (files && files.length > 0) {
                    const fileName = files[0].name;
                    const fileSize = (files[0].size / 1024).toFixed(2) + ' KB';
                    fileInfo.textContent = `${fileName} (${fileSize})`;
                    fileInfo.classList.add('has-file');
                } else {
                    fileInfo.textContent = 'No file chosen';
                    fileInfo.classList.remove('has-file');
                }
            }

            certificateForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const templateId = templateSelect.value;
                if (!templateId) {
                    alert('Please select a certificate template');
                    return;
                }
                const requiredFields = ['participant_name', 'participant_crn', 'participant_mobile', 
                                       'participant_email', 'course_name', 'category_id', 'event_id', 'certificate_ref'];
                let isValid = true;
                requiredFields.forEach(field => {
                    const element = document.getElementById(field);
                    if (!element.value.trim()) {
                        element.classList.add('error');
                        isValid = false;
                    } else {
                        element.classList.remove('error');
                    }
                });
                
                if (!isValid) {
                    alert('Please fill in all required fields');
                    return;
                }
                
                const formData = new FormData(this);
                const submitBtn = this.querySelector('#submit-btn');
                const originalText = submitBtn.innerHTML;
                const isEditMode = document.getElementById('edit_mode').value === '1';
                submitBtn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${isEditMode ? 'Updating...' : 'Submitting...'}`;
                submitBtn.disabled = true;
                
                const endpoint = isEditMode ? '../handlers/update.php' : '../handlers/add_certificate.php';
                fetch(endpoint, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(data => {
                    if (data.includes('success')) {
                        alert(isEditMode ? 'Certificate updated successfully!' : 'Certificate added successfully!');
                        resetForm();
                        location.reload();
                    } else {
                        alert('Error: ' + data);
                    }
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    alert('An error occurred: ' + error.message);
                })
                .finally(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                });
            });

            window.resetForm = function() {
                certificateForm.reset();
                document.querySelectorAll('tr.active-row').forEach(row => {
                    row.classList.remove('active-row');
                    const editBtn = row.querySelector('.edit-btn');
                    const updateBtn = row.querySelector('.update-btn');
                    if (editBtn) editBtn.style.display = 'block';
                    if (updateBtn) updateBtn.style.display = 'none';
                });
                eventSelect.innerHTML = '<option value="">Select Event</option>';
                eventSelect.disabled = true;
                templateSelect.value = '';
                hiddenTemplateInput.value = '';
                document.getElementById('edit_mode').value = '0';
                document.getElementById('form-title').innerHTML = '<i class="fas fa-certificate"></i> Add Certificate';
                document.getElementById('submit-btn').innerHTML = '<i class="fas fa-save"></i> Submit';
                document.getElementById('cancel-btn').style.display = 'none';
                generateBtn.style.display = 'none';
                const certInput = document.getElementById('certificate_ref');
                certInput.value = 'AGOI2025EXE' + Math.floor(100000 + Math.random() * 900000);
                fileInfo.textContent = 'No file chosen';
                fileInfo.classList.remove('has-file');
                fileInput.value = '';
            };

            const certInput = document.getElementById('certificate_ref');
            if (!certInput.value) {
                certInput.value = 'AGOI2025EXE' + Math.floor(100000 + Math.random() * 900000);
            }

            document.getElementById('cancel-btn').addEventListener('click', resetForm);

            window.deleteRow = function(button) {
                if (confirm('Are you sure you want to delete this certificate?')) {
                    const row = button.closest('tr');
                    const rowId = row.getAttribute('data-id');
                    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                    button.disabled = true;
                    fetch('../handlers/delete_certificate.php?id=' + rowId)
                        .then(response => response.text())
                        .then(data => {
                            if (data.includes('success')) {
                                alert('Certificate deleted successfully!');
                                row.remove();
                            } else {
                                alert('Error: ' + data);
                                button.innerHTML = '<i class="fas fa-trash"></i> Delete';
                                button.disabled = false;
                            }
                        })
                        .catch(error => {
                            console.error('Delete error:', error);
                            alert('An error occurred: ' + error.message);
                            button.innerHTML = '<i class="fas fa-trash"></i> Delete';
                            button.disabled = false;
                        });
                }
            };

            window.editRow = function(button) {
                const row = button.closest('tr');
                const cells = row.querySelectorAll("td");
                const rowId = row.getAttribute('data-id');
                const categoryId = row.getAttribute('data-category-id');
                const eventId = row.getAttribute('data-event-id');
                const templateId = row.getAttribute('data-template-id');
                
                document.querySelectorAll('tr.active-row').forEach(r => r.classList.remove('active-row'));
                row.classList.add('active-row');
                row.classList.add('highlight-animation');
                
                document.getElementById('participant_name').value = cells[0].innerText;
                document.getElementById('participant_crn').value = cells[1].innerText;
                document.getElementById('participant_mobile').value = cells[2].innerText;
                document.getElementById('participant_email').value = cells[3].innerText;
                document.getElementById('course_name').value = cells[4].innerText;
                document.getElementById('certificate_ref').value = cells[8].innerText;
                templateSelect.value = templateId || '';
                hiddenTemplateInput.value = templateId || '';
                
                let idInput = document.getElementById('id_field');
                if (!idInput) {
                    idInput = document.createElement('input');
                    idInput.type = 'hidden';
                    idInput.id = 'id_field';
                    idInput.name = 'id';
                    certificateForm.appendChild(idInput);
                }
                idInput.value = rowId;
                
                const categorySelect = document.getElementById('category_id');
                categorySelect.value = categoryId;
                categorySelect.dispatchEvent(new Event('change'));
                setTimeout(() => {
                    document.getElementById('event_id').value = eventId;
                    document.getElementById('event_id').disabled = false;
                }, 500);
                
                document.getElementById('edit_mode').value = "1";
                document.getElementById('form-title').innerHTML = '<i class="fas fa-edit"></i> Edit Certificate';
                document.getElementById('submit-btn').innerHTML = '<i class="fas fa-check"></i> Update';
                document.getElementById('cancel-btn').style.display = "block";
                generateBtn.style.display = "inline-flex";
                
                const fileCell = cells[9].querySelector('a');
                if (fileCell) {
                    fileInfo.textContent = `${row.getAttribute('data-id')}.pdf (Generated or Uploaded)`;
                    fileInfo.classList.add('has-file');
                } else {
                    fileInfo.textContent = 'No file chosen';
                    fileInfo.classList.remove('has-file');
                }
                
                generateBtn.onclick = function() {
                    if (!templateId) {
                        alert('Please select a template before generating the certificate.');
                        return;
                    }
                    generateCertificate(rowId, templateId);
                };
                
                document.getElementById('form-title').scrollIntoView({ behavior: 'smooth' });
                
                const editBtn = row.querySelector('.edit-btn');
                const updateBtn = row.querySelector('.update-btn');
                if (editBtn) editBtn.style.display = 'none';
                if (updateBtn) updateBtn.style.display = 'block';
            };

            window.generateCertificate = function(id, templateId) {
                if (!templateId) {
                    alert('Please select a template before generating the certificate.');
                    return;
                }
                const originalText = generateBtn.innerHTML;
                generateBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
                generateBtn.disabled = true;
                
                fetch(`../PHP_Extensions/make_certificate.php?id=${id}&template_id=${templateId}&return_path=1`, {
                    method: 'GET'
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        fetch(data.file_path)
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Failed to fetch PDF');
                                }
                                return response.blob();
                            })
                            .then(blob => {
                                const fileName = data.file_path.split('/').pop();
                                const file = new File([blob], fileName, { type: 'application/pdf' });
                                const dataTransfer = new DataTransfer();
                                dataTransfer.items.add(file);
                                const fileInput = document.getElementById('certificate_file');
                                if (fileInput) {
                                    fileInput.files = dataTransfer.files;
                                    updateFileInfo(fileInput.files);
                                    alert('Certificate generated and attached successfully!');
                                } else {
                                    console.error('Certificate file input not found');
                                    alert('Error: Certificate file input not found.');
                                }
                            })
                            .catch(error => {
                                console.error('Error fetching PDF:', error);
                                alert('Error attaching certificate: ' + error.message);
                            })
                            .finally(() => {
                                generateBtn.innerHTML = originalText;
                                generateBtn.disabled = false;
                            });
                    } else {
                        alert('Error: ' + data.error);
                        generateBtn.innerHTML = originalText;
                        generateBtn.disabled = false;
                    }
                })
                .catch(error => {
                    console.error('Error generating certificate:', error);
                    alert('An error occurred while generating the certificate: ' + error.message);
                    generateBtn.innerHTML = originalText;
                    generateBtn.disabled = false;
                });
            };

            window.updateRow = function(button) {
                const row = button.closest('tr');
                const rowId = row.getAttribute('data-id');
                let idInput = document.getElementById('id_field');
                if (!idInput) {
                    idInput = document.createElement('input');
                    idInput.type = 'hidden';
                    idInput.id = 'id_field';
                    idInput.name = 'id';
                    certificateForm.appendChild(idInput);
                }
                idInput.value = rowId;
                
                const formData = new FormData(certificateForm);
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                button.disabled = true;
                
                fetch('../handlers/update.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(data => {
                    if (data.startsWith('success')) {
                        const cells = row.querySelectorAll('td');
                        cells[0].innerText = formData.get('participant_name');
                        cells[1].innerText = formData.get('participant_crn');
                        cells[2].innerText = formData.get('participant_mobile');
                        cells[3].innerText = formData.get('participant_email');
                        cells[4].innerText = formData.get('course_name');
                        cells[5].innerText = document.getElementById('category_id').options[document.getElementById('category_id').selectedIndex].text;
                        cells[6].innerText = document.getElementById('event_id').options[document.getElementById('event_id').selectedIndex].text;
                        cells[7].innerText = document.getElementById('template_id').options[document.getElementById('template_id').selectedIndex].text || 'No Template';
                        cells[8].innerText = formData.get('certificate_ref');
                        
                        resetForm();
                        row.classList.add('update-animation');
                        setTimeout(() => {
                            row.classList.remove('update-animation');
                            row.classList.remove('active-row');
                        }, 2000);
                        alert('Certificate updated successfully!');
                    } else {
                        alert('Error: ' + data);
                    }
                    button.innerHTML = '<i class="fas fa-check"></i> Update';
                    button.disabled = false;
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error updating certificate');
                    button.innerHTML = '<i class="fas fa-check"></i> Update';
                    button.disabled = false;
                });
            };

            exportBtn.addEventListener('click', function() {
                const templateId = templateSelect.value;
                if (!templateId) {
                    alert('Please select a template before exporting certificates.');
                    return;
                }
                window.location.href = `../PHP_Extensions/import_export.php?action=export&template_id=${templateId}`;
            });

            importBtn.addEventListener('click', function() {
                const templateId = templateSelect.value;
                if (!templateId) {
                    alert('Please select a template before importing certificates.');
                    return;
                }
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.xlsx, .xls';
                input.onchange = function(e) {
                    const file = e.target.files[0];
                    if (!file) return;

                    const formData = new FormData();
                    formData.append('import_file', file);
                    formData.append('created_by', '<?php echo $userId; ?>');
                    formData.append('template_id', templateId);

                    importBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Importing...';
                    importBtn.disabled = true;

                    fetch('../PHP_Extensions/import_certificates.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(data.message);
                            location.reload();
                        } else {
                            alert('Error: ' + data.error + (data.details ? '\nDetails: ' + JSON.stringify(data.details) : ''));
                        }
                    })
                    .catch(error => {
                        console.error('Import error:', error);
                        alert('An error occurred during import: ' + error.message);
                    })
                    .finally(() => {
                        importBtn.innerHTML = '<i class="fas fa-file-import"></i> Import';
                        importBtn.disabled = false;
                    });
                };
                input.click();
            });

            const modal = document.getElementById('qr-modal');
            const qrImage = document.getElementById('qr-image');
            const printQr = document.getElementById('print-qr');
            const directLink = document.getElementById('direct-link');
            document.querySelectorAll('.view-qr').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    qrImage.src = this.dataset.qr;
                    directLink.href = this.dataset.url;
                    modal.style.display = 'block';
                });
            });
            document.querySelector('.close-modal').addEventListener('click', () => modal.style.display = 'none');
            printQr.addEventListener('click', () => {
                const printWindow = window.open('', '_blank');
                printWindow.document.write('<img src="' + qrImage.src + '" onload="window.print();window.close()">');
            });
            window.addEventListener('click', e => {
                if (e.target === modal) modal.style.display = 'none';
            });

            const filterStatus = document.getElementById('filter_status');
            const filterTemplate = document.getElementById('filter_template');
            const filterCategory = document.getElementById('filter_category');
            const filterCourse = document.getElementById('filter_course');
            const searchInput = document.getElementById('search');
            
            function filterCertificates() {
                const statusValue = filterStatus.value;
                const templateValue = filterTemplate.value || templateSelect.value;
                const categoryValue = filterCategory.value;
                const courseValue = filterCourse.value;
                const searchValue = searchInput.value.toLowerCase();
                const rows = document.querySelectorAll('#certificate-table tr');
                
                rows.forEach(row => {
                    if (row.id === 'no-results-row') return;
                    const hasCertificate = row.querySelector('.badge-danger') === null;
                    const templateCell = row.querySelector('td:nth-child(8)');
                    const categoryCell = row.querySelector('td:nth-child(6)');
                    const courseCell = row.querySelector('td:nth-child(5)');
                    const searchText = row.textContent.toLowerCase();
                    
                    let statusMatch = true;
                    if (statusValue === 'with_certificate') statusMatch = hasCertificate;
                    else if (statusValue === 'without_certificate') statusMatch = !hasCertificate;
                    
                    let templateMatch = true;
                    if (templateValue) {
                        templateMatch = row.getAttribute('data-template-id') === templateValue;
                    }
                    
                    let categoryMatch = true;
                    if (categoryValue) categoryMatch = categoryCell.textContent.trim() === document.querySelector(`#filter_category option[value="${categoryValue}"]`).textContent;
                    
                    let courseMatch = true;
                    if (courseValue) courseMatch = courseCell.textContent.trim() === courseValue;
                    
                    const searchMatch = !searchValue || searchText.includes(searchValue);
                    
                    row.style.display = statusMatch && templateMatch && categoryMatch && courseMatch && searchMatch ? '' : 'none';
                });
                
                const visibleRows = document.querySelectorAll('#certificate-table tr:not([style*="display: none"]):not(#no-results-row)');
                const noResultsRow = document.getElementById('no-results-row');
                if (visibleRows.length === 0) {
                    if (!noResultsRow) {
                        const tbody = document.getElementById('certificate-table');
                        const newRow = document.createElement('tr');
                        newRow.id = 'no-results-row';
                        newRow.innerHTML = '<td colspan="12" class="text-center">No certificates found matching your criteria</td>';
                        tbody.appendChild(newRow);
                    }
                } else if (noResultsRow) {
                    noResultsRow.remove();
                }
            }

            filterStatus.addEventListener('change', filterCertificates);
            filterTemplate.addEventListener('change', filterCertificates);
            filterCategory.addEventListener('change', filterCertificates);
            filterCourse.addEventListener('change', filterCertificates);
            searchInput.addEventListener('input', filterCertificates);

            document.querySelectorAll('.btn').forEach(button => {
                button.addEventListener('click', function(e) {
                    const x = e.clientX - e.target.getBoundingClientRect().left;
                    const y = e.clientY - e.target.getBoundingClientRect().top;
                    const ripple = document.createElement('span');
                    ripple.classList.add('ripple-effect');
                    ripple.style.left = `${x}px`;
                    ripple.style.top = `${y}px`;
                    this.appendChild(ripple);
                    setTimeout(() => ripple.remove(), 600);
                });
            });
        });
    </script>
</body>
</html>