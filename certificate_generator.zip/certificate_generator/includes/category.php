<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../index.html");
    exit;
}

if ($_SESSION['role'] !== 'faculty') {
    header("Location: ../index.html");
    exit;
}

require_once '../assets/db_config.php';

$successMessage = '';
$errorMessage = '';

if (isset($_POST['add_category'])) {
    $category_name = mysqli_real_escape_string($conn, $_POST['category_name']);
    $checkQuery = "SELECT * FROM categories WHERE category_name = '$category_name'";
    $checkResult = mysqli_query($conn, $checkQuery);
    
    if (mysqli_num_rows($checkResult) > 0) {
        $errorMessage = "Category '$category_name' already exists!";
    } else {
        $insertQuery = "INSERT INTO categories (category_name, created_at) VALUES ('$category_name', NOW())";
        if (mysqli_query($conn, $insertQuery)) {
            $successMessage = "Category added successfully!";
        } else {
            $errorMessage = "Error adding category: " . mysqli_error($conn);
        }
    }
}

if (isset($_POST['add_event'])) {
    $event_name = mysqli_real_escape_string($conn, $_POST['event_name']);
    $category_id = mysqli_real_escape_string($conn, $_POST['category_id']);
    $checkQuery = "SELECT * FROM events WHERE event_name = '$event_name' AND category_id = '$category_id'";
    $checkResult = mysqli_query($conn, $checkQuery);
    
    if (mysqli_num_rows($checkResult) > 0) {
        $errorMessage = "Event '$event_name' already exists in this category!";
    } else {
        $insertQuery = "INSERT INTO events (event_name, category_id, created_at) VALUES ('$event_name', '$category_id', NOW())";
        if (mysqli_query($conn, $insertQuery)) {
            $successMessage = "Event added successfully!";
        } else {
            $errorMessage = "Error adding event: " . mysqli_error($conn);
        }
    }
}

if (isset($_GET['delete_category'])) {
    $category_id = mysqli_real_escape_string($conn, $_GET['delete_category']);
    $checkQuery = "SELECT COUNT(*) as count FROM certificates WHERE category_id = '$category_id'";
    $checkResult = mysqli_query($conn, $checkQuery);
    $row = mysqli_fetch_assoc($checkResult);
    
    if ($row['count'] > 0) {
        $errorMessage = "Cannot delete category because it is used by " . $row['count'] . " certificates!";
    } else {
        $deleteEventsQuery = "DELETE FROM events WHERE category_id = '$category_id'";
        mysqli_query($conn, $deleteEventsQuery);
        $deleteCategoryQuery = "DELETE FROM categories WHERE id = '$category_id'";
        if (mysqli_query($conn, $deleteCategoryQuery)) {
            $successMessage = "Category and its events deleted successfully!";
        } else {
            $errorMessage = "Error deleting category: " . mysqli_error($conn);
        }
    }
}

if (isset($_GET['delete_event'])) {
    $event_id = mysqli_real_escape_string($conn, $_GET['delete_event']);
    $checkQuery = "SELECT COUNT(*) as count FROM certificates WHERE event_id = '$event_id'";
    $checkResult = mysqli_query($conn, $checkQuery);
    $row = mysqli_fetch_assoc($checkResult);
    
    if ($row['count'] > 0) {
        $errorMessage = "Cannot delete event because it is used by " . $row['count'] . " certificates!";
    } else {
        $deleteQuery = "DELETE FROM events WHERE id = '$event_id'";
        if (mysqli_query($conn, $deleteQuery)) {
            $successMessage = "Event deleted successfully!";
        } else {
            $errorMessage = "Error deleting event: " . mysqli_error($conn);
        }
    }
}

$categoriesQuery = "SELECT * FROM categories ORDER BY category_name";
$categoriesResult = mysqli_query($conn, $categoriesQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Management - E Certificate System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        :root {
            --primary: #FF6B01;
            --secondary: #FFFFFF;
            --dark: #353535;
            --shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 10px 20px rgba(0, 0, 0, 0.12);
            --border-radius: 12px;
            --border-radius-sm: 6px;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(145deg, #f7f7f7, #e8e8e8);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            color: var(--dark);
            line-height: 1.6;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-user-drag: none;
            -webkit-touch-callout: none;
        }

        .app-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            box-shadow: var(--shadow);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1.5rem;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .app-logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .app-logo h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary);
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            transition: var(--transition);
            overflow: hidden;
        }

        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .app-logo:hover .logo-icon {
            transform: scale(1.1);
        }

        .app-nav {
            display: flex;
            gap: 1rem;
        }

        .nav-link {
            text-decoration: none;
            color: var(--dark);
            font-weight: 500;
            padding: 0.6rem 1.2rem;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.4rem;
            font-size: 0.95rem;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--primary);
            color: var(--secondary);
            box-shadow: var(--shadow);
            transform: translateY(-2px);
        }

        .logout {
            background: var(--primary);
            color: var(--secondary);
        }

        .logout:hover {
            background: #e55e00;
        }

        .dashboard-container {
            display: flex;
            flex-direction: column;
            gap: 2rem;
            margin-top: 2rem;
        }

        .row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .card {
            background: var(--secondary);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: var(--transition);
            animation: fadeInUp 0.6s ease forwards;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .card-header {
            background: linear-gradient(90deg, var(--primary), #ff8c00);
            color: var(--secondary);
            padding: 1.2rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-header h2,
        .card-header h3 {
            font-size: 1.5rem;
            font-weight: 600;
        }

        .card-body {
            padding: 1.5rem;
        }

        .form-group {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .form-control {
            width: 100%;
            padding: 0.8rem 1rem 0.8rem 2.5rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: var(--border-radius-sm);
            font-size: 0.95rem;
            transition: var(--transition);
            background: #fafafa;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 107, 1, 0.1);
            outline: none;
        }

        .form-group i {
            position: absolute;
            left: 0.8rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--dark);
            opacity: 0.5;
        }

        .form-group label {
            position: absolute;
            top: 50%;
            left: 2.5rem;
            transform: translateY(-50%);
            font-size: 0.95rem;
            color: var(--dark);
            opacity: 0.65;
            transition: var(--transition);
            pointer-events: none;
            background: transparent;
        }

        .form-control:focus + label,
        .form-control:not(:placeholder-shown) + label {
            top: -0.7rem;
            left: 1.5rem;
            font-size: 0.75rem;
            color: var(--primary);
            background: var(--secondary);
            padding: 0 0.3rem;
            opacity: 1;
        }

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 0.75rem;
        }

        .btn {
            padding: 0.8rem 1.5rem;
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.4rem;
            font-size: 0.95rem;
            position: relative;
            overflow: hidden;
            text-decoration: none;
        }

        .btn-primary {
            background: var(--primary);
            color: var(--secondary);
        }

        .btn-primary:hover {
            background: #e55e00;
            transform: scale(1.05);
            box-shadow: var(--shadow);
        }

        .btn-danger {
            background: #dc2626;
            color: var(--secondary);
        }

        .btn-danger:hover {
            background: #b91c1c;
            transform: scale(1.05);
            box-shadow: var(--shadow);
            text-decoration: none;
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
            text-decoration: none;
        }

        .btn-sm.btn-danger {
            text-decoration: none;
        }

        .btn-sm.btn-danger:hover {
            text-decoration: none;
        }

        .ripple-effect {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: scale(0);
            animation: ripple 0.5s linear;
        }

        @keyframes ripple {
            to {
                transform: scale(3);
                opacity: 0;
            }
        }

        .category-container {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .category-item {
            border: 1px solid rgba(0, 0, 0, 0.05);
            border-radius: var(--border-radius);
            background: var(--secondary);
            box-shadow: var(--shadow);
            transition: var(--transition);
            animation: fadeInUp 0.6s ease forwards;
        }

        .category-item:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .category-header {
            background: #fafafa;
            padding: 1rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .category-header h3 {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .category-body {
            padding: 1.5rem;
        }

        .event-list {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }

        .event-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem 1rem;
            background: #f5f5f5;
            border-radius: var(--border-radius-sm);
            transition: var(--transition);
            animation: scaleIn 0.5s ease forwards;
        }

        .event-item:hover {
            background: #fff;
            box-shadow: var(--shadow);
            transform: translateY(-2px);
        }

        .event-item span {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--dark);
            font-size: 0.95rem;
        }

        .no-events,
        .no-categories {
            color: var(--dark);
            opacity: 0.65;
            font-style: italic;
            text-align: center;
            padding: 1.5rem;
            font-size: 0.95rem;
        }

        .alert {
            padding: 1rem;
            border-radius: var(--border-radius-sm);
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideInUp 0.5s ease;
        }

        .alert-success {
            background: rgba(255, 107, 1, 0.1);
            color: var(--primary);
            border: 1px solid var(--primary);
        }

        .alert-danger {
            background: rgba(220, 38, 38, 0.1);
            color: #dc2626;
            border: 1px solid #dc2626;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: var(--secondary);
            text-align: center;
            padding: 0.5rem 0;
            font-size: 0.85rem;
            color: var(--dark);
            opacity: 0.65;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            z-index: 1000;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes scaleIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        @media (max-width: 1024px) {
            .container { padding: 1rem; }
            .app-logo h1 { font-size: 1.6rem; }
            .card-header h2, .card-header h3 { font-size: 1.4rem; }
            .row { grid-template-columns: 1fr; }
            .logo-icon { width: 36px; height: 36px; }
        }

        @media (max-width: 768px) {
            .header-content { flex-direction: column; gap: 1rem; }
            .app-nav { flex-direction: column; gap: 0.5rem; }
            .nav-link { padding: 0.5rem 1rem; }
            .card-header h2, .card-header h3 { font-size: 1.3rem; }
            .btn { padding: 0.7rem 1.2rem; font-size: 0.9rem; }
            .logo-icon { width: 34px; height: 34px; }
        }

        @media (max-width: 480px) {
            .app-logo h1 { font-size: 1.4rem; }
            .logo-icon { width: 32px; height: 32px; }
            .card-header h2, .card-header h3 { font-size: 1.2rem; }
            .form-control { font-size: 0.85rem; padding: 0.7rem 1rem 0.7rem 2.2rem; }
            .btn { padding: 0.6rem 1rem; font-size: 0.85rem; }
            .footer { font-size: 0.75rem; }
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="container">
            <div class="header-content">
                <div class="app-logo">
                    <div class="logo-icon">
                        <img src="../images/logo.png" alt="E Certificate Logo">
                    </div>
                    <h1>E Certificates</h1>
                </div>
                <nav class="app-nav">
                    <a href="dashboard.php" class="nav-link"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                    <a href="category.php" class="nav-link active"><i class="fas fa-list"></i> Categories & Events</a>
                    <a href="../handlers/logout.php" class="nav-link logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
        </div>
    </header>
    
    <main class="container dashboard-container">
        <?php if ($successMessage): ?>
            <div class="alert alert-success animate__animated animate__fadeIn"><i class="fas fa-check-circle"></i> <?php echo $successMessage; ?></div>
        <?php endif; ?>
        
        <?php if ($errorMessage): ?>
            <div class="alert alert-danger animate__animated animate__fadeIn"><i class="fas fa-exclamation-circle"></i> <?php echo $errorMessage; ?></div>
        <?php endif; ?>
        
        <div class="row">
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-folder-plus"></i> Add New Category</h3>
                </div>
                <div class="card-body">
                    <form method="post" action="">
                        <div class="form-group">
                            <i class="fas fa-folder"></i>
                            <input type="text" id="category_name" name="category_name" class="form-control" placeholder=" " required>
                            <label for="category_name">Category Name</label>
                        </div>
                        <div class="form-actions">
                            <button type="submit" name="add_category" class="btn btn-primary"><i class="fas fa-plus"></i> Add Category</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-calendar-plus"></i> Add New Event</h3>
                </div>
                <div class="card-body">
                    <form method="post" action="">
                        <div class="form-group">
                            <i class="fas fa-folder"></i>
                            <select id="event_category" name="category_id" class="form-control" required>
                                <option value="">Select Category</option>
                                <?php
                                mysqli_data_seek($categoriesResult, 0);
                                while ($category = mysqli_fetch_assoc($categoriesResult)) {
                                    echo "<option value='" . $category['id'] . "'>" . htmlspecialchars($category['category_name']) . "</option>";
                                }
                                ?>
                            </select>
                            <label for="event_category">Select Category</label>
                        </div>
                        <div class="form-group">
                            <i class="fas fa-calendar-check"></i>
                            <input type="text" id="event_name" name="event_name" class="form-control" placeholder=" " required>
                            <label for="event_name">Event Name</label>
                        </div>
                        <div class="form-actions">
                            <button type="submit" name="add_event" class="btn btn-primary"><i class="fas fa-plus"></i> Add Event</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-list-ul"></i> Existing Categories & Events</h2>
            </div>
            <div class="card-body">
                <div class="category-container">
                    <?php
                    mysqli_data_seek($categoriesResult, 0);
                    if (mysqli_num_rows($categoriesResult) > 0) {
                        while ($category = mysqli_fetch_assoc($categoriesResult)) {
                            ?>
                            <div class="category-item">
                                <div class="category-header">
                                    <h3><i class="fas fa-folder"></i> <?php echo htmlspecialchars($category['category_name']); ?></h3>
                                    <a href="?delete_category=<?php echo $category['id']; ?>" 
                                       class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Are you sure you want to delete this category and all its events?')">
                                        <i class="fas fa-trash"></i> Delete Category
                                    </a>
                                </div>
                                <div class="category-body">
                                    <?php
                                    $eventsQuery = "SELECT * FROM events WHERE category_id = '{$category['id']}' ORDER BY event_name";
                                    $eventsResult = mysqli_query($conn, $eventsQuery);
                                    if (mysqli_num_rows($eventsResult) > 0) {
                                        echo "<div class='event-list'>";
                                        while ($event = mysqli_fetch_assoc($eventsResult)) {
                                            ?>
                                            <div class="event-item">
                                                <span><i class="fas fa-calendar-check"></i> <?php echo htmlspecialchars($event['event_name']); ?></span>
                                                <a href="?delete_event=<?php echo $event['id']; ?>" 
                                                   class="btn btn-sm btn-danger" 
                                                   onclick="return confirm('Are you sure you want to delete this event?')">
                                                    <i class="fas fa-trash"></i> Delete
                                                </a>
                                            </div>
                                            <?php
                                        }
                                        echo "</div>";
                                    } else {
                                        echo "<p class='no-events'><i class='fas fa-info-circle'></i> No events in this category yet.</p>";
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                        }
                    } else {
                        echo "<p class='no-categories'><i class='fas fa-info-circle'></i> No categories found. Please add a category first.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </main>
    
    <footer class="footer">
        Developed by Team GARUDA 🦅
    </footer>

    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());

        document.onkeydown = function(e) {
            if (
                e.keyCode == 123 || 
                (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) || 
                (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) || 
                (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) || 
                (e.ctrlKey && e.keyCode == 'S'.charCodeAt(0))
            ) {
                return false;
            }
        };

        document.addEventListener('selectstart', e => e.preventDefault());
        document.addEventListener('dragstart', e => e.preventDefault());

        setInterval(() => {
            const devtoolsOpen = window.outerWidth - window.innerWidth > 100;
            if (devtoolsOpen) {
                document.body.innerHTML = "<h1 style='text-align:center; margin-top:20%; color:red;'>Inspecting is not allowed!</h1>";
            }
        }, 1000);

        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.classList.remove('animate__fadeIn');
                    alert.classList.add('animate__fadeOut');
                    setTimeout(function() {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });

            document.querySelectorAll('.btn').forEach(button => {
                button.addEventListener('click', function(e) {
                    const x = e.clientX - e.target.getBoundingClientRect().left;
                    const y = e.clientY - e.target.getBoundingClientRect().top;
                    const ripple = document.createElement('span');
                    ripple.classList.add('ripple-effect');
                    ripple.style.left = `${x}px`;
                    ripple.style.top = `${y}px`;
                    this.appendChild(ripple);
                    setTimeout(() => ripple.remove(), 600);
                });
            });
        });
    </script>
</body>
</html>