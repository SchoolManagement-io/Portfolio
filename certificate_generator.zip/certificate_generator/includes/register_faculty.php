<?php
session_start();
require_once '../assets/db_config.php';
require_once '../handlers/faculty_mail.php';

if (!isset($_SESSION['logged_in']) || $_SESSION['role'] !== 'superadmin') {
    header("Location: ../index.html");
    exit;
}

$message = '';
$error = '';
$template_message = '';
$template_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register_faculty') {
    if (empty($_POST['name']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['department'])) {
        $error = "All fields are required";
    } else if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format";
    } else {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = $_POST['password'];
        $department = mysqli_real_escape_string($conn, $_POST['department']);

        $stmt = $conn->prepare("SELECT id FROM faculty WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Email already registered";
        } else {
            $stmt = $conn->prepare("INSERT INTO faculty (name, email, password, department) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $email, $password, $department);
            
            if ($stmt->execute()) {
                $message = "Faculty registered successfully";
                $facultyData = [
                    'name' => $name,
                    'email' => $email,
                    'password' => $password,
                    'department' => $department
                ];
                if (!sendFacultyRegistrationEmail($conn, $facultyData)) {
                    $error = "Faculty registered, but failed to send registration email.";
                }
            } else {
                $error = "Error registering faculty: " . $conn->error;
            }
        }
    }
    
    if ($error) {
        $error = "<div class='alert alert-danger'><i class='fas fa-exclamation-circle'></i> $error</div>";
    } else if ($message) {
        $message = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> $message</div>";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_template') {
    if (empty($_POST['template_name']) || empty($_FILES['template_file']['name'])) {
        $template_error = "All fields are required";
    } else {
        $template_name = mysqli_real_escape_string($conn, $_POST['template_name']);
        $file = $_FILES['template_file'];
        
        $allowed_types = ['application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'];
        $file_type = $file['type'];
        
        if (!in_array($file_type, $allowed_types)) {
            $template_error = "Only PPT/PPTX files are allowed";
        } else {
            $upload_dir = '../Uploads/templates/';
            $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $new_file_name = uniqid() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_file_name;

            $stmt = $conn->prepare("SELECT id FROM certificate_templates WHERE template_name = ?");
            $stmt->bind_param("s", $template_name);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $template_error = "Template name already exists";
            } else if (move_uploaded_file($file['tmp_name'], $upload_path)) {
                $uploaded_by = $_SESSION['user_id'];
                
                $stmt = $conn->prepare("INSERT INTO certificate_templates (template_name, template_file, uploaded_by) VALUES (?, ?, ?)");
                $stmt->bind_param("ssi", $template_name, $new_file_name, $uploaded_by);
                
                if ($stmt->execute()) {
                    $template_message = "Template uploaded successfully";
                } else {
                    $template_error = "Error uploading template: " . $conn->error;
                    unlink($upload_path);
                }
            } else {
                $template_error = "Error uploading file";
            }
        }
    }
    
    if ($template_error) {
        $template_error = "<div class='alert alert-danger'><i class='fas fa-exclamation-circle'></i> $template_error</div>";
    } else if ($template_message) {
        $template_message = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> $template_message</div>";
    }
}

$faculty_list = [];
$stmt = $conn->prepare("SELECT id, name, email, department, created_at FROM faculty ORDER BY created_at DESC");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $faculty_list[] = $row;
}

$template_list = [];
$stmt = $conn->prepare("SELECT id, template_name, template_file, created_at FROM certificate_templates ORDER BY created_at DESC");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $template_list[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Faculty - E Certificate System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --primary: #FF6B01;
            --secondary: #FFFFFF;
            --dark: #353535;
            --shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 10px 20px rgba(0, 0, 0, 0.12);
            --border-radius: 12px;
            --border-radius-sm: 6px;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(145deg, #f7f7f7, #e8e8e8);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-user-drag: none;
            -webkit-touch-callout: none;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 1.5rem;
            padding-bottom: 4rem;
        }

        .header {
            background: var(--secondary);
            padding: 1rem 2rem;
            box-shadow: var(--shadow);
            border-radius: var(--border-radius);
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            animation: fadeInDown 0.8s ease;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .logo-icon {
            width: 36px;
            height: 36px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            transition: var(--transition);
            overflow: hidden;
        }

        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .logo-section:hover .logo-icon {
            transform: scale(1.1);
        }

        .header h1 {
            font-size: 1.6rem;
            font-weight: 600;
            color: var(--primary);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-info span {
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--dark);
            opacity: 0.8;
        }

        .btn {
            padding: 0.8rem 1.5rem;
            border-radius: var(--border-radius-sm);
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
            transition: var(--transition);
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            min-height: 44px;
        }

        .btn-outline {
            border: 1px solid var(--primary);
            color: var(--primary);
            background: transparent;
        }

        .btn-outline:hover {
            background: var(--primary);
            color: var(--secondary);
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .btn-primary {
            background: linear-gradient(90deg, var(--primary), #ff8c00);
            color: var(--secondary);
            border: none;
        }

        .btn-primary:hover {
            background: linear-gradient(90deg, #e55e00, var(--primary));
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .btn-danger {
            background: #dc2626;
            color: var(--secondary);
            border: none;
        }

        .btn-danger:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .btn:disabled {
            background: #cccccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .main-content {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            padding: 1.5rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            backdrop-filter: blur(8px);
            animation: fadeInUp 0.8s ease;
        }

        .card h2 {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-group {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .form-control {
            width: 100%;
            padding: 0.8rem 1rem 0.8rem 2.5rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: var(--border-radius-sm);
            font-size: 0.9rem;
            transition: var(--transition);
            background: #fafafa;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 107, 1, 0.1);
            outline: none;
        }

        select.form-control {
            appearance: none;
            background: #fafafa url("data:image/svg+xml;utf8,<svg fill='%23353535' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/><path d='M0 0h24v24H0z' fill='none'/></svg>") no-repeat right 0.75rem center/16px 16px;
        }

        .form-group i {
            position: absolute;
            left: 0.8rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--dark);
            opacity: 0.5;
            font-size: 0.9rem;
        }

        .form-group label {
            position: absolute;
            top: 50%;
            left: 2.5rem;
            transform: translateY(-50%);
            font-size: 0.9rem;
            color: var(--dark);
            opacity: 0.65;
            transition: var(--transition);
            pointer-events: none;
            background: transparent;
        }

        .form-control:focus + label,
        .form-control:not(:placeholder-shown) + label,
        select.form-control + label {
            top: -0.6rem;
            left: 1.2rem;
            font-size: 0.75rem;
            color: var(--primary);
            background: var(--secondary);
            padding: 0 0.2rem;
            opacity: 1;
        }

        .alert {
            padding: 1rem;
            border-radius: var(--border-radius-sm);
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
            font-weight: 400;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: slideInUp 0.5s ease;
        }

        .alert-success {
            background: #e6fffa;
            color: #2a9d8f;
        }

        .alert-danger {
            background: #ffe6e6;
            color: #dc2626;
        }

        .alert i {
            font-size: 1.1rem;
        }

        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        .table th,
        .table td {
            padding: 0.8rem;
            text-align: left;
            font-size: 0.9rem;
        }

        .table th {
            background: var(--primary);
            color: var(--secondary);
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .table tr:nth-child(even) {
            background: #f9fafb;
        }

        .table tr:hover {
            background: #fff7ed;
        }

        .table-action-buttons {
            display: flex;
            gap: 0.5rem;
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
            min-height: 36px;
        }

        .row {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .col-md-6 {
            flex: 1 0 calc(50% - 0.5rem);
        }

        .text-center {
            text-align: center;
        }

        /* Remove underline from file links in Template List table */
        .table.template-table td:nth-child(2) a {
            text-decoration: none;
            color: var(--dark);
            transition: var(--transition);
        }

        .table.template-table td:nth-child(2) a:hover {
            color: var(--primary);
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: var(--secondary);
            text-align: center;
            padding: 0.5rem;
            font-size: 0.8rem;
            color: var(--dark);
            opacity: 0.65;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            z-index: 1000;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .container {
                padding: 1rem;
            }

            .header {
                padding: 0.8rem 1.5rem;
            }

            .header h1 {
                font-size: 1.4rem;
            }

            .card {
                padding: 1.2rem;
            }

            .card h2 {
                font-size: 1.4rem;
            }

            .form-control {
                font-size: 0.85rem;
                padding: 0.75rem 0.9rem 0.75rem 2.3rem;
            }

            .form-group i {
                left: 0.7rem;
                font-size: 0.85rem;
            }

            .form-group label {
                left: 2.3rem;
                font-size: 0.85rem;
            }

            .form-control:focus + label,
            .form-control:not(:placeholder-shown) + label,
            select.form-control + label {
                top: -0.5rem;
                left: 1rem;
                font-size: 0.7rem;
            }

            .btn {
                padding: 0.7rem 1.2rem;
                font-size: 0.85rem;
            }

            .logo-icon {
                width: 34px;
                height: 34px;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .user-info {
                justify-content: center;
            }

            .col-md-6 {
                flex: 1 0 100%;
            }

            .card {
                padding: 1rem;
            }

            .card h2 {
                font-size: 1.3rem;
            }

            .form-control {
                font-size: 0.8rem;
                padding: 0.7rem 0.8rem 0.7rem 2.2rem;
            }

            .form-group i {
                left: 0.6rem;
                font-size: 0.8rem;
            }

            .form-group label {
                left: 2.2rem;
                font-size: 0.8rem;
            }

            .form-control:focus + label,
            .form-control:not(:placeholder-shown) + label,
            select.form-control + label {
                top: -0.5rem;
                left: 0.9rem;
                font-size: 0.65rem;
            }

            .btn {
                padding: 0.7rem;
                font-size: 0.8rem;
                min-height: 40px;
            }

            .btn-sm {
                padding: 0.4rem 0.8rem;
                font-size: 0.8rem;
            }

            .table th,
            .table td {
                font-size: 0.8rem;
                padding: 0.6rem;
            }

            .alert {
                font-size: 0.8rem;
                padding: 0.8rem;
            }

            .logo-icon {
                width: 32px;
                height: 32px;
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 0.8rem;
            }

            .header {
                padding: 0.6rem 1rem;
            }

            .header h1 {
                font-size: 1.2rem;
            }

            .logo-icon {
                width: 32px;
                height: 32px;
            }

            .user-info span {
                font-size: 0.8rem;
            }

            .card {
                padding: 0.8rem;
            }

            .card h2 {
                font-size: 1.2rem;
            }

            .form-control {
                font-size: 0.75rem;
                padding: 0.65rem 0.8rem 0.65rem 2rem;
            }

            .form-group i {
                left: 0.6rem;
                font-size: 0.75rem;
            }

            .form-group label {
                left: 2rem;
                font-size: 0.75rem;
            }

            .form-control:focus + label,
            .form-control:not(:placeholder-shown) + label,
            select.form-control + label {
                top: -0.5rem;
                left: 0.8rem;
                font-size: 0.6rem;
            }

            .btn {
                padding: 0.6rem;
                font-size: 0.75rem;
                min-height: 36px;
            }

            .btn-sm {
                padding: 0.3rem 0.6rem;
                font-size: 0.75rem;
                min-height: 32px;
            }

            .table th,
            .table td {
                font-size: 0.75rem;
                padding: 0.5rem;
            }

            .alert {
                font-size: 0.75rem;
                padding: 0.7rem;
            }

            .alert i {
                font-size: 1rem;
            }

            .footer {
                font-size: 0.7rem;
                padding: 0.4rem;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo-section">
                <div class="logo-icon"><img src="../images/logo.png" alt="E Certificate Logo"></div>
                <h1>E Certificates</h1>
            </div>
            <div class="user-info">
                <span>Superadmin</span>
                <a href="../handlers/logout.php" class="btn btn-outline"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <main class="container main-content">
        <div class="card">
            <h2><i class="fas fa-user-plus"></i> Register Faculty</h2>
            <?php echo $message; ?>
            <?php echo $error; ?>
            <form method="post" action="">
                <input type="hidden" name="action" value="register_faculty">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <i class="fas fa-user"></i>
                            <input type="text" name="name" class="form-control" placeholder=" " required>
                            <label>Name</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <i class="fas fa-envelope"></i>
                            <input type="email" name="email" class="form-control" placeholder=" " required>
                            <label>Email</label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password" class="form-control" placeholder=" " required>
                            <label>Password</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <i class="fas fa-building"></i>
                            <select name="department" class="form-control" required>
                                <option value="">Select Department</option>
                                <option value="AIT">AIT</option>
                                <option value="ABS">ABS</option>
                            </select>
                            <label>Department</label>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Register</button>
            </form>
        </div>

        <div class="card">
            <h2><i class="fas fa-file-alt"></i> Upload Certificate Template</h2>
            <?php echo $template_message; ?>
            <?php echo $template_error; ?>
            <form method="post" action="" enctype="multipart/form-data">
                <input type="hidden" name="action" value="upload_template">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <i class="fas fa-file-alt"></i>
                            <input type="text" name="template_name" class="form-control" placeholder=" " required>
                            <label>Template Name</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <i class="fas fa-upload"></i>
                            <input type="file" name="template_file" class="form-control" accept=".ppt,.pptx" required>
                            <label>Template File (PPT/PPTX)</label>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Upload Template</button>
            </form>
        </div>

        <div class="card">
            <h2><i class="fas fa-users"></i> Faculty List</h2>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th><i class="fas fa-user"></i> Name</th>
                            <th><i class="fas fa-envelope"></i> Email</th>
                            <th><i class="fas fa-building"></i> Department</th>
                            <th><i class="fas fa-calendar-alt"></i> Created At</th>
                            <th><i class="fas fa-tools"></i> Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($faculty_list)): ?>
                            <tr>
                                <td colspan="5" class="text-center">No faculty registered</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($faculty_list as $faculty): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($faculty['name']); ?></td>
                                    <td><?php echo htmlspecialchars($faculty['email']); ?></td>
                                    <td><?php echo htmlspecialchars($faculty['department']); ?></td>
                                    <td><?php echo date('Y-m-d H:i:s', strtotime($faculty['created_at'])); ?></td>
                                    <td class="table-action-buttons">
                                        <button class="btn btn-sm btn-danger delete-faculty" data-id="<?php echo $faculty['id']; ?>"><i class="fas fa-trash"></i> Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card">
            <h2><i class="fas fa-file-alt"></i> Template List</h2>
            <div class="table-responsive">
                <table class="table template-table">
                    <thead>
                        <tr>
                            <th><i class="fas fa-file-alt"></i> Template Name</th>
                            <th><i class="fas fa-file"></i> File</th>
                            <th><i class="fas fa-calendar-alt"></i> Created At</th>
                            <th><i class="fas fa-tools"></i> Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($template_list)): ?>
                            <tr>
                                <td colspan="4" class="text-center">No templates uploaded</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($template_list as $template): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($template['template_name']); ?></td>
                                    <td><a href="../Uploads/templates/<?php echo htmlspecialchars($template['template_file']); ?>" target="_blank"><?php echo htmlspecialchars($template['template_file']); ?></a></td>
                                    <td><?php echo date('Y-m-d H:i:s', strtotime($template['created_at'])); ?></td>
                                    <td class="table-action-buttons">
                                        <button class="btn btn-sm btn-danger delete-template" data-id="<?php echo $template['id']; ?>" data-file="<?php echo htmlspecialchars($template['template_file']); ?>"><i class="fas fa-trash"></i> Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <footer class="footer">
        Developed by Team GARUDA 🦅
    </footer>

    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());

        document.onkeydown = function(e) {
            if (
                e.keyCode == 123 || 
                (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) ||
                (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) ||
                (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) || 
                (e.ctrlKey && e.keyCode == 'S'.charCodeAt(0))
            ) {
                return false;
            }
        };

        document.addEventListener('selectstart', e => e.preventDefault());
        document.addEventListener('dragstart', e => e.preventDefault());

        setInterval(() => {
            const devtoolsOpen = window.outerWidth - window.innerWidth > 100;
            if (devtoolsOpen) {
                document.body.innerHTML = "<h1 style='text-align:center; margin-top:20%; color:red;'>Inspecting is not allowed!</h1>";
            }
        }, 1000);

        document.addEventListener('DOMContentLoaded', function() {

            document.querySelectorAll('.delete-faculty').forEach(button => {
                button.addEventListener('click', function() {
                    if (confirm('Are you sure you want to delete this faculty member?')) {
                        const facultyId = this.getAttribute('data-id');
                        const button = this;
                        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Deleting...';
                        button.disabled = true;

                        fetch('../handlers/delete_faculty.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({ id: facultyId })
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                alert('Faculty deleted successfully');
                                button.closest('tr').remove();
                            } else {
                                alert('Error: ' + data.error);
                                button.innerHTML = '<i class="fas fa-trash"></i> Delete';
                                button.disabled = false;
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('An error occurred while deleting the faculty');
                            button.innerHTML = '<i class="fas fa-trash"></i> Delete';
                            button.disabled = false;
                        });
                    }
                });
            });

            document.querySelectorAll('.delete-template').forEach(button => {
                button.addEventListener('click', function() {
                    if (confirm('Are you sure you want to delete this template?')) {
                        const templateId = this.getAttribute('data-id');
                        const templateFile = this.getAttribute('data-file');
                        const button = this;
                        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Deleting...';
                        button.disabled = true;

                        fetch('../handlers/delete_template.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({ id: templateId, file: templateFile })
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                alert('Template deleted successfully');
                                button.closest('tr').remove();
                            } else {
                                alert('Error: ' + data.error);
                                button.innerHTML = '<i class="fas fa-trash"></i> Delete';
                                button.disabled = false;
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('An error occurred while deleting the template');
                            button.innerHTML = '<i class="fas fa-trash"></i> Delete';
                            button.disabled = false;
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>