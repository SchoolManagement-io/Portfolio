<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../index.html");
    exit;
}

if ($_SESSION['role'] !== 'student') {
    header("Location: ../index.html");
    exit;
}

require_once '../assets/db_config.php';

$userId = $_SESSION['user_id'];
$studentEmail = $_SESSION['email'];

$sql = "SELECT c.*, cat.category_name, e.event_name 
        FROM certificates c
        JOIN events e ON c.event_id = e.id
        JOIN categories cat ON e.category_id = cat.id
        WHERE c.participant_email = ?
        ORDER BY c.id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $studentEmail);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - E Certificate System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        :root {
            --primary: #FF6B01;
            --secondary: #FFFFFF;
            --dark: #353535;
            --shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 10px 20px rgba(0, 0, 0, 0.12);
            --border-radius: 12px;
            --border-radius-sm: 6px;
            --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(145deg, #f7f7f7, #e8e8e8);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -webkit-user-drag: none;
            -webkit-touch-callout: none;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: clamp(0.8rem, 2vw, 1.5rem);
            padding-bottom: clamp(3rem, 8vh, 4rem);
            width: 100%;
        }

        .app-header {
            background: var(--secondary);
            box-shadow: var(--shadow);
            padding: clamp(0.6rem, 1.5vw, 1rem) clamp(1rem, 2vw, 2rem);
            position: sticky;
            top: 0;
            z-index: 1000;
            animation: fadeInDown 0.8s ease;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: clamp(0.5rem, 2vw, 1rem);
        }

        .app-logo {
            display: flex;
            align-items: center;
            gap: clamp(0.5rem, 1vw, 0.75rem);
        }

        .logo-icon {
            width: clamp(32px, 5vw, 36px);
            height: clamp(32px, 5vw, 36px);
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            transition: var(--transition);
            overflow: hidden;
        }

        .logo-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .app-logo:hover .logo-icon {
            transform: scale(1.1);
        }

        .app-logo h1 {
            font-size: clamp(1.2rem, 2.5vw, 1.6rem);
            font-weight: 600;
            color: var(--primary);
        }

        .app-nav {
            display: flex;
            gap: clamp(0.5rem, 1.5vw, 1rem);
            flex-wrap: wrap;
            justify-content: center;
        }

        .nav-link {
            padding: clamp(0.5rem, 1vw, 0.7rem) clamp(0.8rem, 2vw, 1.2rem);
            border-radius: var(--border-radius-sm);
            text-decoration: none;
            font-weight: 500;
            font-size: clamp(0.8rem, 1.5vw, 0.9rem);
            color: var(--dark);
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            min-height: 44px;
            min-width: 44px;
        }

        .nav-link:hover,
        .nav-link.active {
            background: var(--primary);
            color: var(--secondary);
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .logout {
            background: #dc2626;
            color: var(--secondary);
        }

        .logout:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .dashboard-container {
            display: flex;
            flex-direction: column;
            gap: clamp(1.5rem, 4vw, 2rem);
            margin-top: clamp(1.5rem, 4vw, 2rem);
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            backdrop-filter: blur(8px);
            animation: fadeInUp 0.8s ease;
            overflow: hidden;
        }

        .card-header {
            background: linear-gradient(90deg, var(--primary), #ff8c00);
            color: var(--secondary);
            padding: clamp(0.8rem, 2vw, 1rem) clamp(1rem, 2.5vw, 1.5rem);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-header h2 {
            font-size: clamp(1.2rem, 2.5vw, 1.5rem);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-body {
            padding: clamp(1rem, 2.5vw, 1.5rem);
        }

        .filter-container {
            padding: clamp(1rem, 2.5vw, 1.5rem);
            background: #f9fafb;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .filter-row {
            display: flex;
            flex-wrap: wrap;
            gap: clamp(0.75rem, 2vw, 1rem);
        }

        .filter-col {
            flex: 1;
            min-width: clamp(150px, 40vw, 200px);
            max-width: 100%;
        }

        .form-group {
            position: relative;
            margin-bottom: clamp(1rem, 3vw, 1.5rem);
        }

        .form-control {
            width: 100%;
            padding: clamp(0.6rem, 1.5vw, 0.8rem) 1rem clamp(0.6rem, 1.5vw, 0.8rem) clamp(2rem, 5vw, 2.5rem);
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: var(--border-radius-sm);
            font-size: clamp(0.75rem, 1.5vw, 0.9rem);
            transition: var(--transition);
            background: #fafafa;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(255, 107, 1, 0.1);
            outline: none;
        }

        select.form-control {
            appearance: none;
            background: #fafafa url("data:image/svg+xml;utf8,<svg fill='%23353535' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/><path d='M0 0h24v24H0z' fill='none'/></svg>") no-repeat right 0.75rem center/16px 16px;
        }

        .form-group i {
            position: absolute;
            left: clamp(0.6rem, 1.5vw, 0.8rem);
            top: 50%;
            transform: translateY(-50%);
            color: var(--dark);
            opacity: 0.5;
            font-size: clamp(0.75rem, 1.5vw, 0.9rem);
        }

        .form-group label {
            position: absolute;
            top: 50%;
            left: clamp(2rem, 5vw, 2.5rem);
            transform: translateY(-50%);
            font-size: clamp(0.75rem, 1.5vw, 0.9rem);
            color: var(--dark);
            opacity: 0.65;
            transition: var(--transition);
            pointer-events: none;
            background: transparent;
        }

        .form-control:focus + label,
        .form-control:not(:placeholder-shown) + label,
        select.form-control + label {
            top: clamp(-0.5rem, -1vw, -0.6rem);
            left: clamp(1rem, 2vw, 1.2rem);
            font-size: clamp(0.6rem, 1.2vw, 0.75rem);
            color: var(--primary);
            background: var(--secondary);
            padding: 0 0.2rem;
            opacity: 1;
        }

        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: clamp(0.5rem, 1.5vw, 0.8rem);
            text-align: left;
            font-size: clamp(0.75rem, 1.5vw, 0.9rem);
            min-width: clamp(80px, 10vw, 100px);
        }

        .table th {
            background: var(--primary);
            color: var(--secondary);
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .table tr:nth-child(even) {
            background: #f9fafb;
        }

        .table tr:hover {
            background: #fff7ed;
        }

        .btn {
            padding: clamp(0.3rem, 1vw, 0.5rem) clamp(0.6rem, 1.5vw, 1rem);
            border-radius: var(--border-radius-sm);
            font-weight: 500;
            font-size: clamp(0.7rem, 1.4vw, 0.85rem);
            border: none;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            min-height: clamp(32px, 8vw, 36px);
            min-width: clamp(32px, 8vw, 36px);
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(90deg, var(--primary), #ff8c00);
            color: var(--secondary);
        }

        .btn-primary:hover {
            background: linear-gradient(90deg, #e55e00, var(--primary));
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .btn-secondary {
            background: #6b7280;
            color: var(--secondary);
        }

        .btn-secondary:hover {
            background: #4b5563;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .btn-success {
            background: #16a34a;
            color: var(--secondary);
            text-decoration: none;
        }

        .btn-success:hover {
            background: #15803d;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .badge-danger {
            background: #dc2626;
            color: var(--secondary);
            padding: clamp(0.2rem, 0.8vw, 0.3rem) clamp(0.4rem, 1.2vw, 0.6rem);
            border-radius: var(--border-radius-sm);
            font-size: clamp(0.7rem, 1.3vw, 0.8rem);
            display: inline-block;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1001;
            animation: fadeIn 0.3s ease;
        }

        .modal-content {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.9);
            padding: clamp(1rem, 2.5vw, 1.5rem);
            width: clamp(80%, 90vw, 95%);
            max-width: clamp(400px, 80vw, 500px);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-lg);
            animation: scaleIn 0.3s ease forwards;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            padding-bottom: clamp(0.8rem, 2vw, 1rem);
        }

        .modal-header h3 {
            font-size: clamp(1.1rem, 2vw, 1.3rem);
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .close-modal {
            background: none;
            border: none;
            font-size: clamp(1.2rem, 2.5vw, 1.5rem);
            cursor: pointer;
            color: var(--dark);
            opacity: 0.5;
            transition: var(--transition);
        }

        .close-modal:hover {
            opacity: 1;
        }

        .modal-body {
            padding: clamp(1rem, 2.5vw, 1.5rem) 0;
            text-align: center;
        }

        .qr-container img {
            max-width: clamp(120px, 30vw, 200px);
            margin-bottom: clamp(1rem, 3vw, 1.5rem);
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: var(--border-radius-sm);
        }

        .qr-actions {
            display: flex;
            flex-direction: column;
            gap: clamp(0.5rem, 1.5vw, 0.75rem);
            justify-content: center;
            margin-bottom: clamp(0.8rem, 2vw, 1rem);
        }

        .qr-instructions {
            font-size: clamp(0.7rem, 1.4vw, 0.85rem);
            color: var(--dark);
            opacity: 0.7;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: var(--secondary);
            text-align: center;
            padding: clamp(0.4rem, 1vw, 0.5rem);
            font-size: clamp(0.7rem, 1.4vw, 0.8rem);
            color: var(--dark);
            opacity: 0.65;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            z-index: 1000;
        }

        .text-center {
            text-align: center;
            padding: clamp(0.8rem, 2vw, 1rem);
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes scaleIn {
            from {
                transform: translate(-50%, -50%) scale(0.9);
                opacity: 0;
            }
            to {
                transform: translate(-50%, -50%) scale(1);
                opacity: 1;
            }
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .header-content {
                flex-direction: column;
                align-items: center;
            }

            .app-nav {
                flex-direction: row;
                gap: clamp(0.4rem, 1.2vw, 0.8rem);
            }

            .table th,
            .table td {
                font-size: clamp(0.7rem, 1.4vw, 0.85rem);
                padding: clamp(0.4rem, 1.2vw, 0.7rem);
            }

            .logo-icon {
                width: clamp(30px, 4.5vw, 34px);
                height: clamp(30px, 4.5vw, 34px);
            }
        }

        @media (max-width: 768px) {
            .header-content {
                gap: clamp(0.8rem, 2vw, 1rem);
            }

            .app-nav {
                flex-direction: column;
                align-items: center;
            }

            .nav-link {
                width: 100%;
                justify-content: center;
            }

            .filter-row {
                flex-direction: column;
            }

            .filter-col {
                min-width: 100%;
            }

            .card-header {
                padding: clamp(0.6rem, 1.5vw, 0.8rem) clamp(0.8rem, 2vw, 1rem);
            }

            .card-header h2 {
                font-size: clamp(1.1rem, 2vw, 1.3rem);
            }

            .table th,
            .table td {
                font-size: clamp(0.65rem, 1.3vw, 0.8rem);
                padding: clamp(0.4rem, 1vw, 0.6rem);
                min-width: clamp(60px, 8vw, 80px);
            }

            .modal-content {
                width: clamp(85%, 95vw, 90%);
                max-width: clamp(300px, 80vw, 400px);
            }

            .logo-icon {
                width: clamp(28px, 4vw, 32px);
                height: clamp(28px, 4vw, 32px);
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: clamp(0.5rem, 1.5vw, 0.8rem);
                padding-bottom: clamp(2.5rem, 6vh, 3rem);
            }

            .app-header {
                padding: clamp(0.4rem, 1vw, 0.6rem) clamp(0.6rem, 1.5vw, 1rem);
            }

            .app-logo h1 {
                font-size: clamp(1rem, 2vw, 1.2rem);
            }

            .logo-icon {
                width: clamp(28px, 4vw, 32px);
                height: clamp(28px, 4vw, 32px);
            }

            .nav-link {
                padding: clamp(0.4rem, 1vw, 0.6rem) clamp(0.6rem, 1.5vw, 1rem);
                font-size: clamp(0.7rem, 1.4vw, 0.8rem);
                min-height: 40px;
            }

            .card {
                padding: clamp(0.6rem, 1.5vw, 0.8rem);
            }

            .card-header {
                padding: clamp(0.5rem, 1.2vw, 0.6rem) clamp(0.6rem, 1.5vw, 0.8rem);
            }

            .card-header h2 {
                font-size: clamp(1rem, 1.8vw, 1.2rem);
            }

            .filter-container {
                padding: clamp(0.8rem, 2vw, 1rem);
            }

            .form-control {
                padding: clamp(0.5rem, 1.2vw, 0.65rem) 0.8rem clamp(0.5rem, 1.2vw, 0.65rem) clamp(1.8rem, 4vw, 2rem);
                font-size: clamp(0.65rem, 1.3vw, 0.75rem);
            }

            .form-group i {
                left: clamp(0.5rem, 1.2vw, 0.6rem);
                font-size: clamp(0.65rem, 1.3vw, 0.75rem);
            }

            .form-group label {
                left: clamp(1.8rem, 4vw, 2rem);
                font-size: clamp(0.65rem, 1.3vw, 0.75rem);
            }

            .form-control:focus + label,
            .form-control:not(:placeholder-shown) + label,
            select.form-control + label {
                top: clamp(-0.4rem, -0.8vw, -0.5rem);
                left: clamp(0.6rem, 1.5vw, 0.8rem);
                font-size: clamp(0.5rem, 1vw, 0.6rem);
            }

            .btn {
                padding: clamp(0.2rem, 0.8vw, 0.3rem) clamp(0.4rem, 1vw, 0.6rem);
                font-size: clamp(0.65rem, 1.3vw, 0.75rem);
                min-height: clamp(28px, 7vw, 32px);
            }

            .table th,
            .table td {
                font-size: clamp(0.6rem, 1.2vw, 0.75rem);
                padding: clamp(0.3rem, 0.8vw, 0.5rem);
                min-width: clamp(50px, 7vw, 60px);
            }

            .modal-content {
                padding: clamp(0.6rem, 1.5vw, 0.8rem);
            }

            .modal-header h3 {
                font-size: clamp(0.9rem, 1.8vw, 1.1rem);
            }

            .qr-container img {
                max-width: clamp(100px, 25vw, 120px);
            }

            .qr-instructions {
                font-size: clamp(0.6rem, 1.2vw, 0.75rem);
            }

            .footer {
                font-size: clamp(0.6rem, 1.2vw, 0.7rem);
                padding: clamp(0.3rem, 0.8vw, 0.4rem);
            }
        }

        @media (max-width: 360px) {
            .container {
                padding: clamp(0.4rem, 1.2vw, 0.6rem);
            }

            .app-logo h1 {
                font-size: clamp(0.9rem, 1.8vw, 1rem);
            }

            .nav-link {
                font-size: clamp(0.65rem, 1.3vw, 0.75rem);
                min-height: 36px;
            }

            .table th,
            .table td {
                font-size: clamp(0.55rem, 1.1vw, 0.7rem);
                padding: clamp(0.25rem, 0.6vw, 0.4rem);
                min-width: clamp(40px, 6vw, 50px);
            }

            .btn {
                font-size: clamp(0.6rem, 1.2vw, 0.7rem);
                min-height: clamp(26px, 6.5vw, 30px);
            }

            .logo-icon {
                width: clamp(26px, 3.5vw, 30px);
                height: clamp(26px, 3.5vw, 30px);
            }
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="container">
            <div class="header-content">
                <div class="app-logo">
                    <div class="logo-icon"><img src="../images/logo.png" alt="E Certificate Logo"></div>
                    <h1>E Certificates</h1>
                </div>
                <nav class="app-nav">
                    <a href="student_dashboard.php" class="nav-link active"><i class="fas fa-certificate"></i> My Certificates</a>
                    <a href="../handlers/logout.php" class="nav-link logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <main class="container dashboard-container">
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-list-ul"></i> My Certificates</h2>
            </div>
            <div class="filter-container">
                <div class="filter-row">
                    <div class="filter-col">
                        <div class="form-group">
                            <i class="fas fa-search"></i>
                            <input type="text" id="search" class="form-control" placeholder="Search certificates...">
                            <label>Search</label>
                        </div>
                    </div>
                    <div class="filter-col">
                        <div class="form-group">
                            <i class="fas fa-graduation-cap"></i>
                            <select id="filter_course" class="form-control">
                                <option value="">All Courses</option>
                                <?php
                                $courseQuery = "SELECT DISTINCT course_name FROM certificates WHERE participant_email = ?";
                                $courseStmt = $conn->prepare($courseQuery);
                                $courseStmt->bind_param("s", $studentEmail);
                                $courseStmt->execute();
                                $courseResult = $courseStmt->get_result();
                                while ($courseRow = $courseResult->fetch_assoc()) {
                                    echo "<option value='" . htmlspecialchars($courseRow['course_name']) . "'>" . htmlspecialchars($courseRow['course_name']) . "</option>";
                                }
                                ?>
                            </select>
                            <label>Course</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-user"></i> Name</th>
                                <th><i class="fas fa-id-card"></i> CRN</th>
                                <th><i class="fas fa-phone"></i> Mobile</th>
                                <th><i class="fas fa-envelope"></i> Email</th>
                                <th><i class="fas fa-folder"></i> Category</th>
                                <th><i class="fas fa-calendar-check"></i> Event</th>
                                <th><i class="fas fa-barcode"></i> Certificate Ref</th>
                                <th><i class="fas fa-file"></i> File</th>
                                <th><i class="fas fa-qrcode"></i> QR Code</th>
                            </tr>
                        </thead>
                        <tbody id="certificate-table">
                            <?php
                            if ($result && $result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr data-course='" . htmlspecialchars($row['course_name']) . "'>";
                                    echo "<td>" . htmlspecialchars($row['participant_name']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['participant_crn']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['participant_mobile']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['participant_email']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['category_name']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['event_name']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['certificate_ref']) . "</td>";
                                    echo "<td>";
                                    if (!empty($row['certificate_file'])) {
                                        $downloadUrl = "../handlers/download_certificate.php?ref=" . urlencode($row['certificate_ref']);
                                        echo "<a href='$downloadUrl' class='btn btn-primary btn-sm'><i class='fas fa-download'></i> Download</a>";
                                    } else {
                                        echo "<span class='badge-danger'>No File</span>";
                                    }
                                    echo "</td>";
                                    echo "<td>";
                                    if (!empty($row['qr_code'])) {
                                        $qrUrl = "../qrcodes/" . htmlspecialchars($row['qr_code']);
                                        $verificationUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                                        $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
                                        if ($scriptDir != '/') {
                                            $verificationUrl .= $scriptDir;
                                        }
                                        $verificationUrl .= "/view_certificate.php?ref=" . urlencode($row['certificate_ref']);
                                        echo "<button class='btn btn-secondary btn-sm view-qr' data-qr='$qrUrl' data-url='$verificationUrl'><i class='fas fa-qrcode'></i> View QR</button>";
                                    } else {
                                        echo "<span class='badge-danger'>No QR</span>";
                                    }
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='9' class='text-center p-3'>No certificates found for your email address.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <div id="qr-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-qrcode"></i> Certificate QR Code</h3>
                <button class="close-modal">×</button>
            </div>
            <div class="modal-body">
                <div class="qr-container">
                    <img id="qr-image" src="" alt="QR Code">
                    <div class="qr-actions">
                        <button id="print-qr" class="btn btn-primary"><i class="fas fa-print"></i> Print QR Code</button>
                        <a id="direct-link" href="#" target="_blank" class="btn btn-success"><i class='fas fa-link'></i> Open Verification Link</a>
                    </div>
                    <p class="qr-instructions">Scan this QR code or use the button above to verify the certificate.</p>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        Developed by Team GARUDA 🦅
    </footer>

    <script>
        document.addEventListener('contextmenu', event => event.preventDefault());

        document.onkeydown = function(e) {
            if (
                e.keyCode == 123 ||
                (e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) ||
                (e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) ||
                (e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) ||
                (e.ctrlKey && e.keyCode == 'S'.charCodeAt(0))
            ) {
                return false;
            }
        };

        document.addEventListener('selectstart', e => e.preventDefault());
        document.addEventListener('dragstart', e => e.preventDefault());

        setInterval(() => {
            const devtoolsOpen = window.outerWidth - window.innerWidth > 100;
            if (devtoolsOpen) {
                document.body.innerHTML = "<h1 style='text-align:center; margin-top:20%; color:red;'>Inspecting is not allowed!</h1>";
            }
        }, 1000);

        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('search');
            const filterCourse = document.getElementById('filter_course');

            function filterCertificates() {
                const searchValue = searchInput.value.toLowerCase();
                const courseValue = filterCourse.value;
                const rows = document.querySelectorAll('#certificate-table tr');

                rows.forEach(row => {
                    if (row.querySelector('td')) {
                        const text = row.textContent.toLowerCase();
                        const course = row.getAttribute('data-course');
                        const searchMatch = !searchValue || text.includes(searchValue);
                        const courseMatch = !courseValue || course === courseValue;
                        row.style.display = searchMatch && courseMatch ? '' : 'none';
                    }
                });
            }

            searchInput.addEventListener('input', filterCertificates);
            filterCourse.addEventListener('change', filterCertificates);

            const modal = document.getElementById('qr-modal');
            const qrImage = document.getElementById('qr-image');
            const printQr = document.getElementById('print-qr');
            const directLink = document.getElementById('direct-link');

            document.querySelectorAll('.view-qr').forEach(btn => {
                btn.addEventListener('click', function() {
                    qrImage.src = this.dataset.qr;
                    directLink.href = this.dataset.url;
                    modal.style.display = 'block';
                });
            });

            document.querySelector('.close-modal').addEventListener('click', () => modal.style.display = 'none');
            window.addEventListener('click', e => {
                if (e.target === modal) modal.style.display = 'none';
            });

            printQr.addEventListener('click', () => {
                const printWindow = window.open('', '_blank');
                printWindow.document.write('<img src="' + qrImage.src + '" onload="window.print();window.close()">');
            });
        });
    </script>
</body>
</html>