<?php
require_once 'vendor/autoload.php';

use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevel;

function generateQRCode($data, $filename) {
    $qrDir = __DIR__ . '/../qrcodes/';
    $qrPath = $qrDir . $filename;

    if (!file_exists($qrDir)) {
        mkdir($qrDir, 0777, true);
        file_put_contents(__DIR__ . '/debug_log.txt', date('Y-m-d H:i:s') . " - Created qrcodes directory\n", FILE_APPEND);
    }

    try {
        $builder = new Builder(
            writer: new PngWriter(),
            size: 300,
            margin: 10,
        );

        $result = $builder->build(
            data: $data
        );

        $result->saveToFile($qrPath);

        if (file_exists($qrPath)) {
            file_put_contents(__DIR__ . '/debug_log.txt', date('Y-m-d H:i:s') . " - QR code generated successfully: $qrPath\n", FILE_APPEND);
            return $filename;
        } else {
            file_put_contents(__DIR__ . '/debug_log.txt', date('Y-m-d H:i:s') . " - QR code file not found after generation\n", FILE_APPEND);
            throw new Exception('Failed to generate QR code');
        }
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/debug_log.txt', date('Y-m-d H:i:s') . " - QR code generation error: " . $e->getMessage() . "\n", FILE_APPEND);
        throw $e;
    }
}
?>