<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../index.html");
    exit;
}

if ($_SESSION['role'] !== 'faculty') {
    header("Location: ../index.html");
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_error_log.txt');

require_once '../assets/db_config.php';
require_once 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - import_certificates.php started\n", FILE_APPEND);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_FILES['import_file']) || $_FILES['import_file']['error'] !== UPLOAD_ERR_OK) {
        file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - No file uploaded or upload error\n", FILE_APPEND);
        echo json_encode(['success' => false, 'error' => 'No file uploaded or upload error']);
        exit;
    }

    if (!isset($_POST['template_id']) || empty(trim($_POST['template_id']))) {
        file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - Missing template ID\n", FILE_APPEND);
        echo json_encode(['success' => false, 'error' => 'Template ID is required']);
        exit;
    }

    $file = $_FILES['import_file']['tmp_name'];
    $created_by = mysqli_real_escape_string($conn, $_POST['created_by']);
    $template_id = mysqli_real_escape_string($conn, $_POST['template_id']);

    file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - File uploaded: $file, Created by: $created_by, Template ID: $template_id\n", FILE_APPEND);

    try {
        $spreadsheet = IOFactory::load($file);
        $sheet = $spreadsheet->getActiveSheet();
        $data = $sheet->toArray();

        $expectedHeaders = [
            'Participant Name',
            'CRN',
            'Mobile',
            'Email',
            'Course Name',
            'Category Name',
            'Event Name'
        ];

        $headers = array_map('trim', $data[0]);
        if ($headers !== $expectedHeaders) {
            file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - Invalid headers: " . implode(', ', $headers) . "\n", FILE_APPEND);
            echo json_encode(['success' => false, 'error' => 'Invalid file format. Headers must be: ' . implode(', ', $expectedHeaders)]);
            exit;
        }

        $successCount = 0;
        $errors = [];
        $rowCount = count($data) - 1; 
        set_time_limit($rowCount * 5); 

        for ($i = 1; $i < count($data); $i++) {
            set_time_limit(5); 
            $row = array_map('trim', $data[$i]);
            if (empty($row[0])) continue;

            $category_name = $row[5];
            $event_name = $row[6];

            file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - Processing row $i: " . implode(', ', $row) . "\n", FILE_APPEND);

            $categoryQuery = "SELECT id FROM categories WHERE category_name = '" . mysqli_real_escape_string($conn, $category_name) . "'";
            $categoryResult = mysqli_query($conn, $categoryQuery);
            if (!$categoryResult || mysqli_num_rows($categoryResult) == 0) {
                $errors[] = "Row $i: Category '$category_name' not found";
                file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - Category '$category_name' not found\n", FILE_APPEND);
                continue;
            }
            $categoryRow = mysqli_fetch_assoc($categoryResult);
            $category_id = $categoryRow['id'];

            $eventQuery = "SELECT id FROM events WHERE event_name = '" . mysqli_real_escape_string($conn, $event_name) . "' AND category_id = '$category_id'";
            $eventResult = mysqli_query($conn, $eventQuery);
            if (!$eventResult || mysqli_num_rows($eventResult) == 0) {
                $errors[] = "Row $i: Event '$event_name' not found under category '$category_name'";
                file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - Event '$event_name' not found under category '$category_name'\n", FILE_APPEND);
                continue;
            }
            $eventRow = mysqli_fetch_assoc($eventResult);
            $event_id = $eventRow['id'];

            $certificate_ref = 'AGOI2025EXE' . rand(100000, 999999);
            $sql = "INSERT INTO certificates (participant_name, participant_crn, participant_mobile, participant_email, 
                                             course_name, category_id, event_id, template_id, certificate_ref, created_by, created_at) 
                    VALUES (
                        '" . mysqli_real_escape_string($conn, $row[0]) . "',
                        '" . mysqli_real_escape_string($conn, $row[1]) . "',
                        '" . mysqli_real_escape_string($conn, $row[2]) . "',
                        '" . mysqli_real_escape_string($conn, $row[3]) . "',
                        '" . mysqli_real_escape_string($conn, $row[4]) . "',
                        '$category_id',
                        '$event_id',
                        '$template_id',
                        '$certificate_ref',
                        '$created_by',
                        NOW()
                    )";

            file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - SQL Query for row $i: $sql\n", FILE_APPEND);

            if (mysqli_query($conn, $sql)) {
                $successCount++;
                file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - Row $i added successfully\n", FILE_APPEND);
            } else {
                $db_error = mysqli_error($conn);
                $errors[] = "Row $i: Database error - $db_error";
                file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - Database error for row $i: $db_error\n", FILE_APPEND);
            }
        }

        if ($successCount > 0) {
            echo json_encode(['success' => true, 'message' => "$successCount certificates imported successfully", 'errors' => $errors]);
        } else {
            echo json_encode(['success' => false, 'error' => 'No certificates imported', 'details' => $errors]);
        }
        file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - Import complete. Success: $successCount, Errors: " . count($errors) . "\n", FILE_APPEND);
    } catch (Exception $e) {
        file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - Exception: " . $e->getMessage() . "\n", FILE_APPEND);
        echo json_encode(['success' => false, 'error' => 'Error processing file: ' . $e->getMessage()]);
    }
    mysqli_close($conn);
    exit;
} else {
    header("Location: ../includes/dashboard.php");
    exit;
}
?>