<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../index.html");
    exit;
}

if ($_SESSION['role'] !== 'faculty') {
    header("Location: ../index.html");
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'php_error_log.txt');

ob_start();

require_once '../assets/db_config.php';
require_once 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

file_put_contents('import_debug_log.txt', date('Y-m-d H:i:s') . " - import_export.php started\n", FILE_APPEND);

$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($action === 'export') {
    ob_end_clean();

    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    $headers = [
        'Participant Name',
        'CRN',
        'Mobile',
        'Email',
        'Course Name',
        'Category Name',
        'Event Name'
    ];
    $sheet->fromArray($headers, NULL, 'A1');

    $userId = $_SESSION['user_id'];
    $query = "SELECT c.participant_name, c.participant_crn, c.participant_mobile, c.participant_email, 
                     c.course_name, cat.category_name, e.event_name 
              FROM certificates c 
              JOIN events e ON c.event_id = e.id 
              JOIN categories cat ON e.category_id = cat.id 
              WHERE c.created_by = '$userId'";
    $result = mysqli_query($conn, $query);

    $data = [];
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = [
                $row['participant_name'],
                $row['participant_crn'],
                $row['participant_mobile'],
                $row['participant_email'],
                $row['course_name'],
                $row['category_name'],
                $row['event_name']
            ];
        }
    } else {
        $data = [
            ['John Doe', 'CRN123', '9876543210', 'john@example.com', 'BCA', 'Technical', 'Hackathon'],
            ['Jane Smith', 'CRN456', '9123456789', 'jane@example.com', 'BBA', 'Cultural', 'Dance Competition']
        ];
    }
    $sheet->fromArray($data, NULL, 'A2');

    foreach (range('A', 'G') as $column) {
        $sheet->getColumnDimension($column)->setAutoSize(true);
    }

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="certificate_template.xlsx"');
    header('Cache-Control: max-age=0');
    header('Pragma: public');
    header('Expires: 0');

    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
} else {
    ob_end_clean();
    header("Location: ../includes/dashboard.php");
    exit;
}
?>