<?php
session_start();
require_once '../assets/db_config.php';

ob_start();

require_once 'vendor/autoload.php';

use PhpOffice\PhpPresentation\PhpPresentation;
use PhpOffice\PhpPresentation\IOFactory;

error_reporting(E_ALL & ~E_DEPRECATED & ~E_WARNING);

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../index.html");
    exit;
}

if ($_SESSION['role'] !== 'superadmin' && $_SESSION['role'] !== 'faculty') {
    header("Location: ../includes/dashboard.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Certificate ID is required']);
    exit;
}

$certificateId = mysqli_real_escape_string($conn, $_GET['id']);

file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Starting certificate generation for ID: $certificateId\n", FILE_APPEND);

$sql = "SELECT c.participant_name, c.course_name, c.certificate_ref, e.event_name, c.template_id 
        FROM certificates c 
        JOIN events e ON c.event_id = e.id 
        WHERE c.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $certificateId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $errorMsg = "Certificate not found for ID: $certificateId";
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - $errorMsg\n", FILE_APPEND);
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $errorMsg]);
    exit;
}

$certificate = $result->fetch_assoc();
$participantName = $certificate['participant_name'];
$courseName = $certificate['course_name'];
$eventName = $certificate['event_name'];
$certificateRef = $certificate['certificate_ref'];
$templateId = $certificate['template_id'];

$templateQuery = "SELECT template_name, template_file 
                  FROM certificate_templates 
                  WHERE id = ?";
$templateStmt = $conn->prepare($templateQuery);
$templateStmt->bind_param("i", $templateId);
$templateStmt->execute();
$templateResult = $templateStmt->get_result();

if ($templateResult->num_rows === 0) {
    $errorMsg = "Template not found for Template ID: $templateId";
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - $errorMsg\n", FILE_APPEND);
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $errorMsg]);
    exit;
}

$template = $templateResult->fetch_assoc();
$templateName = $template['template_name'];
$templateFile = $template['template_file'];

$templatePath = "../Uploads/templates/" . $templateFile;
if (!file_exists($templatePath)) {
    $errorMsg = "Template file '{$templateFile}' not found in Uploads/templates directory";
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - $errorMsg\n", FILE_APPEND);
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $errorMsg]);
    exit;
}

if ($_SESSION['role'] === 'faculty') {
    $checkQuery = "SELECT created_by FROM certificates WHERE id = ?";
    $checkStmt = $conn->prepare($checkQuery);
    $checkStmt->bind_param("i", $certificateId);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    $certData = $checkResult->fetch_assoc();
    if ($certData['created_by'] != $_SESSION['user_id']) {
        $errorMsg = "Permission denied for ID: $certificateId";
        file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - $errorMsg\n", FILE_APPEND);
        ob_end_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => $errorMsg]);
        exit;
    }
}

try {
    $oPresentation = IOFactory::load($templatePath);
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Template loaded successfully: $templatePath\n", FILE_APPEND);
} catch (Exception $e) {
    $errorMsg = "Failed to load template: " . $e->getMessage();
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - $errorMsg\n", FILE_APPEND);
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $errorMsg]);
    exit;
}

$oSlide = $oPresentation->getSlide(0);
$shapes = $oSlide->getShapeCollection();
$placeholders = [
    '{PARTICIPANT_NAME}' => $participantName,
    '{COURSE_NAME}' => $courseName,
    '{EVENT_NAME}' => $eventName,
    '{CERTIFICATE_REF}' => $certificateRef
];

foreach ($shapes as $index => $shape) {
    if (method_exists($shape, 'getParagraphs')) {
        $paragraphs = $shape->getParagraphs();
        if ($paragraphs && count($paragraphs) > 0) {
            foreach ($paragraphs as $paragraph) {
                $textElements = $paragraph->getRichTextElements();
                if ($textElements && count($textElements) > 0) {
                    foreach ($textElements as $textElement) {
                        $text = $textElement->getText();
                        if ($text !== null && $text !== '') {
                            $newText = str_replace(array_keys($placeholders), array_values($placeholders), $text);
                            if ($newText !== $text) {
                                $textElement->setText($newText);
                            }
                        }
                    }
                }
            }
        }
    }
}

$outputPptx = "../certificates/{$certificateRef}.pptx";
if (!file_exists('../certificates')) {
    mkdir('../certificates', 0777, true);
}

try {
    $oWriterPPTX = IOFactory::createWriter($oPresentation, 'PowerPoint2007');
    $oWriterPPTX->save($outputPptx);
    flush();
    $pptxSize = filesize($outputPptx);
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - PPTX saved: $outputPptx, Size: $pptxSize bytes\n", FILE_APPEND);
    if ($pptxSize < 1000) {
        throw new Exception("PPTX file is too small ($pptxSize bytes), likely invalid.");
    }
} catch (Exception $e) {
    $errorMsg = "Failed to save PPTX: " . $e->getMessage();
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - $errorMsg\n", FILE_APPEND);
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $errorMsg]);
    exit;
}

$outputPdf = "../certificates/{$certificateRef}.pdf";
$libreOfficePath = '"C:\Program Files\LibreOffice\program\soffice.exe"';
$command = "$libreOfficePath --headless --convert-to pdf " . escapeshellarg(realpath($outputPptx)) . " --outdir " . escapeshellarg(realpath('../certificates'));

file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Executing command: $command\n", FILE_APPEND);
exec($command . " 2>&1", $output, $returnVar);
$commandOutput = implode("\n", $output);
file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - Command executed. Return code: $returnVar, Output: $commandOutput\n", FILE_APPEND);

$maxWait = 15;
$waited = 0;
$lastSize = 0;
while ($waited < $maxWait) {
    if (file_exists($outputPdf)) {
        $currentSize = filesize($outputPdf);
        if ($currentSize > 1000 && $currentSize == $lastSize) {
            break;
        }
        $lastSize = $currentSize;
    }
    sleep(1);
    $waited++;
}

if (file_exists($outputPdf) && filesize($outputPdf) > 1000) {
    $pdfSize = filesize($outputPdf);
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - PDF generated: $outputPdf, Size: $pdfSize bytes\n", FILE_APPEND);
    
    ob_end_clean();

    if (isset($_GET['return_path'])) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'file_path' => $outputPdf]);
    } else {
        header('Content-Type: application/pdf');
        header("Content-Disposition: attachment; filename=\"{$certificateRef}.pdf\"");
        header("Content-Length: " . $pdfSize);
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');
        readfile($outputPdf);
    }
    exit;
} else {
    $errorMsg = "PDF generation failed. Size: " . (file_exists($outputPdf) ? filesize($outputPdf) : 0) . " bytes, Command output: $commandOutput";
    file_put_contents('debug_log.txt', date('Y-m-d H:i:s') . " - $errorMsg\n", FILE_APPEND);
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $errorMsg]);
    exit;
}

mysqli_close($conn);
?>
